# Cubescape: 3D Block House Mystery Adventure

Cubescape is a 3D block-style puzzle and mystery adventure game built for Android with Jetpack Compose, Three.js, and Android hardware acceleration.

## Overview
- **Visual Atmosphere**: Twilight / sunset ambiance with soft lilac, amber, and warm peach hues.
- **Controls**: Virtual joystick / touch controls, camera toggle between 1st Person and 3rd Person, interact prompt, and customizable HUD.
- **Story & Exploration**: Explore interconnected rooms, discover collectible yellow rubber ducks, investigate clues, and meet magical companions.
- **Android Integration**: Native bridge supporting vibration haptics, state persistence via SharedPreferences, full edge-to-edge support, and responsive Android back-key handling.

## Tech Stack
- **OS / Target**: Android (Min SDK 24, Target SDK 36, Java 11)
- **UI & Architecture**: Jetpack Compose, Material 3, Android Bridge WebView
- **Graphics**: Three.js WebGL with Android performance tuning
