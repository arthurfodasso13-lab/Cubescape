// Cubescape Procedural Web Audio Engine
// Independent channels: Master, Music, Ambient, Character

class SoundEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.musicGain = null;
    this.ambientGain = null;
    this.characterGain = null;
    this.voiceVolume = 1.0;
    this.currentVoice = null;

    // Default volumes
    this.volumes = {
      master: 0.8,
      music: 0.6,
      ambient: 0.5,
      character: 0.8,
      voice: 1.0
    };

    this.bgmPlaying = false;
    this.bgmTimer = null;
    this.ambientTimer = null;
    this.windNode = null;

    this.loadVolumes();
  }

  loadVolumes() {
    try {
      const saved = localStorage.getItem('cubescape_audio_settings');
      if (saved) {
        Object.assign(this.volumes, JSON.parse(saved));
      }
    } catch (e) {
      console.warn('Failed to load audio settings', e);
    }
  }

  saveVolumes() {
    try {
      localStorage.setItem('cubescape_audio_settings', JSON.stringify(this.volumes));
    } catch (e) {
      console.warn('Failed to save audio settings', e);
    }
  }

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioCtx();

      // Master Gain
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volumes.master, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      // Music Gain
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.setValueAtTime(this.volumes.music, this.ctx.currentTime);
      this.musicGain.connect(this.masterGain);

      // Ambient Gain (Wind & Birds)
      this.ambientGain = this.ctx.createGain();
      this.ambientGain.gain.setValueAtTime(this.volumes.ambient, this.ctx.currentTime);
      this.ambientGain.connect(this.masterGain);

      // Character Gain (Footsteps & Interactions)
      this.characterGain = this.ctx.createGain();
      this.characterGain.gain.setValueAtTime(this.volumes.character, this.ctx.currentTime);
      this.characterGain.connect(this.masterGain);

      this.startAmbientMusic();
      this.startOutdoorAmbience();
    } catch (e) {
      console.warn("Web Audio not supported or blocked", e);
    }
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setMasterVolume(val) {
    this.volumes.master = Math.max(0, Math.min(1, val));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volumes.master, this.ctx.currentTime);
    }
    this.saveVolumes();
  }

  setMusicVolume(val) {
    this.volumes.music = Math.max(0, Math.min(1, val));
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setValueAtTime(this.volumes.music, this.ctx.currentTime);
    }
    this.saveVolumes();
  }

  setAmbientVolume(val) {
    this.volumes.ambient = Math.max(0, Math.min(1, val));
    if (this.ambientGain && this.ctx) {
      this.ambientGain.gain.setValueAtTime(this.volumes.ambient, this.ctx.currentTime);
    }
    this.saveVolumes();
  }

  setCharacterVolume(val) {
    this.volumes.character = Math.max(0, Math.min(1, val));
    if (this.characterGain && this.ctx) {
      this.characterGain.gain.setValueAtTime(this.volumes.character, this.ctx.currentTime);
    }
    this.saveVolumes();
  }


  // --- LOCAL RECORDED VOICES ---
  setVoiceVolume(val) {
    this.volumes.voice = Math.max(0, Math.min(1, val));
    this.saveVolumes();
    if (this.currentVoice) this.currentVoice.volume = this.volumes.voice * this.volumes.master;
  }

  playVoice(relativePath) {
    if (!relativePath) return;
    try {
      if (this.currentVoice) {
        this.currentVoice.pause();
        this.currentVoice.currentTime = 0;
      }
      const voice = new Audio(relativePath);
      voice.preload = 'auto';
      voice.volume = Math.max(0, Math.min(1, (this.volumes.voice ?? 1) * this.volumes.master));
      this.currentVoice = voice;
      const result = voice.play();
      if (result && typeof result.catch === 'function') {
        result.catch(() => {
          // Missing optional voice files or WebView playback restrictions should never break gameplay.
        });
      }
    } catch (e) {
      console.warn('Voice playback unavailable:', e);
    }
  }

  stopVoice() {
    if (this.currentVoice) {
      this.currentVoice.pause();
      this.currentVoice.currentTime = 0;
      this.currentVoice = null;
    }
  }

  // --- BACKGROUND MUSIC ---
  startAmbientMusic() {
    if (this.bgmPlaying || !this.ctx) return;
    this.bgmPlaying = true;

    // Peaceful indie chord sequence: Cmaj7 -> Am9 -> Fmaj9 -> G6
    const chordProgression = [
      [261.63, 329.63, 392.00, 493.88], // C E G B
      [220.00, 261.63, 329.63, 493.88], // A C E B
      [174.61, 261.63, 329.63, 392.00], // F C E G
      [196.00, 246.94, 293.66, 392.00]  // G B D G
    ];
    let chordIdx = 0;

    const playChord = () => {
      if (!this.bgmPlaying || !this.ctx) return;
      const notes = chordProgression[chordIdx];
      chordIdx = (chordIdx + 1) % chordProgression.length;

      const now = this.ctx.currentTime;
      notes.forEach((freq, i) => {
        const osc = this.ctx.createOscillator();
        const noteGain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();

        osc.type = i % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now + i * 0.18);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(750, now);

        noteGain.gain.setValueAtTime(0, now + i * 0.18);
        noteGain.gain.linearRampToValueAtTime(0.09, now + i * 0.18 + 0.5);
        noteGain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.18 + 4.2);

        osc.connect(filter);
        filter.connect(noteGain);
        noteGain.connect(this.musicGain);

        osc.start(now + i * 0.18);
        osc.stop(now + i * 0.18 + 4.5);
      });

      this.bgmTimer = setTimeout(playChord, 5000);
    };

    playChord();
  }

  stopAmbientMusic() {
    this.bgmPlaying = false;
    if (this.bgmTimer) clearTimeout(this.bgmTimer);
  }

  // --- OUTDOOR AMBIENT (BREEZE & BIRDS) ---
  startOutdoorAmbience() {
    if (!this.ctx) return;

    // Gentle bird chirp routine
    const triggerBird = () => {
      if (!this.ctx) return;
      this.playBirdChirp();
      const nextDelay = 7000 + Math.random() * 9000;
      this.ambientTimer = setTimeout(triggerBird, nextDelay);
    };
    this.ambientTimer = setTimeout(triggerBird, 3000);
  }

  playBirdChirp() {
    if (!this.ctx || this.volumes.ambient <= 0.01) return;
    const now = this.ctx.currentTime;
    const count = 2 + Math.floor(Math.random() * 2);
    for (let i = 0; i < count; i++) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      const startF = 2600 + Math.random() * 400;
      const endF = 3400 + Math.random() * 600;
      osc.frequency.setValueAtTime(startF, now + i * 0.12);
      osc.frequency.exponentialRampToValueAtTime(endF, now + i * 0.12 + 0.07);

      gain.gain.setValueAtTime(0.04, now + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.12 + 0.09);

      osc.connect(gain);
      gain.connect(this.ambientGain);

      osc.start(now + i * 0.12);
      osc.stop(now + i * 0.12 + 0.1);
    }
  }

  // --- CHARACTER SOUNDS ---
  playFootstep() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(100 + Math.random() * 15, now);
    osc.frequency.exponentialRampToValueAtTime(38, now + 0.07);

    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);

    osc.connect(gain);
    gain.connect(this.characterGain);

    osc.start(now);
    osc.stop(now + 0.08);
  }

  playDoor() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.linearRampToValueAtTime(190, now + 0.22);

    gain.gain.setValueAtTime(0.09, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(450, now);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.characterGain);

    osc.start(now);
    osc.stop(now + 0.3);
  }

  playDrawer() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(160, now + 0.2);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.linearRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(this.characterGain);
    osc.start(now);
    osc.stop(now + 0.22);
  }

  playItemPickup() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5 E5 G5 C6
    notes.forEach((freq, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.06);

      gain.gain.setValueAtTime(0.16, now + idx * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.35);

      osc.connect(gain);
      gain.connect(this.characterGain);

      osc.start(now + idx * 0.06);
      osc.stop(now + idx * 0.06 + 0.38);
    });
  }

  playClick() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, now);
    osc.frequency.exponentialRampToValueAtTime(400, now + 0.04);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    osc.connect(gain);
    gain.connect(this.characterGain);
    osc.start(now);
    osc.stop(now + 0.05);
  }

  playSafeSuccess() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const freqs = [440, 554.37, 659.25, 880];
    freqs.forEach((f, i) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, now + i * 0.1);
      gain.gain.setValueAtTime(0.18, now + i * 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.1 + 0.5);
      osc.connect(gain);
      gain.connect(this.characterGain);
      osc.start(now + i * 0.1);
      osc.stop(now + i * 0.1 + 0.55);
    });
  }

  playSafeError() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, now);
    osc.frequency.setValueAtTime(130, now + 0.15);

    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(gain);
    gain.connect(this.characterGain);
    osc.start(now);
    osc.stop(now + 0.36);
  }

  playDuckQuack() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(700, now);
    osc.frequency.linearRampToValueAtTime(950, now + 0.08);
    osc.frequency.linearRampToValueAtTime(600, now + 0.22);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    osc.connect(gain);
    gain.connect(this.characterGain);
    osc.start(now);
    osc.stop(now + 0.26);
  }

  playFlush() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(90, now + 0.8);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(350, now);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.9);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.characterGain);
    osc.start(now);
    osc.stop(now + 0.95);
  }

  playVictory() {
    if (!this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const chords = [
      { f: [261.63, 329.63, 392.00], t: 0.0, d: 0.3 },
      { f: [293.66, 369.99, 440.00], t: 0.35, d: 0.3 },
      { f: [329.63, 392.00, 493.88], t: 0.7, d: 0.3 },
      { f: [392.00, 493.88, 587.33, 783.99], t: 1.05, d: 1.2 }
    ];
    chords.forEach(c => {
      c.f.forEach(freq => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + c.t);
        gain.gain.setValueAtTime(0.2, now + c.t);
        gain.gain.exponentialRampToValueAtTime(0.001, now + c.t + c.d);
        osc.connect(gain);
        gain.connect(this.characterGain);
        osc.start(now + c.t);
        osc.stop(now + c.t + c.d + 0.05);
      });
    });
  }
}

window.soundEngine = new SoundEngine();
