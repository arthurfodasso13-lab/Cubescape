// Cubescape: 3D Block House Mystery Adventure
// Complete with:
// - Refined voluminous dark curly hairstyle for Maya
// - Smooth sliding capsule collision preventing furniture trapping
// - First-Person (1P) and Third-Person (3P) camera modes with ceiling collision avoidance
// - Bedroom starting location with fully animated 3D opening wake-up cutscene
// - Responsive jump mechanics with gravity
// - Fun MEME button with 6 randomized Portuguese phrases and speech bubble
// - Fully customizable HUD layout

(function () {
  'use strict';

  // Conservative rendering profile for Android phones and other low-power devices.
  // The game must remain playable on mid-range hardware rather than prioritizing desktop visuals.
  const IS_MOBILE_DEVICE = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent || '') ||
    (window.matchMedia && window.matchMedia('(max-width: 800px)').matches);
  const MOBILE_PIXEL_RATIO = 1.0;
  const DESKTOP_PIXEL_RATIO = 1.35;
  let lastMirrorRenderAt = 0;

  // --- MODULAR NARRATIVE SCRIPT SYSTEM (MEMORIES_CONFIG) ---
  // Easy-to-edit configuration for all memory rooms in the Wizard Cat's mind.
  // Each room has presentation text, mandatory interactable objects, conclusion text, and door unlocking.
  const MEMORIES_CONFIG = [
    {
      id: 'bedroom',
      name: 'Quarto das Origens',
      subtitle: 'O Início das Lembranças',
      zMin: 8.5,
      zMax: 18.5,
      doorId: 'door_bedroom',
      presentationText: [
        '[ROTEIRO PROVISÓRIO - APRESENTAÇÃO DO GATO]',
        'Este lugar... é familiar para você, não é? Foi aqui que começamos a guardar tudo o que não queríamos esquecer.',
        'Dê uma olhada ao redor antes de sairmos. Alguns detalhes daqui ainda guardam o início da nossa jornada.'
      ],
      mandatoryObjectIds: ['bedroom_mirror', 'bedroom_diary', 'bedroom_desk'],
      conclusionText: [
        '[ROTEIRO PROVISÓRIO - CONCLUSÃO DO CÔMODO]',
        'Você ainda se lembra desses pequenos detalhes. A porta está aberta... venha, há muito mais para recordar adiante.'
      ],
      objects: [
        {
          id: 'bedroom_mirror',
          name: 'Espelho de Corpo Inteiro',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'O espelho reflete Maya e o quarto com clareza.',
            'O Gato Feiticeiro observa: "Sempre que olhava para esse reflexo, você procurava respostas... mas as respostas não estão na imagem, e sim nas lembranças que deixamos pelo caminho."'
          ]
        },
        {
          id: 'bedroom_diary',
          name: 'Diário de Cabeceira',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Um caderno com anotações e desenhos cuidadosos feitos à mão.',
            'O Gato Feiticeiro murmura: "Lembro de quando você escreveu aqui pela primeira vez. Cada página era um plano para os lugares que queríamos construir juntos."'
          ]
        },
        {
          id: 'bedroom_desk',
          name: 'Bancada de Criação',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Plantas arquitetônicas, réguas de precisão e esboços geométricos.',
            'O Gato Feiticeiro comenta: "Você passava horas aqui desenhando formas e cômodos. É por isso que tudo aqui dentro se parece tanto com as coisas que você imaginava."'
          ]
        }
      ]
    },
    {
      id: 'memory_room_1',
      name: '1º Cômodo: Biblioteca dos Pergaminhos',
      subtitle: 'Memória da Primeira Descoberta',
      zMin: -1.5,
      zMax: 8.5,
      doorId: 'door_room1',
      presentationText: [
        '[ROTEIRO PROVISÓRIO - APRESENTAÇÃO DO GATO]',
        'Bem-vinda à primeira memória. Aqui eu guardei as coisas antigas que aprendemos a decifrar juntos.',
        'Observe os pergaminhos e estantes. Cada um carrega um fragmento daquele dia chuvoso.'
      ],
      mandatoryObjectIds: ['library_scrolls', 'library_globe', 'library_armchair'],
      conclusionText: [
        '[ROTEIRO PROVISÓRIO - CONCLUSÃO DO CÔMODO]',
        'Percebe como o silêncio dessa sala se parece com aquele silêncio tranquilo da tarde? O caminho para a próxima memória está livre.'
      ],
      objects: [
        {
          id: 'library_scrolls',
          name: 'Pergaminhos Antigos Abertos',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Mapas desenhados com tinta sépia e símbolos astronômicos antigos.',
            'O Gato Feiticeiro aponta com a varinha: "Estes são os primeiros mapas que tentamos decifrar. Você dizia que cada linha traçava um destino."'
          ]
        },
        {
          id: 'library_globe',
          name: 'Globo Celeste de Latão',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Uma esfera metálica giratória detalhando constelações imaginárias.',
            'O Gato Feiticeiro comenta: "Girávamos este globo e escolhíamos constelações imaginárias para dar nomes aos nossos pensamentos."'
          ]
        },
        {
          id: 'library_armchair',
          name: 'Poltrona de Leitura Âmbar',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Uma poltrona macia de veludo com uma manta dobrada sobre o braço de madeira.',
            'O Gato Feiticeiro senta-se brevemente: "Eu costumava dormir ao pé dessa poltrona enquanto você lia histórias até tarde."'
          ]
        }
      ]
    },
    {
      id: 'memory_room_2',
      name: '2º Cômodo: Jardim de Inverno e Chá',
      subtitle: 'Memória da Serenidade e Conversas',
      zMin: -11.5,
      zMax: -1.5,
      doorId: 'door_room2',
      presentationText: [
        '[ROTEIRO PROVISÓRIO - APRESENTAÇÃO DO GATO]',
        'Respire fundo. Consegue sentir o aroma das laranjeiras e da terra úmida?',
        'Esta memória é uma das minhas favoritas. Foi uma época de paz, onde o tempo parecia não ter pressa.'
      ],
      mandatoryObjectIds: ['garden_tea_table', 'garden_fountain', 'garden_orange_tree'],
      conclusionText: [
        '[ROTEIRO PROVISÓRIO - CONCLUSÃO DO CÔMODO]',
        'O calor suave deste lugar continua tão vívido quanto naquele dia. Venha, a próxima porta já se abriu.'
      ],
      objects: [
        {
          id: 'garden_tea_table',
          name: 'Mesa de Chá de Porcelana',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Duas xícaras de chá repousadas ao lado de um bule de cerâmica azul e biscoitos artesanais.',
            'O Gato Feiticeiro sorri suavemente: "Você sempre colocava duas xícaras na mesa, mesmo sabendo que gatos bebem água fresca. Eu achava gentil da sua parte."'
          ]
        },
        {
          id: 'garden_fountain',
          name: 'Fonte de Pedra Esculpida',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Água cristalina fluindo suavemente sobre degraus de pedra com reflexos dourados.',
            'O Gato Feiticeiro escuta o murmúrio: "O som da água sempre acalmava você quando os dias eram difíceis. Eu quis eternizar esse som aqui."'
          ]
        },
        {
          id: 'garden_orange_tree',
          name: 'Laranjeira em Flor',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Um arbusto frutífero com laranjas maduras e pequenas flores perfumadas.',
            'O Gato Feiticeiro cheira o ar: "Plantamos a muda juntos. Olhe como ela cresceu forte na minha lembrança."'
          ]
        }
      ]
    },
    {
      id: 'memory_room_3',
      name: '3º Cômodo: Ateliê de Música e Sonhos',
      subtitle: 'Memória da Criação Compartilhada',
      zMin: -21.5,
      zMax: -11.5,
      doorId: 'door_room3',
      presentationText: [
        '[ROTEIRO PROVISÓRIO - APRESENTAÇÃO DO GATO]',
        'Escute com atenção. Aqui cada acorde e cada traço de pincel foram compartilhados.',
        'Nesta época, você já sabia exatamente como transformar sentimentos em arte.'
      ],
      mandatoryObjectIds: ['atelier_piano', 'atelier_easel', 'atelier_gramophone'],
      conclusionText: [
        '[ROTEIRO PROVISÓRIO - CONCLUSÃO DO CÔMODO]',
        'A melodia nunca realmente parou de tocar. Estamos nos aproximando do coração das minhas memórias.'
      ],
      objects: [
        {
          id: 'atelier_piano',
          name: 'Piano Vertical em Mogno',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Teclas de marfim e partituras manuscritas com anotações e sentimentos sinceros.',
            'O Gato Feiticeiro toca uma tecla com a pata: "Quando você tocava, eu me deitava sobre a tampa de madeira para sentir a vibração das cordas."'
          ]
        },
        {
          id: 'atelier_easel',
          name: 'Cavalete com Pintura a Óleo',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Uma tela em processo retratando um horizonte de fim de tarde lilás com duas silhuetas lado a lado.',
            'O Gato Feiticeiro contempla o quadro: "Você ainda não tinha terminado esta pintura... ou talvez ela represente o que estamos vivendo agora."'
          ]
        },
        {
          id: 'atelier_gramophone',
          name: 'Gramofone de Bronze & Discos',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Um gramofone artesanal com sua campânula polida e discos de vinil cuidadosamente guardados.',
            'O Gato Feiticeiro observa: "Ouvíamos aquele mesmo disco repetidas vezes nas noites de vento frio. Aquela canção nunca envelhece."'
          ]
        }
      ]
    },
    {
      id: 'memory_room_4',
      name: '4º Cômodo: Observatório Celestial',
      subtitle: 'Memória da Compreensão e Despedida',
      zMin: -31.5,
      zMax: -21.5,
      doorId: 'door_room4',
      presentationText: [
        '[ROTEIRO PROVISÓRIO - APRESENTAÇÃO DO GATO]',
        'O céu aqui é infinito, Maya. Daqui conseguimos ver além das paredes e dos limites da casa.',
        'Foi neste observatório que você me ensinou a olhar para as estrelas sem medo da escuridão.'
      ],
      mandatoryObjectIds: ['observatory_telescope', 'observatory_celestial_map', 'observatory_crystals'],
      conclusionText: [
        '[ROTEIRO PROVISÓRIO - CONCLUSÃO DO CÔMODO]',
        'Você já compreendeu, não é? Esta casa é feita de tudo o que vivemos. E a grande porta final agora está aberta.'
      ],
      objects: [
        {
          id: 'observatory_telescope',
          name: 'Grande Telescópio de Latão',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Lentes polidas apontadas para uma constelação dourada em formato de gato e de uma estrela guia.',
            'O Gato Feiticeiro olha pela ocular: "Olhávamos para o céu e imaginávamos se haveria outros mundos tão acolhedores quanto o nosso."'
          ]
        },
        {
          id: 'observatory_celestial_map',
          name: 'Mesa de Cartografia Estelar',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Esquemas iluminados mostrando as órbitas e o mapa da mente mágica onde esta casa existe.',
            'O Gato Feiticeiro pousa a pata no mapa: "Tudo o que construímos juntos está mapeado aqui. Nenhuma memória se perdeu."'
          ]
        },
        {
          id: 'observatory_crystals',
          name: 'Agrupamento de Cristais Ressonantes',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Cristais translúcidos lilás e âmbar emitindo um zumbido harmônico suave.',
            'O Gato Feiticeiro murmura: "Eles ressoam com a sua presença. Quanto mais você se lembra, mais fortes eles brilham."'
          ]
        }
      ]
    },
    {
      id: 'final_grand_hall',
      name: 'A Grande Sala da Mente',
      subtitle: 'O Santuário das Memórias Eternas',
      zMin: -61.5,
      zMax: -31.5,
      doorId: null,
      presentationText: [
        '[ROTEIRO PROVISÓRIO - APRESENTAÇÃO DO GATO]',
        'Chegamos ao coração da minha mente, Maya. O lugar mais profundo e seguro que consegui construir para nós.',
        'Sinta a imensidão deste salão. Toda lembrança que revisitamos desemboca aqui.',
        'O pedestal central aguarda o que ainda há de vir... nosso elo mais puro.'
      ],
      mandatoryObjectIds: ['final_pedestal', 'final_pillar_altar', 'final_memorial_mirror'],
      conclusionText: [
        '[ROTEIRO PROVISÓRIO - CONCLUSÃO DO CÔMODO]',
        'O santuário está sereno. Maya e o Gato Feiticeiro permanecem lado a lado, unidos pela lembrança e pelo afeto que nada pode apagar.'
      ],
      objects: [
        {
          id: 'final_pedestal',
          name: 'O Pedestal Central do Santuário',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - ESPAÇO RESERVADO]',
            'Uma plataforma circular em mármore polido e runas de latão banhada por um feixe de luz celestial.',
            'O Gato Feiticeiro permanece ao lado: "Este lugar no centro do salão está guardado para o símbolo mais especial da nossa história. Ele será colocado aqui quando for a hora."'
          ]
        },
        {
          id: 'final_pillar_altar',
          name: 'Colunas do Tempo e Memória',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Colunas majestosas que sustentam a cúpula translúcida por onde brilha o sol poente eterno.',
            'O Gato Feiticeiro observa os relevos: "Cada coluna sustenta um ano, um mês, um instante em que estivemos juntos."'
          ]
        },
        {
          id: 'final_memorial_mirror',
          name: 'Vigia das Estrelas Infinitas',
          narrativeText: [
            '[ROTEIRO PROVISÓRIO - OBJETO]',
            'Uma imensa abertura para o horizonte cósmico em tons de lilás, âmbar e ouro.',
            'O Gato Feiticeiro senta-se junto a Maya: "Obrigado por caminhar comigo pelas minhas memórias. Eu nunca esquecerei quem você é."'
          ]
        }
      ]
    }
  ];

  // --- GAME STATE ---
  const state = {
    room: 'bedroom',
    cameraMode: '3P', // '3P' or '1P'
    inMainMenu: true,
    inCutscene: false,
    hudEditMode: false,
    inspectedObjects: [], // IDs of examined memory items
    unlockedDoors: [],    // IDs of opened doors
    roomsIntroduced: [],  // IDs of rooms whose intro narrative has played
    flags: {
      bedroomDrawerOpen: false,
      gameCompleted: false,
      cutsceneWatched: false
    }
  };

  // --- SAVE / LOAD PERSISTENCE ---
  function hasSavedGame() {
    return !!(localStorage.getItem('cubescape_save') || (window.AndroidBridge && window.AndroidBridge.loadGameState()));
  }

  function saveGame() {
    try {
      const saveData = {
        playerPos: { x: characterPos.x, y: characterPos.y, z: characterPos.z },
        characterYaw: characterFacingYaw,
        cameraMode: state.cameraMode,
        room: state.room,
        flags: state.flags,
        inspectedObjects: state.inspectedObjects,
        unlockedDoors: state.unlockedDoors,
        roomsIntroduced: state.roomsIntroduced,
        timestamp: Date.now()
      };
      const json = JSON.stringify(saveData);
      localStorage.setItem('cubescape_save', json);
      if (window.AndroidBridge && window.AndroidBridge.saveGameState) {
        window.AndroidBridge.saveGameState(json);
      }
      updateMenuButtons();
    } catch (e) {
      console.warn('Save failed', e);
    }
  }

  function loadGame() {
    try {
      let raw = null;
      if (window.AndroidBridge && window.AndroidBridge.loadGameState) {
        raw = window.AndroidBridge.loadGameState();
      }
      if (!raw) {
        raw = localStorage.getItem('cubescape_save');
      }
      if (!raw) return false;

      const data = JSON.parse(raw);
      if (data.flags) Object.assign(state.flags, data.flags);
      if (data.inspectedObjects) state.inspectedObjects = data.inspectedObjects;
      if (data.unlockedDoors) state.unlockedDoors = data.unlockedDoors;
      if (data.roomsIntroduced) state.roomsIntroduced = data.roomsIntroduced;
      if (data.room) state.room = data.room;
      if (data.cameraMode) setCameraMode(data.cameraMode);

      if (data.playerPos) {
        characterPos.set(data.playerPos.x, data.playerPos.y, data.playerPos.z);
      }
      if (data.characterYaw !== undefined) {
        characterFacingYaw = data.characterYaw;
      }

      // Restore unlocked doors from memory
      if (state.unlockedDoors && Array.isArray(state.unlockedDoors)) {
        state.unlockedDoors.forEach(doorId => {
          restoreUnlockedDoor(doorId);
        });
      }

      if (state.flags.bedroomDrawerOpen && bedroomDrawerMesh) {
        bedroomDrawerMesh.position.z = 14.9;
      }

      updateHUD();
      return true;
    } catch (e) {
      console.warn('Load failed', e);
      return false;
    }
  }

  // --- THREE.JS SCENE SETUP ---
  let scene, camera, renderer;
  let sunLight, sunMesh;
  const colliders = [];
  const interactables = [];
  const animDoors = [];
  const animDrawers = [];

  // --- 3D PLAYABLE ARTICULATED CHARACTER (Maya) ---
  let characterGroup;
  let wizardCatGroup = null;
  let wizardCatStaff = null;
  let catRadioTimer = 0;
  let catRadioVisible = false;
  let lastCatRoom = '';
  let charBodyRoot;
  let charHips, charSpineLower, charChest;
  let charNeck, charHead, charEyeLids;
  let charShoulderL, charUpperArmL, charElbowL, charForearmL, charWristL, charHandL, charFingersL;
  let charShoulderR, charUpperArmR, charElbowR, charForearmR, charWristR, charHandR, charFingersR;
  let charHipL, charThighL, charKneeL, charCalfL, charAnkleL, charFootL;
  let charHipR, charThighR, charKneeR, charCalfR, charAnkleR, charFootR;

  // Planar Mirror Reflection System
  let mirrorRenderTarget, mirrorCamera, mirrorGlassMesh, bedroomMirrorMesh;
  let bathMirrorRenderTarget, bathMirrorCamera, bathMirrorGlassMesh;

  // Environmental life & animation
  const animatedCurtains = [];
  const animatedPlants = [];
  let dustMotesGroup = null;

  // Bed & Key objects
  let bedroomDuvetMesh = null;
  let bedroomKeyMesh = null;

  // Physical reaching interaction
  let isReaching = false;
  let reachTimer = 0;
  let reachCallback = null;

  let characterPos = new THREE.Vector3(0, 0, 15.5); // Starts in Bedroom!
  let characterFacingYaw = Math.PI; // Faces forward toward door
  let currentSpeed = 0;
  let isMoving = false;
  let walkAnimTime = 0;
  let jumpVelocity = 0;
  let isGrounded = true;
  let blinkTimer = 3.2;

  // Camera Settings & Ceiling Clamping
  let cameraYaw = Math.PI;
  let cameraPitch = 0.22;
  const maxCamDistance = 3.2;
  let currentCamDistance = 3.2;
  const cameraTargetHeight = 1.35;
  let sensitivity = 0.0035;

  // Joystick Input
  let joyActive = false;
  let joyStartX = 0, joyStartY = 0;
  let joyDeltaX = 0, joyDeltaY = 0;
  let lookActive = false;
  let lookLastX = 0, lookLastY = 0;
  const keys = {};
  let activeInteractable = null;

  // Cutscene Tracking
  let cutsceneStage = 0;
  // --- PROCEDURAL PBR TEXTURE & MATERIAL GENERATOR ---
  const MaterialLib = (function() {
    function makeWoodTexture(baseHex, darkHex, isPlanks) {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 512;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = baseHex;
      ctx.fillRect(0, 0, 512, 512);

      ctx.fillStyle = darkHex;
      ctx.globalAlpha = 0.22;
      for (let y = 0; y < 512; y += 2) {
        ctx.beginPath();
        let x = 0;
        ctx.moveTo(x, y);
        while (x < 512) {
          const wave = Math.sin(x * 0.015 + y * 0.02) * 2.5 + Math.sin(x * 0.05) * 1.0;
          x += 8;
          ctx.lineTo(x, y + wave);
        }
        ctx.lineWidth = 1.2;
        ctx.strokeStyle = darkHex;
        ctx.stroke();
      }

      ctx.globalAlpha = 0.18;
      for (let k = 0; k < 3; k++) {
        const kx = 120 + k * 140;
        const ky = 160 + (k % 2) * 180;
        for (let r = 10; r < 55; r += 8) {
          ctx.beginPath();
          ctx.ellipse(kx, ky, r * 1.8, r * 0.7, 0.15, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      if (isPlanks) {
        ctx.globalAlpha = 0.5;
        ctx.fillStyle = '#1A0F07';
        for (let x = 128; x < 512; x += 128) {
          ctx.fillRect(x - 2, 0, 4, 512);
        }
      }
      ctx.globalAlpha = 1.0;

      const tex = new THREE.CanvasTexture(canvas);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      return tex;
    }

    function makeFabricTexture(baseHex, threadHex) {
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 256;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = baseHex;
      ctx.fillRect(0, 0, 256, 256);

      ctx.fillStyle = threadHex;
      ctx.globalAlpha = 0.18;
      for (let x = 0; x < 256; x += 4) {
        for (let y = 0; y < 256; y += 4) {
          if ((x / 4 + y / 4) % 2 === 0) {
            ctx.fillRect(x, y, 3, 3);
          }
        }
      }
      ctx.globalAlpha = 1.0;

      const tex = new THREE.CanvasTexture(canvas);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(4, 4);
      return tex;
    }

    function makeParquetTexture() {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 512;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#D4A373';
      ctx.fillRect(0, 0, 512, 512);

      const blockSize = 128;
      for (let bx = 0; bx < 512; bx += blockSize) {
        for (let by = 0; by < 512; by += blockSize) {
          const isHorizontal = ((bx / blockSize) + (by / blockSize)) % 2 === 0;
          ctx.fillStyle = ((bx / blockSize) % 2 === 0) ? '#C69363' : '#DCAB7B';
          ctx.fillRect(bx, by, blockSize, blockSize);

          ctx.strokeStyle = '#854D0E';
          ctx.lineWidth = 2;
          ctx.globalAlpha = 0.45;
          const numSlats = 4;
          const slatSize = blockSize / numSlats;
          for (let s = 0; s < numSlats; s++) {
            if (isHorizontal) {
              ctx.strokeRect(bx, by + s * slatSize, blockSize, slatSize);
            } else {
              ctx.strokeRect(bx + s * slatSize, by, slatSize, blockSize);
            }
          }
        }
      }
      ctx.globalAlpha = 1.0;

      const tex = new THREE.CanvasTexture(canvas);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(3, 3);
      return tex;
    }

    function makeTileTexture(tileHex, groutHex) {
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 256;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = groutHex;
      ctx.fillRect(0, 0, 256, 256);

      const tileSize = 60;
      const gap = 4;
      for (let x = gap; x < 256; x += tileSize + gap) {
        for (let y = gap; y < 256; y += tileSize + gap) {
          ctx.fillStyle = tileHex;
          ctx.fillRect(x, y, tileSize, tileSize);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
          ctx.fillRect(x, y, tileSize, 4);
          ctx.fillRect(x, y, 4, tileSize);
        }
      }

      const tex = new THREE.CanvasTexture(canvas);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(4, 4);
      return tex;
    }

    function makePlasterTexture(wallHex) {
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 256;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = wallHex;
      ctx.fillRect(0, 0, 256, 256);

      const imgData = ctx.getImageData(0, 0, 256, 256);
      const data = imgData.data;
      for (let i = 0; i < data.length; i += 4) {
        const noise = (Math.random() - 0.5) * 12;
        data[i] = Math.min(255, Math.max(0, data[i] + noise));
        data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + noise));
        data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + noise));
      }
      ctx.putImageData(imgData, 0, 0);

      const tex = new THREE.CanvasTexture(canvas);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(6, 6);
      return tex;
    }

    return {
      makeWoodTexture,
      makeFabricTexture,
      makeParquetTexture,
      makeTileTexture,
      makePlasterTexture
    };
  })();

  const PBR_MATERIALS = {};
  function initPBRMaterials() {
    PBR_MATERIALS.woodOak = new THREE.MeshStandardMaterial({
      map: MaterialLib.makeWoodTexture('#C89D66', '#854D0E', true),
      roughness: 0.35,
      metalness: 0.05
    });
    PBR_MATERIALS.woodDark = new THREE.MeshStandardMaterial({
      map: MaterialLib.makeWoodTexture('#6B4423', '#3E2412', true),
      roughness: 0.38,
      metalness: 0.05
    });
    PBR_MATERIALS.fabricMint = new THREE.MeshStandardMaterial({
      map: MaterialLib.makeFabricTexture('#A7F3D0', '#059669'),
      roughness: 0.85,
      metalness: 0.0
    });
    PBR_MATERIALS.fabricEmerald = new THREE.MeshStandardMaterial({
      map: MaterialLib.makeFabricTexture('#059669', '#064E3B'),
      roughness: 0.85,
      metalness: 0.0
    });
    PBR_MATERIALS.fabricSofa = new THREE.MeshStandardMaterial({
      map: MaterialLib.makeFabricTexture('#3B82F6', '#1E40AF'),
      roughness: 0.88,
      metalness: 0.0
    });
    PBR_MATERIALS.fabricWhite = new THREE.MeshStandardMaterial({
      map: MaterialLib.makeFabricTexture('#F8FAFC', '#CBD5E1'),
      roughness: 0.85,
      metalness: 0.0
    });
    PBR_MATERIALS.parquetFloor = new THREE.MeshStandardMaterial({
      map: MaterialLib.makeParquetTexture(),
      roughness: 0.32,
      metalness: 0.05
    });
    PBR_MATERIALS.bedroomFloor = new THREE.MeshStandardMaterial({
      map: MaterialLib.makeWoodTexture('#5C4033', '#3A2820', true),
      roughness: 0.35,
      metalness: 0.05
    });
    PBR_MATERIALS.tileKitchen = new THREE.MeshStandardMaterial({
      map: MaterialLib.makeTileTexture('#F1F5F9', '#94A3B8'),
      roughness: 0.22,
      metalness: 0.1
    });
    PBR_MATERIALS.tileBathroom = new THREE.MeshStandardMaterial({
      map: MaterialLib.makeTileTexture('#99F6E4', '#0D9488'),
      roughness: 0.18,
      metalness: 0.12
    });
    PBR_MATERIALS.plasterWall = new THREE.MeshStandardMaterial({
      map: MaterialLib.makePlasterTexture('#F8FAFC'),
      roughness: 0.88,
      metalness: 0.0
    });
    PBR_MATERIALS.metalChrome = new THREE.MeshStandardMaterial({
      color: 0xF1F5F9,
      roughness: 0.15,
      metalness: 0.9
    });
    PBR_MATERIALS.metalBrass = new THREE.MeshStandardMaterial({
      color: 0xF59E0B,
      roughness: 0.22,
      metalness: 0.85
    });
    PBR_MATERIALS.glassWindow = new THREE.MeshStandardMaterial({
      color: 0xBAE6FD,
      transparent: true,
      opacity: 0.35,
      roughness: 0.08,
      metalness: 0.1
    });
  }

  function initThree() {
    const container = document.getElementById('canvas-container');
    const width = Math.max(container.clientWidth || window.innerWidth, 320);
    const height = Math.max(container.clientHeight || window.innerHeight, 240);

    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87CEEB);
    scene.fog = new THREE.FogExp2(0xB0E2FF, 0.012);

    camera = new THREE.PerspectiveCamera(65, width / height, 0.1, 100);
    camera.position.set(characterPos.x, 1.8, characterPos.z + 3.8);
    camera.lookAt(characterPos.x, 1.2, characterPos.z);
    camera.updateProjectionMatrix();

    // Avoid expensive MSAA + high-DPI rendering on phones. A DPR of 1 is a major
    // reduction in fragment workload on common Android devices.
    renderer = new THREE.WebGLRenderer({
      antialias: !IS_MOBILE_DEVICE,
      alpha: false,
      powerPreference: IS_MOBILE_DEVICE ? 'low-power' : 'default',
      stencil: false,
      depth: true,
      preserveDrawingBuffer: false
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1,
      IS_MOBILE_DEVICE ? MOBILE_PIXEL_RATIO : DESKTOP_PIXEL_RATIO));
    renderer.setSize(width, height, false);

    // Real-time shadow maps are particularly costly in Android WebView.
    // Keep desktop shadows; use baked/material shading on mobile.
    renderer.shadowMap.enabled = !IS_MOBILE_DEVICE;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.top = '0';
    renderer.domElement.style.left = '0';
    container.appendChild(renderer.domElement);

    // Natural Daytime Lighting
    const hemiLight = new THREE.HemisphereLight(0xE0F2FE, 0xE2D9C8, 0.72);
    scene.add(hemiLight);

    sunLight = new THREE.DirectionalLight(0xFFF7ED, 1.25);
    sunLight.position.set(16, 26, -20);
    sunLight.castShadow = !IS_MOBILE_DEVICE;
    if (!IS_MOBILE_DEVICE) {
      sunLight.shadow.mapSize.width = 1024;
      sunLight.shadow.mapSize.height = 1024;
    }
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 65;
    const d = 24;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0005;
    scene.add(sunLight);

    initPBRMaterials();
    buildSkyAndSun();
    buildOutdoorScenery();
    buildModernHouse();
    buildCharacterMaya();
    buildWizardCat();
    initPlanarMirrorReflection();

    window.addEventListener('resize', onWindowResize);
    setupControls();
    loadHudLayout();
    updateMenuButtons();
  }

  // --- FULLY ARTICULATED SKELETAL RIG & CHARACTER MODEL (MAYA) ---
  function buildCharacterMaya() {
    characterGroup = new THREE.Group();
    characterGroup.position.copy(characterPos);

    charBodyRoot = new THREE.Group();
    characterGroup.add(charBodyRoot);

    const skinMat = new THREE.MeshStandardMaterial({ color: 0xF5D0B5, roughness: 0.65, metalness: 0.0 });
    const hairDarkMat = new THREE.MeshStandardMaterial({ color: 0x361E10, roughness: 0.75, metalness: 0.05 });
    const hairMedMat = new THREE.MeshStandardMaterial({ color: 0x472815, roughness: 0.75, metalness: 0.05 });
    const sweaterMat = PBR_MATERIALS.fabricMint;
    const jeansMat = new THREE.MeshStandardMaterial({ color: 0x2563EB, roughness: 0.7, metalness: 0.05 });
    const shoesMat = new THREE.MeshStandardMaterial({ color: 0xF8FAFC, roughness: 0.35, metalness: 0.1 });

    // 1. Pelvis / Hips (Root Joint of skeleton at Y = 0.72)
    charHips = new THREE.Group();
    charHips.position.set(0, 0.72, 0);
    const hipsMesh = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.22, 0.24), jeansMat);
    hipsMesh.castShadow = true;
    charHips.add(hipsMesh);
    charBodyRoot.add(charHips);

    // 2. Spine Lower (at top of hips)
    charSpineLower = new THREE.Group();
    charSpineLower.position.set(0, 0.11, 0);
    const spineMesh = new THREE.Mesh(new THREE.BoxGeometry(0.40, 0.22, 0.23), sweaterMat);
    spineMesh.position.set(0, 0.11, 0);
    spineMesh.castShadow = true;
    charSpineLower.add(spineMesh);
    charHips.add(charSpineLower);

    // 3. Chest / Upper Torso
    charChest = new THREE.Group();
    charChest.position.set(0, 0.22, 0);
    const chestMesh = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.26, 0.24), sweaterMat);
    chestMesh.position.set(0, 0.13, 0);
    chestMesh.castShadow = true;
    charChest.add(chestMesh);
    charSpineLower.add(charChest);

    // 4. Neck & Head
    charNeck = new THREE.Group();
    charNeck.position.set(0, 0.26, 0);
    const neckMesh = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.10, 0.16), skinMat);
    neckMesh.position.set(0, 0.05, 0);
    neckMesh.castShadow = true;
    charNeck.add(neckMesh);
    charChest.add(charNeck);

    charHead = new THREE.Group();
    charHead.position.set(0, 0.10, 0);
    const headMesh = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.34, 0.32), skinMat);
    headMesh.position.set(0, 0.17, 0);
    headMesh.castShadow = true;
    charHead.add(headMesh);

    // Eyes, Brows, and Animated Eyelids
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x1E293B });
    const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.02), eyeMat);
    eyeL.position.set(-0.09, 0.20, 0.165);
    charHead.add(eyeL);

    const eyeR = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.02), eyeMat);
    eyeR.position.set(0.09, 0.20, 0.165);
    charHead.add(eyeR);

    // Eyelids (scale Y to open/close/blink!)
    charEyeLids = new THREE.Group();
    charEyeLids.position.set(0, 0.20, 0.17);
    const eyelidL = new THREE.Mesh(new THREE.BoxGeometry(0.064, 0.064, 0.02), skinMat);
    eyelidL.position.set(-0.09, 0, 0);
    const eyelidR = new THREE.Mesh(new THREE.BoxGeometry(0.064, 0.064, 0.02), skinMat);
    eyelidR.position.set(0.09, 0, 0);
    charEyeLids.add(eyelidL);
    charEyeLids.add(eyelidR);
    charEyeLids.scale.y = 0.0;
    charHead.add(charEyeLids);

    // Subtle Smile
    const lipMat = new THREE.MeshBasicMaterial({ color: 0xE17B77 });
    const lips = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.03, 0.02), lipMat);
    lips.position.set(0, 0.08, 0.165);
    charHead.add(lips);

    // Voluminous Curly Hairstyle Clusters
    const crownTop = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.16, 0.42), hairDarkMat);
    crownTop.position.set(0, 0.35, -0.02);
    charHead.add(crownTop);

    const crownMid = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.18, 0.44), hairMedMat);
    crownMid.position.set(0, 0.25, -0.04);
    charHead.add(crownMid);

    const fringe1 = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 0.1), hairMedMat);
    fringe1.position.set(-0.11, 0.31, 0.16);
    fringe1.rotation.z = 0.15;
    charHead.add(fringe1);

    const fringe2 = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.08, 0.1), hairDarkMat);
    fringe2.position.set(0.08, 0.32, 0.16);
    fringe2.rotation.z = -0.12;
    charHead.add(fringe2);

    const curls = [
      { pos: [-0.22, 0.25, 0.1], s: [0.15, 0.15, 0.16], m: hairMedMat },
      { pos: [-0.24, 0.13, 0.08], s: [0.16, 0.16, 0.17], m: hairDarkMat },
      { pos: [-0.22, -0.01, 0.06], s: [0.15, 0.16, 0.16], m: hairMedMat },
      { pos: [-0.19, -0.15, 0.05], s: [0.14, 0.17, 0.15], m: hairDarkMat },
      { pos: [0.22, 0.25, 0.1], s: [0.15, 0.15, 0.16], m: hairDarkMat },
      { pos: [0.24, 0.13, 0.08], s: [0.16, 0.16, 0.17], m: hairMedMat },
      { pos: [0.22, -0.01, 0.06], s: [0.15, 0.16, 0.16], m: hairDarkMat },
      { pos: [0.19, -0.15, 0.05], s: [0.14, 0.17, 0.15], m: hairMedMat },
      { pos: [0, 0.22, -0.22], s: [0.38, 0.18, 0.18], m: hairDarkMat },
      { pos: [-0.12, 0.07, -0.23], s: [0.18, 0.18, 0.17], m: hairMedMat },
      { pos: [0.12, 0.07, -0.23], s: [0.18, 0.18, 0.17], m: hairDarkMat },
      { pos: [0, -0.08, -0.22], s: [0.24, 0.19, 0.16], m: hairDarkMat },
      { pos: [-0.08, -0.22, -0.20], s: [0.16, 0.16, 0.14], m: hairMedMat },
      { pos: [0.08, -0.22, -0.20], s: [0.16, 0.16, 0.14], m: hairDarkMat }
    ];
    curls.forEach(c => {
      const cm = new THREE.Mesh(new THREE.BoxGeometry(c.s[0], c.s[1], c.s[2]), c.m);
      cm.position.set(c.pos[0], c.pos[1], c.pos[2]);
      cm.castShadow = true;
      charHead.add(cm);
    });
    charNeck.add(charHead);

    // 5. Left Arm Joint Hierarchy
    charShoulderL = new THREE.Group();
    charShoulderL.position.set(-0.26, 0.22, 0);
    charChest.add(charShoulderL);

    charUpperArmL = new THREE.Group();
    const upperArmMeshL = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.24, 0.12), sweaterMat);
    upperArmMeshL.position.set(0, -0.12, 0);
    upperArmMeshL.castShadow = true;
    charUpperArmL.add(upperArmMeshL);
    charShoulderL.add(charUpperArmL);

    charElbowL = new THREE.Group();
    charElbowL.position.set(0, -0.24, 0);
    charUpperArmL.add(charElbowL);

    charForearmL = new THREE.Group();
    const forearmMeshL = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.22, 0.11), skinMat);
    forearmMeshL.position.set(0, -0.11, 0);
    forearmMeshL.castShadow = true;
    charForearmL.add(forearmMeshL);
    charElbowL.add(charForearmL);

    charWristL = new THREE.Group();
    charWristL.position.set(0, -0.22, 0);
    charForearmL.add(charWristL);

    charHandL = new THREE.Group();
    const handMeshL = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.08, 0.09), skinMat);
    handMeshL.position.set(0, -0.04, 0);
    handMeshL.castShadow = true;
    charHandL.add(handMeshL);
    charWristL.add(charHandL);

    charFingersL = new THREE.Group();
    charFingersL.position.set(0, -0.08, 0);
    const fingersMeshL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 0.06), skinMat);
    fingersMeshL.position.set(0, -0.03, 0);
    charFingersL.add(fingersMeshL);
    charHandL.add(charFingersL);

    // 6. Right Arm Joint Hierarchy
    charShoulderR = new THREE.Group();
    charShoulderR.position.set(0.26, 0.22, 0);
    charChest.add(charShoulderR);

    charUpperArmR = new THREE.Group();
    const upperArmMeshR = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.24, 0.12), sweaterMat);
    upperArmMeshR.position.set(0, -0.12, 0);
    upperArmMeshR.castShadow = true;
    charUpperArmR.add(upperArmMeshR);
    charShoulderR.add(charUpperArmR);

    charElbowR = new THREE.Group();
    charElbowR.position.set(0, -0.24, 0);
    charUpperArmR.add(charElbowR);

    charForearmR = new THREE.Group();
    const forearmMeshR = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.22, 0.11), skinMat);
    forearmMeshR.position.set(0, -0.11, 0);
    forearmMeshR.castShadow = true;
    charForearmR.add(forearmMeshR);
    charElbowR.add(charForearmR);

    charWristR = new THREE.Group();
    charWristR.position.set(0, -0.22, 0);
    charForearmR.add(charWristR);

    charHandR = new THREE.Group();
    const handMeshR = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.08, 0.09), skinMat);
    handMeshR.position.set(0, -0.04, 0);
    handMeshR.castShadow = true;
    charHandR.add(handMeshR);
    charWristR.add(charHandR);

    charFingersR = new THREE.Group();
    charFingersR.position.set(0, -0.08, 0);
    const fingersMeshR = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 0.06), skinMat);
    fingersMeshR.position.set(0, -0.03, 0);
    charFingersR.add(fingersMeshR);
    charHandR.add(charFingersR);

    // 7. Left Leg Joint Hierarchy
    charHipL = new THREE.Group();
    charHipL.position.set(-0.12, -0.05, 0);
    charHips.add(charHipL);

    charThighL = new THREE.Group();
    const thighMeshL = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.32, 0.16), jeansMat);
    thighMeshL.position.set(0, -0.16, 0);
    thighMeshL.castShadow = true;
    charThighL.add(thighMeshL);
    charHipL.add(charThighL);

    charKneeL = new THREE.Group();
    charKneeL.position.set(0, -0.32, 0);
    charThighL.add(charKneeL);

    charCalfL = new THREE.Group();
    const calfMeshL = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.30, 0.15), jeansMat);
    calfMeshL.position.set(0, -0.15, 0);
    calfMeshL.castShadow = true;
    charCalfL.add(calfMeshL);
    charKneeL.add(charCalfL);

    charAnkleL = new THREE.Group();
    charAnkleL.position.set(0, -0.30, 0);
    charCalfL.add(charAnkleL);

    charFootL = new THREE.Group();
    const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.10, 0.24), shoesMat);
    shoeL.position.set(0, -0.05, 0.04);
    shoeL.castShadow = true;
    charFootL.add(shoeL);
    charAnkleL.add(charFootL);

    // 8. Right Leg Joint Hierarchy
    charHipR = new THREE.Group();
    charHipR.position.set(0.12, -0.05, 0);
    charHips.add(charHipR);

    charThighR = new THREE.Group();
    const thighMeshR = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.32, 0.16), jeansMat);
    thighMeshR.position.set(0, -0.16, 0);
    thighMeshR.castShadow = true;
    charThighR.add(thighMeshR);
    charHipR.add(charThighR);

    charKneeR = new THREE.Group();
    charKneeR.position.set(0, -0.32, 0);
    charThighR.add(charKneeR);

    charCalfR = new THREE.Group();
    const calfMeshR = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.30, 0.15), jeansMat);
    calfMeshR.position.set(0, -0.15, 0);
    calfMeshR.castShadow = true;
    charCalfR.add(calfMeshR);
    charKneeR.add(charCalfR);

    charAnkleR = new THREE.Group();
    charAnkleR.position.set(0, -0.30, 0);
    charCalfR.add(charAnkleR);

    charFootR = new THREE.Group();
    const shoeR = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.10, 0.24), shoesMat);
    shoeR.position.set(0, -0.05, 0.04);
    shoeR.castShadow = true;
    charFootR.add(shoeR);
    charAnkleR.add(charFootR);

    scene.add(characterGroup);
  }


  // --- WIZARD CAT COMPANION (procedural 3D character) ---
  function buildWizardCat() {
    wizardCatGroup = new THREE.Group();
    wizardCatGroup.name = 'WizardCatCompanion';

    const fur = new THREE.MeshStandardMaterial({ color: 0x171321, roughness: 0.82 });
    const furLight = new THREE.MeshStandardMaterial({ color: 0x30243f, roughness: 0.78 });
    const robe = new THREE.MeshStandardMaterial({ color: 0x56318b, roughness: 0.72 });
    const gold = new THREE.MeshStandardMaterial({ color: 0xe7b94f, metalness: 0.55, roughness: 0.34 });
    const eye = new THREE.MeshStandardMaterial({ color: 0xffd86b, emissive: 0x6b4210, emissiveIntensity: 0.35 });
    const white = new THREE.MeshStandardMaterial({ color: 0xf7f0e8, roughness: 0.45 });
    const pink = new THREE.MeshStandardMaterial({ color: 0x9e607e, roughness: 0.8 });

    const addSphere = (parent, mat, scale, pos) => {
      const m = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 14), mat);
      m.scale.set(scale[0], scale[1], scale[2]);
      m.position.set(pos[0], pos[1], pos[2]);
      m.castShadow = !IS_MOBILE_DEVICE; m.receiveShadow = false; parent.add(m); return m;
    };
    const addBox = (parent, mat, size, pos) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(...size), mat);
      m.position.set(...pos); m.castShadow = true; parent.add(m); return m;
    };

    // Soft, compact body and robe
    addSphere(wizardCatGroup, fur, [0.31, 0.39, 0.25], [0, 0.48, 0]);
    const robeMesh = new THREE.Mesh(new THREE.ConeGeometry(0.43, 0.72, 8), robe);
    robeMesh.position.set(0, 0.39, 0); robeMesh.castShadow = !IS_MOBILE_DEVICE; wizardCatGroup.add(robeMesh);
    const robeHem = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.035, 8, 20), gold);
    robeHem.rotation.x = Math.PI / 2; robeHem.position.y = 0.08; wizardCatGroup.add(robeHem);

    // Head, muzzle, ears
    addSphere(wizardCatGroup, fur, [0.39, 0.34, 0.32], [0, 1.02, 0.02]);
    const earL = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.38, 4), fur);
    earL.position.set(-0.25, 1.34, 0.02); earL.rotation.z = 0.22; wizardCatGroup.add(earL);
    const earR = earL.clone(); earR.position.x = 0.25; earR.rotation.z = -0.22; wizardCatGroup.add(earR);
    addSphere(wizardCatGroup, pink, [0.065, 0.12, 0.025], [-0.25, 1.34, 0.10]);
    addSphere(wizardCatGroup, pink, [0.065, 0.12, 0.025], [0.25, 1.34, 0.10]);
    addSphere(wizardCatGroup, white, [0.105, 0.13, 0.045], [-0.14, 1.08, 0.30]);
    addSphere(wizardCatGroup, white, [0.105, 0.13, 0.045], [0.14, 1.08, 0.30]);
    addSphere(wizardCatGroup, eye, [0.052, 0.075, 0.026], [-0.13, 1.08, 0.342]);
    addSphere(wizardCatGroup, eye, [0.052, 0.075, 0.026], [0.15, 1.08, 0.342]);
    addSphere(wizardCatGroup, furLight, [0.13, 0.085, 0.08], [0, 0.94, 0.30]);
    addSphere(wizardCatGroup, pink, [0.045, 0.035, 0.025], [0, 0.99, 0.372]);

    // Whiskers
    for (let s of [-1, 1]) {
      for (let n = 0; n < 2; n++) {
        const whisker = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.24, 5), white);
        whisker.position.set(s * 0.22, 0.94 - n * 0.045, 0.30);
        whisker.rotation.z = s * (Math.PI / 2 + 0.15 * (n ? -1 : 1));
        wizardCatGroup.add(whisker);
      }
    }

    // Wizard hat: broad brim, pointed purple cone, gold band and star
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.07, 20), robe);
    brim.position.set(0, 1.34, 0.015); wizardCatGroup.add(brim);
    const hat = new THREE.Mesh(new THREE.ConeGeometry(0.27, 0.62, 9), robe);
    hat.position.set(0, 1.64, 0.015); hat.rotation.z = -0.13; hat.castShadow = !IS_MOBILE_DEVICE; wizardCatGroup.add(hat);
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.235, 0.025, 8, 18), gold);
    band.position.set(0, 1.48, 0.015); band.rotation.x = Math.PI / 2; wizardCatGroup.add(band);
    const hatStar = new THREE.Mesh(new THREE.OctahedronGeometry(0.09, 0), gold);
    hatStar.position.set(0.12, 1.72, 0.23); wizardCatGroup.add(hatStar);

    // Tiny arms and paws
    const armL = addSphere(wizardCatGroup, fur, [0.10, 0.23, 0.11], [-0.34, 0.58, 0.02]);
    armL.rotation.z = -0.38;
    const armR = addSphere(wizardCatGroup, fur, [0.10, 0.23, 0.11], [0.34, 0.58, 0.02]);
    armR.rotation.z = 0.38;
    addSphere(wizardCatGroup, furLight, [0.12, 0.09, 0.12], [-0.38, 0.39, 0.08]);
    addSphere(wizardCatGroup, furLight, [0.12, 0.09, 0.12], [0.38, 0.39, 0.08]);

    // Curled tail
    const tailCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.18, 0.20, -0.10),
      new THREE.Vector3(0.42, 0.12, -0.22),
      new THREE.Vector3(0.55, 0.28, -0.25),
      new THREE.Vector3(0.48, 0.43, -0.22)
    ]);
    const tail = new THREE.Mesh(new THREE.TubeGeometry(tailCurve, 16, 0.065, 8, false), fur);
    wizardCatGroup.add(tail);

    // Star wand held in the right paw
    const wand = new THREE.Group();
    wand.position.set(0.43, 0.47, 0.13);
    wand.rotation.z = -0.25;
    const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.035, 0.72, 8), gold);
    stick.position.y = 0.34; wand.add(stick);
    const starShape = new THREE.Shape();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + i * Math.PI / 5;
      const r = i % 2 === 0 ? 0.19 : 0.085;
      const x = Math.cos(a) * r, y = Math.sin(a) * r;
      if (i === 0) starShape.moveTo(x, y); else starShape.lineTo(x, y);
    }
    starShape.closePath();
    const star = new THREE.Mesh(new THREE.ShapeGeometry(starShape), new THREE.MeshStandardMaterial({
      color: 0xffdf75, emissive: 0xffb52e, emissiveIntensity: 0.8, side: THREE.DoubleSide
    }));
    star.position.set(0, 0.76, 0.02); wand.add(star);
    const starGlow = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 10),
      new THREE.MeshBasicMaterial({ color: 0xffd66b, transparent: true, opacity: 0.22 }));
    starGlow.position.copy(star.position); wand.add(starGlow);
    wizardCatStaff = wand; wizardCatGroup.add(wand);

    wizardCatGroup.scale.setScalar(0.92);
    wizardCatGroup.position.set(-2.25, 0.04, 14.1);
    wizardCatGroup.visible = false;
    scene.add(wizardCatGroup);
  }

  let catPrevPos = new THREE.Vector3();
  let catWanderAngle = 0;

  function updateWizardCat(dt, now) {
    if (!wizardCatGroup) return;
    if (state.inMainMenu) {
      wizardCatGroup.visible = false;
      return;
    }
    
    // During awakening cutscene, cutscene code manages visibility and positioning directly
    if (state.inCutscene) return;

    wizardCatGroup.visible = true;

    // Determine current room unlocked Z boundary so cat doesn't cross closed doors
    let minZAllowed = 8.6; // Bedroom exit default
    if (state.unlockedDoors.includes('door_bedroom_to_room1')) minZAllowed = -1.4;
    if (state.unlockedDoors.includes('door_room1_to_room2')) minZAllowed = -11.4;
    if (state.unlockedDoors.includes('door_room2_to_room3')) minZAllowed = -21.4;
    if (state.unlockedDoors.includes('door_room3_to_room4')) minZAllowed = -31.4;
    if (state.unlockedDoors.includes('door_room4_to_sanctuary')) minZAllowed = -60.0;

    const narrativeCard = document.getElementById('narrative-card');
    const isTalking = narrativeCard && narrativeCard.classList.contains('visible');

    let targetX, targetZ;

    if (isTalking) {
      // In dialogue: stand in front of Maya, gazing up at her respectfully
      const angle = characterFacingYaw;
      targetX = characterPos.x + Math.sin(angle) * 1.35;
      targetZ = characterPos.z + Math.cos(angle) * 1.35;
    } else {
      // Natural companion following: stay ~1.3m to Maya's side/rear
      const offsetAngle = characterFacingYaw + 2.4;
      targetX = characterPos.x + Math.sin(offsetAngle) * 1.35;
      targetZ = characterPos.z + Math.cos(offsetAngle) * 1.35;

      // Keep within house width bounds
      const halfWidth = (characterPos.z < -31.5) ? 8.2 : 4.4;
      targetX = Math.max(-halfWidth, Math.min(halfWidth, targetX));
    }

    // Clamp Z by current unlocked door
    targetZ = Math.max(minZAllowed, Math.min(18.0, targetZ));

    const prevX = wizardCatGroup.position.x;
    const prevZ = wizardCatGroup.position.z;

    const moveLerp = isTalking ? Math.min(1.0, dt * 3.5) : Math.min(1.0, dt * 2.2);
    wizardCatGroup.position.x += (targetX - wizardCatGroup.position.x) * moveLerp;
    wizardCatGroup.position.z += (targetZ - wizardCatGroup.position.z) * moveLerp;

    const dx = wizardCatGroup.position.x - prevX;
    const dz = wizardCatGroup.position.z - prevZ;
    const speed = Math.hypot(dx, dz) / Math.max(0.001, dt);

    if (isTalking) {
      // Face Maya directly during dialogue
      const toMayaX = characterPos.x - wizardCatGroup.position.x;
      const toMayaZ = characterPos.z - wizardCatGroup.position.z;
      wizardCatGroup.rotation.y = Math.atan2(toMayaX, toMayaZ);
      wizardCatGroup.position.y = 0.06 + Math.sin(now * 0.003) * 0.04;
      if (wizardCatStaff) wizardCatStaff.rotation.z = Math.sin(now * 0.004) * 0.15;
    } else if (speed > 0.12) {
      // Walking motion: gentle sway and paw steps
      const moveAngle = Math.atan2(dx, dz);
      wizardCatGroup.rotation.y = moveAngle;
      wizardCatGroup.rotation.z = Math.sin(now * 0.012) * 0.07;
      wizardCatGroup.position.y = 0.06 + Math.abs(Math.sin(now * 0.014)) * 0.07;
      if (wizardCatStaff) wizardCatStaff.rotation.z = Math.sin(now * 0.01) * 0.12;
    } else {
      // Idle: floating / breathing softly, scanning room
      wizardCatGroup.rotation.z *= 0.85;
      wizardCatGroup.position.y = 0.06 + Math.sin(now * 0.0028) * 0.045;
      if (wizardCatStaff) wizardCatStaff.rotation.z = Math.sin(now * 0.003) * 0.08;

      // When Maya is standing still, turn towards her gently
      const toMayaX = characterPos.x - wizardCatGroup.position.x;
      const toMayaZ = characterPos.z - wizardCatGroup.position.z;
      const targetFacing = Math.atan2(toMayaX, toMayaZ);
      let diff = targetFacing - wizardCatGroup.rotation.y;
      while (diff < -Math.PI) diff += Math.PI * 2;
      while (diff > Math.PI) diff -= Math.PI * 2;
      wizardCatGroup.rotation.y += diff * Math.min(1.0, dt * 2.5);
    }
  }

  function showCatRadioMessage(message, voiceFile) {
    const panel = document.getElementById('cat-radio-panel');
    const text = document.getElementById('cat-radio-text');
    if (!panel || state.inMainMenu || state.inCutscene) return;
    text.textContent = message;
    panel.classList.add('visible');
    catRadioVisible = true;
    if (voiceFile && window.soundEngine && window.soundEngine.playVoice) {
      window.soundEngine.playVoice('audio/voices/cat/' + voiceFile);
    }
    clearTimeout(catRadioTimer);
    catRadioTimer = setTimeout(() => {
      panel.classList.remove('visible');
      catRadioVisible = false;
    }, 7500);
  }

  function updateCatRoomPresence(roomName) {
    // Room entry messages are now handled systematically by triggerRoomIntroduction(roomId)
  }


  function updateCatPuzzleHints(now) {
    if (!catPuzzleStartedAt || !activeSafeType) return;
    const safeModal = document.getElementById('safe-modal');
    if (!safeModal || safeModal.style.display !== 'flex') return;
    const elapsed = (now - catPuzzleStartedAt) / 1000;
    if (elapsed >= 240 && catHintStage < 2) {
      catHintStage = 2;
      const message = activeSafeType === 'kitchen_safe'
        ? 'Dica mais direta: procure a anotação na cozinha e relacione os quatro números na ordem em que ela apresenta os objetos.'
        : 'Dica mais direta: a combinação está escondida na mensagem escrita no espelho embaçado. Use a sequência dos três elementos mencionados.';
      showCatRadioMessage(message, 'hint_02.mp3');
    } else if (elapsed >= 180 && catHintStage < 1) {
      catHintStage = 1;
      showCatRadioMessage('Já faz alguns minutos... Quer uma pista? Volte às anotações e observe os detalhes do cômodo. Eu prometo tentar não resolver tudo por você.', 'hint_01.mp3');
    }
  }

  // --- PLANAR REAL-TIME MIRROR REFLECTION SYSTEM ---
  function initPlanarMirrorReflection() {
    mirrorRenderTarget = new THREE.WebGLRenderTarget(IS_MOBILE_DEVICE ? 192 : 384, IS_MOBILE_DEVICE ? 192 : 384, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBFormat
    });

    mirrorCamera = new THREE.PerspectiveCamera(65, 1.4 / 1.8, 0.1, 50);
    scene.add(mirrorCamera);

    const mirrorGeom = new THREE.PlaneGeometry(1.4, 1.8);
    const uv = mirrorGeom.attributes.uv;
    for (let i = 0; i < uv.count; i++) {
      uv.setX(i, 1.0 - uv.getX(i));
    }
    uv.needsUpdate = true;

    const mirrorMat = new THREE.MeshBasicMaterial({
      map: mirrorRenderTarget.texture,
      color: 0xF0F9FF
    });

    mirrorGlassMesh = new THREE.Mesh(mirrorGeom, mirrorMat);
    mirrorGlassMesh.position.set(-4.83, 1.5, 14.5);
    mirrorGlassMesh.rotation.y = Math.PI / 2;
    scene.add(mirrorGlassMesh);
    bedroomMirrorMesh = mirrorGlassMesh;

    // Wood frame around mirror
    createBlock(0.1, 1.9, 0.08, 0x854D0E, { pos: [-4.84, 1.5, 13.76], material: PBR_MATERIALS.woodDark });
    createBlock(0.1, 1.9, 0.08, 0x854D0E, { pos: [-4.84, 1.5, 15.24], material: PBR_MATERIALS.woodDark });
    createBlock(0.1, 0.08, 1.56, 0x854D0E, { pos: [-4.84, 2.45, 14.5], material: PBR_MATERIALS.woodDark });
    createBlock(0.1, 0.08, 1.56, 0x854D0E, { pos: [-4.84, 0.55, 14.5], material: PBR_MATERIALS.woodDark });

    interactables.push({
      name: 'Espelho de Corpo Inteiro',
      pos: new THREE.Vector3(-4.3, 1.5, 14.5),
      action: () => inspectMemoryObject('bedroom_mirror')
    });
  }

  function renderPlanarMirrors() {
    if (!mirrorRenderTarget || !mirrorCamera || !mirrorGlassMesh) return;

    // A mirror requires a second full 3D render. Limit it to ~5 FPS on mobile
    // and ~10 FPS on desktop; the mirror still looks animated without rendering twice every frame.
    const mirrorNow = performance.now();
    const mirrorInterval = IS_MOBILE_DEVICE ? 200 : 100;
    if (mirrorNow - lastMirrorRenderAt < mirrorInterval) return;

    const mirrorX = -4.83;
    const distCam = camera.position.x - mirrorX;
    if (distCam <= 0.05 || distCam > 8.0 || Math.abs(camera.position.z - 14.5) > 6.0) {
      return;
    }

    mirrorCamera.position.set(
      2 * mirrorX - camera.position.x,
      camera.position.y,
      camera.position.z
    );

    const camDir = new THREE.Vector3();
    camera.getWorldDirection(camDir);
    const target = camera.position.clone().add(camDir.multiplyScalar(5.0));
    const refTarget = new THREE.Vector3(
      2 * mirrorX - target.x,
      target.y,
      target.z
    );

    mirrorCamera.lookAt(refTarget);
    mirrorCamera.up.set(0, 1, 0);
    lastMirrorRenderAt = mirrorNow;

    mirrorGlassMesh.visible = false;
    renderer.setRenderTarget(mirrorRenderTarget);
    renderer.clear();
    renderer.render(scene, mirrorCamera);
    renderer.setRenderTarget(null);
    mirrorGlassMesh.visible = true;
  }

  // --- PHYSICAL REACHING INTERACTION SYSTEM ---
  function triggerPhysicalReach(targetWorldPos, onContact) {
    if (isReaching) return;
    isReaching = true;
    reachTimer = 0;
    reachCallback = onContact;

    if (targetWorldPos) {
      const dx = targetWorldPos.x - characterPos.x;
      const dz = targetWorldPos.z - characterPos.z;
      characterFacingYaw = Math.atan2(dx, dz);
    }
  }

  // --- ENVIRONMENTAL LIFE & ANIMATION ---
  function animateEnvironments(dt) {
    const time = performance.now() * 0.001;

    animatedCurtains.forEach(c => {
      c.mesh.rotation.z = Math.sin(time * 1.6 + c.phase) * 0.04;
    });

    animatedPlants.forEach(p => {
      p.mesh.rotation.x = Math.sin(time * 1.8 + p.phase) * 0.035;
    });

    if (dustMotesGroup) {
      dustMotesGroup.children.forEach(mote => {
        mote.position.y += dt * 0.12;
        if (mote.position.y > 2.6) mote.position.y = 0.4;
        mote.position.x += Math.sin(time + mote.position.z) * 0.002;
      });
    }
  }

  // --- SKY, SUN & CLOUDS ---
  function buildSkyAndSun() {
    const sunGeom = new THREE.BoxGeometry(4.5, 4.5, 4.5);
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xFDE047 });
    sunMesh = new THREE.Mesh(sunGeom, sunMat);
    sunMesh.position.set(20, 28, -26);
    scene.add(sunMesh);

    const haloGeom = new THREE.BoxGeometry(6, 6, 6);
    const haloMat = new THREE.MeshBasicMaterial({ color: 0xFEF08A, transparent: true, opacity: 0.35 });
    sunMesh.add(new THREE.Mesh(haloGeom, haloMat));

    // Voxel Clouds
    const cloudMat = new THREE.MeshLambertMaterial({ color: 0xFFFFFF, transparent: true, opacity: 0.9 });
    for (let i = 0; i < 8; i++) {
      const cloud = new THREE.Group();
      const numBlocks = 4 + Math.floor(Math.random() * 4);
      for (let b = 0; b < numBlocks; b++) {
        const cw = 4 + Math.random() * 4;
        const ch = 1.8 + Math.random() * 1.2;
        const cd = 3 + Math.random() * 3;
        const cm = new THREE.Mesh(new THREE.BoxGeometry(cw, ch, cd), cloudMat);
        cm.position.set((b - numBlocks / 2) * 2.8, (Math.random() - 0.5) * 0.8, (Math.random() - 0.5) * 2);
        cloud.add(cm);
      }
      cloud.position.set((Math.random() - 0.5) * 80, 22 + Math.random() * 6, (Math.random() - 0.5) * 80);
      scene.add(cloud);
    }
  }

  // --- OUTDOOR SCENERY ---
  function buildOutdoorScenery() {
    // Vast lawn spanning the entire linear house length
    const lawnGeom = new THREE.BoxGeometry(90, 0.4, 125);
    const lawnMat = new THREE.MeshLambertMaterial({ color: 0x4ADE80 });
    const lawn = new THREE.Mesh(lawnGeom, lawnMat);
    lawn.position.set(0, -0.2, -22);
    lawn.receiveShadow = true;
    scene.add(lawn);

    // Voxel trees flanking both sides of the linear house and behind the Grand Sanctuary
    const treePositions = [
      // Left side along Z
      [-14, 18], [-18, 12], [-14, 4], [-18, -4], [-14, -12], [-18, -20], [-14, -28], [-18, -38], [-20, -50], [-18, -62],
      // Right side along Z
      [14, 18], [18, 12], [14, 4], [18, -4], [14, -12], [18, -20], [14, -28], [18, -38], [20, -50], [18, -62],
      // Back landscape behind Grand Sanctuary (visible through 12m arched window at Z = -61.5)
      [-10, -72], [-4, -76], [4, -76], [10, -72], [0, -82], [-14, -78], [14, -78]
    ];
    treePositions.forEach(([tx, tz]) => {
      buildVoxelTree(tx, tz);
    });
  }

  function buildVoxelTree(x, z) {
    const trunkMat = new THREE.MeshLambertMaterial({ color: 0x854D0E });
    const leavesMat = new THREE.MeshLambertMaterial({ color: 0x16A34A });

    const trunk = new THREE.Mesh(new THREE.BoxGeometry(0.8, 3.5, 0.8), trunkMat);
    trunk.position.set(x, 1.75, z);
    trunk.castShadow = true;
    scene.add(trunk);
    colliders.push(new THREE.Box3().setFromObject(trunk));

    const leavesBottom = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.6, 3.2), leavesMat);
    leavesBottom.position.set(x, 4.0, z);
    leavesBottom.castShadow = true;
    scene.add(leavesBottom);

    const leavesTop = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.4, 2.0), leavesMat);
    leavesTop.position.set(x, 5.2, z);
    leavesTop.castShadow = true;
    scene.add(leavesTop);
  }

  // --- DYNAMIC LIGHTING & FUNCTIONAL LAMPS SYSTEM ---
  const dynamicLamps = [];
  const LampManager = {
    addLamp: function (options) {
      const group = new THREE.Group();
      const pos = options.pos || [0, 1.5, 0];
      group.position.set(pos[0], pos[1], pos[2]);

      const lightColor = options.color || 0xFDE68A;
      const maxIntensity = options.intensity !== undefined ? options.intensity : 1.4;
      const distance = options.distance !== undefined ? options.distance : 8.5;

      // Real Three.js PointLight that illuminates nearby geometry
      const pointLight = new THREE.PointLight(lightColor, maxIntensity, distance, 1.8);
      pointLight.position.set(0, 0, 0);
      pointLight.castShadow = false;
      group.add(pointLight);

      // Emissive bulb / core geometry
      const bulbGeom = new THREE.BoxGeometry(0.14, 0.14, 0.14);
      const bulbMat = new THREE.MeshStandardMaterial({
        color: lightColor,
        emissive: lightColor,
        emissiveIntensity: 1.0,
        roughness: 0.15,
        metalness: 0.1
      });
      const bulbMesh = new THREE.Mesh(bulbGeom, bulbMat);
      group.add(bulbMesh);

      // Model detailed fixture housing based on type
      if (options.type === 'bedside' || options.type === 'table') {
        const base = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.04, 0.24), PBR_MATERIALS.metalBrass);
        base.position.set(0, -0.22, 0);
        group.add(base);
        const stem = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.26, 0.04), PBR_MATERIALS.metalBrass);
        stem.position.set(0, -0.09, 0);
        group.add(stem);
        const shade = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.26, 0.36), PBR_MATERIALS.fabricWhite);
        shade.position.set(0, 0.04, 0);
        group.add(shade);
      } else if (options.type === 'floor') {
        const base = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.08, 0.48), PBR_MATERIALS.metalBrass);
        base.position.set(0, -2.25, 0);
        group.add(base);
        const pole = new THREE.Mesh(new THREE.BoxGeometry(0.06, 2.3, 0.06), PBR_MATERIALS.metalBrass);
        pole.position.set(0, -1.1, 0);
        group.add(pole);
        const shade = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.38, 0.46), PBR_MATERIALS.fabricWhite);
        shade.position.set(0, 0.05, 0);
        group.add(shade);
      } else if (options.type === 'ceiling') {
        const mount = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.04, 0.28), PBR_MATERIALS.metalChrome);
        mount.position.set(0, 0.18, 0);
        group.add(mount);
        const cord = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.22, 0.03), new THREE.MeshBasicMaterial({ color: 0x1E293B }));
        cord.position.set(0, 0.07, 0);
        group.add(cord);
        const shade = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.18, 0.58), PBR_MATERIALS.metalChrome);
        shade.position.set(0, -0.05, 0);
        group.add(shade);
      } else if (options.type === 'sconce') {
        const backplate = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.24, 0.04), PBR_MATERIALS.metalChrome);
        backplate.position.set(0, 0, -0.1);
        group.add(backplate);
        const shade = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.18, 0.18), PBR_MATERIALS.fabricWhite);
        group.add(shade);
      }

      scene.add(group);

      const lampObj = {
        name: options.name || 'Lamp',
        group: group,
        light: pointLight,
        bulbMesh: bulbMesh,
        isOn: options.initialOn !== false,
        maxIntensity: maxIntensity,
        targetIntensity: options.initialOn !== false ? maxIntensity : 0.0
      };

      if (options.toggleable) {
        interactables.push({
          name: options.name || 'Lamp',
          pos: new THREE.Vector3(pos[0], pos[1], pos[2]),
          action: () => {
            lampObj.isOn = !lampObj.isOn;
            lampObj.targetIntensity = lampObj.isOn ? lampObj.maxIntensity : 0.0;
            window.soundEngine.playClick();
            showToast(`${lampObj.name}: ${lampObj.isOn ? 'Switched ON' : 'Switched OFF'}`);
          }
        });
      }

      dynamicLamps.push(lampObj);
      return lampObj;
    },

    update: function (dt) {
      for (let i = 0; i < dynamicLamps.length; i++) {
        const lamp = dynamicLamps[i];
        lamp.light.intensity = THREE.MathUtils.lerp(
          lamp.light.intensity,
          lamp.targetIntensity,
          dt * 7.5
        );
        const ratio = lamp.maxIntensity > 0 ? (lamp.light.intensity / lamp.maxIntensity) : 0;
        lamp.bulbMesh.material.emissiveIntensity = ratio;
      }
    }
  };

  // Block Helper with PBR Material Support
  function createBlock(w, h, d, color, options = {}) {
    let mat = options.material;
    if (!mat) {
      if (options.transparent) {
        mat = new THREE.MeshStandardMaterial({
          color: color,
          transparent: true,
          opacity: options.opacity !== undefined ? options.opacity : 0.5,
          roughness: 0.1,
          metalness: 0.1
        });
      } else {
        mat = new THREE.MeshStandardMaterial({
          color: color,
          roughness: options.roughness !== undefined ? options.roughness : 0.55,
          metalness: options.metalness !== undefined ? options.metalness : 0.05
        });
      }
    }
    const geom = new THREE.BoxGeometry(w, h, d);
    const mesh = new THREE.Mesh(geom, mat);
    if (options.pos) mesh.position.set(options.pos[0], options.pos[1], options.pos[2]);
    if (options.rot) mesh.rotation.set(options.rot[0], options.rot[1], options.rot[2]);
    mesh.castShadow = options.castShadow !== false;
    mesh.receiveShadow = options.receiveShadow !== false;
    scene.add(mesh);

    if (options.collider) {
      colliders.push(new THREE.Box3().setFromObject(mesh));
    }
    return mesh;
  }

  function removeCollider(box) {
    const idx = colliders.indexOf(box);
    if (idx !== -1) colliders.splice(idx, 1);
  }

  // --- LINEAR HOUSE ARCHITECTURE & DETAILED MEMORY ROOMS ---
  const linearDoors = {};
  let bedroomDrawerMesh;

  function registerLinearDoor(id, group, collider, isDouble = false, rightGroup = null, rightCollider = null) {
    linearDoors[id] = {
      id: id,
      group: group,
      collider: collider,
      isDouble: isDouble,
      rightGroup: rightGroup,
      rightCollider: rightCollider,
      isOpen: false
    };
  }

  function openLinearDoor(doorId, playSound = true) {
    const door = linearDoors[doorId];
    if (!door || door.isOpen) return;
    door.isOpen = true;
    if (!state.unlockedDoors.includes(doorId)) {
      state.unlockedDoors.push(doorId);
    }
    animDoors.push({
      obj: door.group,
      targetRot: Math.PI / 2
    });
    if (door.collider) removeCollider(door.collider);
    if (door.isDouble && door.rightGroup) {
      animDoors.push({
        obj: door.rightGroup,
        targetRot: -Math.PI / 2
      });
      if (door.rightCollider) removeCollider(door.rightCollider);
    }
    if (playSound && window.soundEngine && window.soundEngine.playDoor) {
      window.soundEngine.playDoor();
    }
    saveGame();
  }

  function restoreUnlockedDoor(doorId) {
    const door = linearDoors[doorId];
    if (!door) return;
    door.isOpen = true;
    door.group.rotation.y = Math.PI / 2;
    if (door.collider) removeCollider(door.collider);
    if (door.isDouble && door.rightGroup) {
      door.rightGroup.rotation.y = -Math.PI / 2;
      if (door.rightCollider) removeCollider(door.rightCollider);
    }
  }

  function buildModernHouse() {
    const wallColor = 0xF5F0F8;
    const ceilingColor = 0xFAF5FF;
    const glassColor = 0xC8DDF5;

    // --- LINEAR FLOORS (ALIGNED ON Z AXIS FROM +18.5 DOWN TO -61.5) ---
    // Initial Bedroom (Z: 8.5 to 18.5, Center 13.5)
    createBlock(10, 0.2, 10, 0x5C4033, { pos: [0, 0, 13.5], receiveShadow: true, material: PBR_MATERIALS.bedroomFloor });
    // Room 1: Biblioteca de Antiquidades (Z: -1.5 to 8.5, Center 3.5)
    createBlock(10, 0.2, 10, 0xD4A373, { pos: [0, 0, 3.5], receiveShadow: true, material: PBR_MATERIALS.parquetFloor });
    // Room 2: Jardim de Inverno & Chá (Z: -11.5 to -1.5, Center -6.5)
    createBlock(10, 0.2, 10, 0xB45309, { pos: [0, 0, -6.5], receiveShadow: true, material: PBR_MATERIALS.tileKitchen });
    // Room 3: Ateliê de Música (Z: -21.5 to -11.5, Center -16.5)
    createBlock(10, 0.2, 10, 0x3E2723, { pos: [0, 0, -16.5], receiveShadow: true, material: PBR_MATERIALS.woodDark });
    // Room 4: Observatório Celestial (Z: -31.5 to -21.5, Center -26.5)
    createBlock(10, 0.2, 10, 0x1E1B4B, { pos: [0, 0, -26.5], receiveShadow: true, material: PBR_MATERIALS.tileBathroom });
    // Grande Sala Final: Santuário das Memórias (Z: -61.5 to -31.5, Center -46.5, Width 18m, Length 30m)
    createBlock(18, 0.2, 30, 0xEDE9FE, { pos: [0, 0, -46.5], receiveShadow: true, material: PBR_MATERIALS.fabricWhite });
    // Central golden runner along Grand Hall nave
    createBlock(3.6, 0.015, 30, 0xFBBF24, { pos: [0, 0.11, -46.5], material: PBR_MATERIALS.metalBrass });

    // --- CEILINGS ---
    createBlock(10, 0.2, 10, ceilingColor, { pos: [0, 3.8, 13.5] }); // Bedroom
    createBlock(10, 0.2, 10, ceilingColor, { pos: [0, 3.8, 3.5] });  // Room 1
    createBlock(10, 0.15, 10, glassColor, { pos: [0, 3.8, -6.5], transparent: true, opacity: 0.45 }); // Room 2 Glass Roof
    createBlock(10, 0.2, 10, ceilingColor, { pos: [0, 3.8, -16.5] }); // Room 3
    createBlock(10, 0.2, 10, 0x1E1B4B, { pos: [0, 3.8, -26.5] }); // Room 4
    // High Grand Hall Vaulted Ceiling (Height 7.0m!)
    createBlock(18, 0.25, 30, 0xF5F3FF, { pos: [0, 7.0, -46.5] });
    createBlock(6.0, 0.1, 26, glassColor, { pos: [0, 7.0, -46.5], transparent: true, opacity: 0.55 });

    // --- EXTERIOR WALLS & VIEWING WINDOWS (CONTINUOUS LINEAR CORRIDOR) ---
    // North Bedroom Wall (Z = 18.5)
    createBlock(10, 3.8, 0.3, wallColor, { pos: [0, 1.9, 18.5], collider: true });

    // West Exterior Walls & Windows (X = -5.0 from Z = 18.5 to -31.5)
    for (let r = 0; r < 5; r++) {
      const zC = 13.5 - r * 10;
      createBlock(0.3, 3.8, 3.0, wallColor, { pos: [-5.0, 1.9, zC + 3.5], collider: true });
      createBlock(0.3, 3.8, 3.0, wallColor, { pos: [-5.0, 1.9, zC - 3.5], collider: true });
      createBlock(0.1, 3.8, 4.0, glassColor, { pos: [-5.0, 1.9, zC], transparent: true, opacity: 0.35, collider: true });
      createBlock(0.15, 3.8, 0.1, 0x334155, { pos: [-5.0, 1.9, zC - 1.0] });
      createBlock(0.15, 3.8, 0.1, 0x334155, { pos: [-5.0, 1.9, zC + 1.0] });
      createBlock(0.15, 0.1, 4.0, 0x334155, { pos: [-5.0, 1.9, zC] });
    }

    // East Exterior Walls & Windows (X = 5.0 from Z = 18.5 to -31.5)
    for (let r = 0; r < 5; r++) {
      const zC = 13.5 - r * 10;
      createBlock(0.3, 3.8, 3.0, wallColor, { pos: [5.0, 1.9, zC + 3.5], collider: true });
      createBlock(0.3, 3.8, 3.0, wallColor, { pos: [5.0, 1.9, zC - 3.5], collider: true });
      createBlock(0.1, 3.8, 4.0, glassColor, { pos: [5.0, 1.9, zC], transparent: true, opacity: 0.35, collider: true });
      createBlock(0.15, 3.8, 0.1, 0x334155, { pos: [5.0, 1.9, zC - 1.0] });
      createBlock(0.15, 3.8, 0.1, 0x334155, { pos: [5.0, 1.9, zC + 1.0] });
      createBlock(0.15, 0.1, 4.0, 0x334155, { pos: [5.0, 1.9, zC] });
    }

    // Grand Sanctuary Walls (X = -9.0 and X = 9.0, Height 7.0m, Z: -31.5 to -61.5)
    createBlock(0.3, 7.0, 30, 0xF5F3FF, { pos: [-9.0, 3.5, -46.5], collider: true });
    createBlock(0.3, 7.0, 30, 0xF5F3FF, { pos: [9.0, 3.5, -46.5], collider: true });
    // Far North Wall of Grand Sanctuary (Z = -61.5) with Colossal Panoramic Sunset Window
    createBlock(3.0, 7.0, 0.3, 0xF5F3FF, { pos: [-7.5, 3.5, -61.5], collider: true });
    createBlock(3.0, 7.0, 0.3, 0xF5F3FF, { pos: [7.5, 3.5, -61.5], collider: true });
    createBlock(12.0, 1.8, 0.3, 0xF5F3FF, { pos: [0, 6.1, -61.5] });
    createBlock(12.0, 5.2, 0.12, glassColor, { pos: [0, 2.6, -61.5], transparent: true, opacity: 0.45, collider: true });

    // --- PARTITION WALLS & DOORWAYS ---
    buildPartitionWalls();
    buildFunctionalDoors();

    // --- AMBIENT CEILING LAMPS ---
    LampManager.addLamp({
      name: 'Bedroom Ceiling Lamp',
      type: 'ceiling',
      pos: [0, 3.55, 13.5],
      color: 0xFEF3C7,
      intensity: 1.5,
      distance: 13.0
    });
    LampManager.addLamp({
      name: 'Library Chandelier',
      type: 'ceiling',
      pos: [0, 3.55, 3.5],
      color: 0xFDE68A,
      intensity: 1.5,
      distance: 13.0
    });
    LampManager.addLamp({
      name: 'Garden Sun Chandelier',
      type: 'ceiling',
      pos: [0, 3.55, -6.5],
      color: 0xFEF3C7,
      intensity: 1.6,
      distance: 14.0
    });
    LampManager.addLamp({
      name: 'Atelier Brass Pendant',
      type: 'ceiling',
      pos: [0, 3.55, -16.5],
      color: 0xFED7AA,
      intensity: 1.5,
      distance: 13.0
    });
    LampManager.addLamp({
      name: 'Observatory Starlight Beacon',
      type: 'ceiling',
      pos: [0, 3.55, -26.5],
      color: 0xE0E7FF,
      intensity: 1.6,
      distance: 14.0
    });
    LampManager.addLamp({
      name: 'Grand Sanctuary Celestial Aura',
      type: 'ceiling',
      pos: [0, 6.5, -46.5],
      color: 0xF3E8FF,
      intensity: 2.2,
      distance: 26.0
    });

    // Build details for all rooms!
    buildBedroomDetails();
    buildLibraryDetails();
    buildGardenDetails();
    buildAtelierDetails();
    buildObservatoryDetails();
    buildGrandSanctuaryDetails();
  }

  function buildPartitionWalls() {
    const wallColor = 0xF5F0F8;
    // 1. Bedroom <-> Room 1 (Z: 8.5)
    createBlock(3.9, 3.8, 0.3, wallColor, { pos: [-3.05, 1.9, 8.5], collider: true });
    createBlock(3.9, 3.8, 0.3, wallColor, { pos: [3.05, 1.9, 8.5], collider: true });
    createBlock(2.2, 1.2, 0.3, wallColor, { pos: [0, 3.2, 8.5] });

    // 2. Room 1 <-> Room 2 (Z: -1.5)
    createBlock(3.9, 3.8, 0.3, wallColor, { pos: [-3.05, 1.9, -1.5], collider: true });
    createBlock(3.9, 3.8, 0.3, wallColor, { pos: [3.05, 1.9, -1.5], collider: true });
    createBlock(2.2, 1.2, 0.3, wallColor, { pos: [0, 3.2, -1.5] });

    // 3. Room 2 <-> Room 3 (Z: -11.5)
    createBlock(3.9, 3.8, 0.3, wallColor, { pos: [-3.05, 1.9, -11.5], collider: true });
    createBlock(3.9, 3.8, 0.3, wallColor, { pos: [3.05, 1.9, -11.5], collider: true });
    createBlock(2.2, 1.2, 0.3, wallColor, { pos: [0, 3.2, -11.5] });

    // 4. Room 3 <-> Room 4 (Z: -21.5)
    createBlock(3.9, 3.8, 0.3, wallColor, { pos: [-3.05, 1.9, -21.5], collider: true });
    createBlock(3.9, 3.8, 0.3, wallColor, { pos: [3.05, 1.9, -21.5], collider: true });
    createBlock(2.2, 1.2, 0.3, wallColor, { pos: [0, 3.2, -21.5] });

    // 5. Room 4 <-> Grand Sanctuary (Z: -31.5) - Expanding archway into grand hall
    createBlock(7.2, 7.0, 0.4, 0xF5F3FF, { pos: [-5.4, 3.5, -31.5], collider: true });
    createBlock(7.2, 7.0, 0.4, 0xF5F3FF, { pos: [5.4, 3.5, -31.5], collider: true });
    createBlock(3.6, 2.6, 0.4, 0xF5F3FF, { pos: [0, 5.7, -31.5] });
  }

  function buildFunctionalDoors() {
    function createDoor(doorId, zPos, name) {
      const doorGroup = new THREE.Group();
      doorGroup.position.set(-1.1, 0, zPos);

      const doorPanel = new THREE.Mesh(
        new THREE.BoxGeometry(2.2, 2.6, 0.12),
        new THREE.MeshLambertMaterial({ color: 0x6B4B3E })
      );
      doorPanel.position.set(1.1, 1.3, 0);
      doorPanel.castShadow = true;
      doorGroup.add(doorPanel);

      const handle = new THREE.Mesh(
        new THREE.BoxGeometry(0.14, 0.08, 0.22),
        new THREE.MeshLambertMaterial({ color: 0xF59E0B })
      );
      handle.position.set(2.0, 1.3, 0);
      doorGroup.add(handle);

      scene.add(doorGroup);

      const collider = new THREE.Box3(
        new THREE.Vector3(-1.1, 0, zPos - 0.15),
        new THREE.Vector3(1.1, 2.6, zPos + 0.15)
      );
      colliders.push(collider);

      registerLinearDoor(doorId, doorGroup, collider);

      interactables.push({
        name: name,
        pos: new THREE.Vector3(0, 1.3, zPos),
        action: () => {
          const door = linearDoors[doorId];
          if (!door) return;
          if (!door.isOpen) {
            const room = MEMORIES_CONFIG.find(r => r.doorId === doorId);
            if (room) {
              const remaining = room.mandatoryObjectIds.filter(id => !state.inspectedObjects.includes(id));
              if (remaining.length > 0) {
                showNarrativeCard('GATO FEITICEIRO', room.name, [
                  `Esta porta continua selada pelas memórias.`,
                  `Ainda precisamos observar ${remaining.length} elemento(s) essencial(is) neste cômodo para que o caminho se abra.`
                ]);
                if (window.soundEngine && window.soundEngine.playSafeError) {
                  window.soundEngine.playSafeError();
                }
                return;
              }
            }
            openLinearDoor(doorId);
          }
        }
      });
    }

    // 1. Bedroom Door (Z: 8.5)
    createDoor('door_bedroom', 8.5, 'Porta do Quarto das Origens');
    // 2. Room 1 Door (Z: -1.5)
    createDoor('door_room1', -1.5, 'Porta da Biblioteca');
    // 3. Room 2 Door (Z: -11.5)
    createDoor('door_room2', -11.5, 'Porta do Jardim de Inverno');
    // 4. Room 3 Door (Z: -21.5)
    createDoor('door_room3', -21.5, 'Porta do Ateliê de Música');

    // 5. Room 4 Grand Portal (Z: -31.5) - Double grand doors to Sanctuary
    const doubleLeft = new THREE.Group();
    doubleLeft.position.set(-1.8, 0, -31.5);
    const leftPanel = new THREE.Mesh(
      new THREE.BoxGeometry(1.8, 4.4, 0.18),
      new THREE.MeshLambertMaterial({ color: 0x4C1D95 })
    );
    leftPanel.position.set(0.9, 2.2, 0);
    doubleLeft.add(leftPanel);
    scene.add(doubleLeft);

    const doubleRight = new THREE.Group();
    doubleRight.position.set(1.8, 0, -31.5);
    const rightPanel = new THREE.Mesh(
      new THREE.BoxGeometry(1.8, 4.4, 0.18),
      new THREE.MeshLambertMaterial({ color: 0x4C1D95 })
    );
    rightPanel.position.set(-0.9, 2.2, 0);
    doubleRight.add(rightPanel);
    scene.add(doubleRight);

    const colliderLeft = new THREE.Box3(
      new THREE.Vector3(-1.8, 0, -31.65),
      new THREE.Vector3(0, 4.4, -31.35)
    );
    const colliderRight = new THREE.Box3(
      new THREE.Vector3(0, 0, -31.65),
      new THREE.Vector3(1.8, 4.4, -31.35)
    );
    colliders.push(colliderLeft);
    colliders.push(colliderRight);

    registerLinearDoor('door_room4', doubleLeft, colliderLeft, true, doubleRight, colliderRight);

    interactables.push({
      name: 'Portal do Grande Santuário',
      pos: new THREE.Vector3(0, 2.2, -31.5),
      action: () => {
        const door = linearDoors['door_room4'];
        if (!door) return;
        if (!door.isOpen) {
          const room = MEMORIES_CONFIG.find(r => r.doorId === 'door_room4');
          if (room) {
            const remaining = room.mandatoryObjectIds.filter(id => !state.inspectedObjects.includes(id));
            if (remaining.length > 0) {
              showNarrativeCard('GATO FEITICEIRO', room.name, [
                `O grande portal do Santuário permanece resguardado.`,
                `Examine todos os instrumentos astronômicos deste observatório primeiro.`
              ]);
              if (window.soundEngine && window.soundEngine.playSafeError) {
                window.soundEngine.playSafeError();
              }
              return;
            }
          }
          openLinearDoor('door_room4');
        }
      }
    });
  }

  // --- DETAILED BEDROOM REDESIGN ---
  function buildBedroomDetails() {
    // 1. Cozy Scandinavian Floor Rug
    createBlock(5.2, 0.02, 4.8, 0xF8FAFC, { pos: [0, 0.02, 14.0], material: PBR_MATERIALS.fabricWhite });
    createBlock(5.4, 0.015, 5.0, 0xD4A373, { pos: [0, 0.015, 14.0], material: PBR_MATERIALS.woodOak });

    // 2. High-Detail Bed (Maya's bed with separate frame, mattress, duvet, cushions & headboard)
    // Wooden headboard with upholstered back cushion panel
    createBlock(3.2, 1.3, 0.25, 0x5C4033, { pos: [0, 1.15, 17.3], collider: true, material: PBR_MATERIALS.woodDark });
    createBlock(2.8, 0.9, 0.1, 0xA7F3D0, { pos: [0, 1.25, 17.15], material: PBR_MATERIALS.fabricMint });

    // Raised bed frame with legs
    createBlock(3.0, 0.35, 3.5, 0x5C4033, { pos: [0, 0.22, 15.4], collider: true, material: PBR_MATERIALS.woodDark });
    // Plush mattress
    createBlock(2.8, 0.35, 3.3, 0xF8FAFC, { pos: [0, 0.55, 15.3], material: PBR_MATERIALS.fabricWhite });
    // Folded emerald quilted duvet / blanket
    bedroomDuvetMesh = createBlock(2.8, 0.35, 2.4, 0x059669, { pos: [0, 0.58, 16.0], material: PBR_MATERIALS.fabricEmerald });
    // Mint duvet fold trim
    createBlock(2.82, 0.12, 0.45, 0xA7F3D0, { pos: [0, 0.72, 14.9], material: PBR_MATERIALS.fabricMint });

    // Pillows & Accent Cushions
    createBlock(0.9, 0.22, 0.55, 0xFFFFFF, { pos: [-0.8, 0.82, 16.6], material: PBR_MATERIALS.fabricWhite }); // Left pillow
    createBlock(0.9, 0.22, 0.55, 0xFFFFFF, { pos: [0.8, 0.82, 16.6], material: PBR_MATERIALS.fabricWhite }); // Right pillow
    createBlock(0.6, 0.25, 0.3, 0xFDE68A, { pos: [-0.75, 0.86, 16.2] }); // Left mustard accent cushion
    createBlock(0.6, 0.25, 0.3, 0xF472B6, { pos: [0.75, 0.86, 16.2] }); // Right dusty rose accent cushion

    // 3. Left Nightstand (Mid-century table beside pillow with Bedside Lamp & Key!)
    createBlock(0.85, 0.7, 0.85, 0x5C4033, { pos: [-2.2, 0.35, 14.0], collider: true, material: PBR_MATERIALS.woodDark });
    createBlock(0.88, 0.05, 0.88, 0xD4A373, { pos: [-2.2, 0.725, 14.0], material: PBR_MATERIALS.woodOak });
    bedroomDrawerMesh = createBlock(0.72, 0.24, 0.65, 0xD4A373, { pos: [-2.2, 0.35, 14.3], material: PBR_MATERIALS.woodOak });
    const leftDrawerKnob = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.04, 0.06), PBR_MATERIALS.metalBrass);
    leftDrawerKnob.position.set(-2.2, 0.35, 14.65);
    scene.add(leftDrawerKnob);

    // Bedside Reading Lamp (Dynamic PointLight, Warm Golden Light, Toggleable)
    LampManager.addLamp({
      name: 'Bedside Reading Lamp',
      type: 'bedside',
      pos: [-2.35, 1.0, 13.85],
      color: 0xFDE68A,
      intensity: 1.35,
      distance: 7.5,
      toggleable: true
    });

    // Books & Diary on Nightstand
    createBlock(0.35, 0.06, 0.45, 0x92400E, { pos: [-2.2, 0.78, 14.3] });
    interactables.push({
      name: 'Nightstand Diary',
      pos: new THREE.Vector3(-2.2, 0.8, 14.3),
      action: () => {
        state.flags.bedroomDrawerOpen = !state.flags.bedroomDrawerOpen;
        animDrawers.push({
          obj: bedroomDrawerMesh,
          axis: 'z',
          target: state.flags.bedroomDrawerOpen ? 14.9 : 14.3
        });
        window.soundEngine.playDrawer();
        if (state.flags.bedroomDrawerOpen) {
          triggerNoteDialogue('bedroom_diary');
        }
      }
    });

    // 4. CRITICAL: 3D Solid Brass Bedroom Key on Bedside Nightstand
    if (!state.flags.bedroomDoorUnlocked && !hasItem('bedroom_key')) {
      const keyGroup = new THREE.Group();
      keyGroup.position.set(-2.0, 0.77, 14.05);

      const keyBow = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.03, 0.12), PBR_MATERIALS.metalBrass);
      keyGroup.add(keyBow);
      const keyStem = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.025, 0.16), PBR_MATERIALS.metalBrass);
      keyStem.position.set(0, 0, 0.11);
      keyGroup.add(keyStem);
      const keyBit = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.04, 0.04), PBR_MATERIALS.metalBrass);
      keyBit.position.set(0.03, -0.01, 0.16);
      keyGroup.add(keyBit);

      scene.add(keyGroup);
      bedroomKeyMesh = keyGroup;

      interactables.push({
        name: 'Take Bedroom Key',
        pos: new THREE.Vector3(-2.0, 0.78, 14.05),
        action: () => {
          if (!hasItem('bedroom_key') && !state.flags.bedroomDoorUnlocked) {
            triggerPhysicalReach(new THREE.Vector3(-2.0, 0.78, 14.05), () => {
              addItem('bedroom_key', '🔑', 'Bedroom Key', 'Solid brass key found on your bedside nightstand. Unlocks the bedroom door.');
              if (bedroomKeyMesh) {
                scene.remove(bedroomKeyMesh);
                bedroomKeyMesh = null;
              }
              showCinematicDialogue('Maya', [
                'Found the Bedroom Key! It was resting right here on my bedside nightstand.',
                'Now I can unlock the bedroom door and explore the house.'
              ]);
              window.soundEngine.playItemPickup();
            });
          }
        }
      });
    }

    // 5. Right Nightstand (With carafe, tumbler and succulent)
    createBlock(0.85, 0.7, 0.85, 0x5C4033, { pos: [2.2, 0.35, 14.0], collider: true, material: PBR_MATERIALS.woodDark });
    createBlock(0.88, 0.05, 0.88, 0xD4A373, { pos: [2.2, 0.725, 14.0], material: PBR_MATERIALS.woodOak });
    // Glass water carafe & tumbler
    createBlock(0.12, 0.24, 0.12, 0xBAE6FD, { pos: [2.15, 0.88, 14.15], transparent: true, opacity: 0.65 });
    createBlock(0.08, 0.14, 0.08, 0xBAE6FD, { pos: [2.35, 0.82, 14.15], transparent: true, opacity: 0.65 });
    // Potted Succulent Plant
    const pot = createBlock(0.18, 0.16, 0.18, 0xFFFFFF, { pos: [2.25, 0.83, 13.8] });
    const succulentMat = new THREE.MeshLambertMaterial({ color: 0x10B981 });
    const succ1 = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.14, 0.16), succulentMat);
    succ1.position.set(2.25, 0.98, 13.8);
    scene.add(succ1);

    // 6. Full-Sized Clothing Wardrobe (Decorative, non-interactive, realistic 3-door wardrobe)
    // Beautiful architectural dark wood wardrobe against partition wall
    createBlock(3.4, 2.8, 0.85, 0x361E10, { pos: [0, 1.5, 18.05], collider: true, material: PBR_MATERIALS.woodDark });
    // Multi-panel door details
    createBlock(0.98, 2.6, 0.04, 0x472815, { pos: [-1.05, 1.5, 17.61], material: PBR_MATERIALS.woodDark });
    createBlock(0.98, 2.6, 0.04, 0x472815, { pos: [0, 1.5, 17.61], material: PBR_MATERIALS.woodDark });
    createBlock(0.98, 2.6, 0.04, 0x472815, { pos: [1.05, 1.5, 17.61], material: PBR_MATERIALS.woodDark });
    // Vertical brass handles
    createBlock(0.04, 0.65, 0.06, 0xF59E0B, { pos: [-0.62, 1.5, 17.58], material: PBR_MATERIALS.metalBrass });
    createBlock(0.04, 0.65, 0.06, 0xF59E0B, { pos: [0.62, 1.5, 17.58], material: PBR_MATERIALS.metalBrass });
    // Top molding cornice
    createBlock(3.55, 0.12, 0.95, 0x361E10, { pos: [0, 2.95, 18.05], material: PBR_MATERIALS.woodDark });

    // 7. Detailed Chest of Drawers (Dresser on East Wall)
    createBlock(2.2, 1.1, 0.75, 0x5C4033, { pos: [3.6, 0.65, 10.5], collider: true, material: PBR_MATERIALS.woodDark });
    createBlock(2.26, 0.06, 0.80, 0xD4A373, { pos: [3.6, 1.23, 10.5], material: PBR_MATERIALS.woodOak });
    // 4 sculpted drawer front panels with brass pull knobs
    for (let d = 0; d < 4; d++) {
      const dy = 0.3 + d * 0.22;
      createBlock(2.0, 0.18, 0.04, 0xD4A373, { pos: [3.6, dy, 10.12], material: PBR_MATERIALS.woodOak });
      const knobL = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.04, 0.05), PBR_MATERIALS.metalBrass);
      knobL.position.set(3.1, dy, 10.08);
      scene.add(knobL);
      const knobR = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.04, 0.05), PBR_MATERIALS.metalBrass);
      knobR.position.set(4.1, dy, 10.08);
      scene.add(knobR);
    }
    // Items on top of Dresser
    // Ceramic vase with dried botanicals
    createBlock(0.24, 0.42, 0.24, 0xFFFFFF, { pos: [4.2, 1.45, 10.5] });
    createBlock(0.08, 0.35, 0.08, 0xD97706, { pos: [4.2, 1.8, 10.5] });
    // Jewelry organizer box
    createBlock(0.42, 0.08, 0.32, 0x1E293B, { pos: [3.6, 1.3, 10.55] });
    // Stack of fashion/design magazines
    createBlock(0.38, 0.06, 0.3, 0xEC4899, { pos: [2.95, 1.28, 10.45] });
    createBlock(0.36, 0.04, 0.28, 0x3B82F6, { pos: [2.95, 1.33, 10.45] });

    // 8. Vanity Table Console & Stool (Near Wall-Mounted Mirror)
    createBlock(0.75, 0.8, 2.0, 0x5C4033, { pos: [-4.4, 0.4, 14.5], collider: true, material: PBR_MATERIALS.woodDark });
    createBlock(0.8, 0.05, 2.05, 0xD4A373, { pos: [-4.4, 0.82, 14.5], material: PBR_MATERIALS.woodOak });
    // Vanity Stool
    createBlock(0.55, 0.45, 0.55, 0x1E293B, { pos: [-3.7, 0.25, 14.5], collider: true });
    createBlock(0.5, 0.12, 0.5, 0xA7F3D0, { pos: [-3.7, 0.52, 14.5], material: PBR_MATERIALS.fabricMint });
    // Perfume bottles & makeup organizer on vanity
    createBlock(0.1, 0.18, 0.1, 0xF472B6, { pos: [-4.3, 0.94, 14.9] });
    createBlock(0.08, 0.14, 0.08, 0x38BDF8, { pos: [-4.42, 0.92, 15.1] });
    createBlock(0.28, 0.04, 0.45, 0xFFFFFF, { pos: [-4.35, 0.86, 14.1] });

    // 9. Workstation Desk & Architect Computer
    createBlock(1.15, 0.82, 2.8, 0x1E293B, { pos: [-4.3, 0.41, 11.2], collider: true });
    createBlock(1.2, 0.05, 2.85, 0x334155, { pos: [-4.3, 0.84, 11.2] });
    // Ergonomic office chair
    createBlock(0.65, 0.48, 0.65, 0x0F172A, { pos: [-3.3, 0.25, 11.2], collider: true });
    createBlock(0.12, 0.65, 0.58, 0x059669, { pos: [-2.95, 0.75, 11.2], material: PBR_MATERIALS.fabricEmerald });
    createBlock(0.58, 0.12, 0.58, 0x059669, { pos: [-3.3, 0.52, 11.2], material: PBR_MATERIALS.fabricEmerald });

    // Task Desk Lamp (Dynamic PointLight, Toggleable)
    LampManager.addLamp({
      name: 'Workstation Task Lamp',
      type: 'table',
      pos: [-4.35, 1.15, 12.2],
      color: 0xFFFBEB,
      intensity: 1.25,
      distance: 6.5,
      toggleable: true
    });

    // Desk Drawer
    deskDrawerMesh = createBlock(0.8, 0.25, 0.8, 0x475569, { pos: [-4.3, 0.3, 12.3] });
    interactables.push({
      name: 'Gaveta da Escrivaninha',
      pos: new THREE.Vector3(-4.0, 0.4, 12.3),
      action: () => {
        state.flags.deskDrawerOpen = !state.flags.deskDrawerOpen;
        animDrawers.push({
          obj: deskDrawerMesh,
          axis: 'x',
          target: state.flags.deskDrawerOpen ? -3.7 : -4.3
        });
        window.soundEngine.playDrawer();
      }
    });

    // Workstation Terminal (Mandatory Bedroom Memory Object)
    createBlock(0.1, 0.6, 0.9, 0x0F172A, { pos: [-4.3, 1.25, 11.2] });
    createBlock(0.05, 0.5, 0.8, 0x38BDF8, { pos: [-4.24, 1.25, 11.2] });
    createBlock(0.35, 0.04, 0.7, 0x1E293B, { pos: [-3.95, 0.88, 11.2] });

    interactables.push({
      name: 'Terminal de Projetos',
      pos: new THREE.Vector3(-3.95, 1.25, 11.2),
      action: () => inspectMemoryObject('bedroom_desk')
    });

    // Floating Bookshelves above Desk
    createBlock(0.35, 0.05, 2.2, 0xD4A373, { pos: [-4.55, 2.1, 11.2], material: PBR_MATERIALS.woodOak });
    const shelfBookColors = [0xEF4444, 0x3B82F6, 0x10B981, 0xF59E0B, 0x8B5CF6];
    for (let b = 0; b < 5; b++) {
      createBlock(0.24, 0.35, 0.08, shelfBookColors[b], { pos: [-4.55, 2.3, 10.4 + b * 0.16] });
    }
    // Small minimalist desk clock
    createBlock(0.1, 0.18, 0.18, 0x1E293B, { pos: [-4.55, 2.22, 11.8] });

    // 10. Windows, Animated Swaying Curtains & Dust Motes
    const curtainMat = PBR_MATERIALS.fabricWhite;
    const curtainL = createBlock(0.15, 3.2, 0.8, 0xFFFFFF, { pos: [4.8, 1.8, 11.2], material: curtainMat });
    const curtainR = createBlock(0.15, 3.2, 0.8, 0xFFFFFF, { pos: [4.8, 1.8, 15.8], material: curtainMat });
    animatedCurtains.push({ mesh: curtainL, phase: 0.0 });
    animatedCurtains.push({ mesh: curtainR, phase: 1.5 });

    // Floating Dust Motes in Sunbeam
    dustMotesGroup = new THREE.Group();
    const moteMat = new THREE.MeshBasicMaterial({ color: 0xFEF08A, transparent: true, opacity: 0.65 });
    for (let i = 0; i < 28; i++) {
      const mote = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.035, 0.035), moteMat);
      mote.position.set(-1.0 + Math.random() * 2.8, 0.5 + Math.random() * 2.2, 13.0 + Math.random() * 3.8);
      dustMotesGroup.add(mote);
    }
    scene.add(dustMotesGroup);
  }

  // =========================================================================
  // ROOM 1: BIBLIOTECA DE ANTIQUIDADES (Z: [-1.5, 8.5], Center Z = 3.5)
  // =========================================================================
  function buildLibraryDetails() {
    // 1. Central Persian-style Runner Rug
    createBlock(3.2, 0.02, 6.4, 0x7F1D1D, { pos: [0, 0.02, 3.5] });
    createBlock(3.0, 0.025, 6.2, 0x991B1B, { pos: [0, 0.025, 3.5] });
    createBlock(2.4, 0.03, 5.6, 0xD97706, { pos: [0, 0.03, 3.5] });

    // 2. Tall Mahogany Library Bookcases (West Wall)
    createBlock(0.65, 3.4, 6.2, 0x451A03, { pos: [-4.6, 1.7, 3.5], collider: true, material: PBR_MATERIALS.woodDark });
    // Decorative shelf compartments and colorful books
    const bookColors = [0x991B1B, 0x1E3A8A, 0x14532D, 0xB45309, 0x581C87, 0x0F172A];
    for (let level = 0; level < 4; level++) {
      const shelfY = 0.6 + level * 0.75;
      createBlock(0.68, 0.06, 6.0, 0x78350F, { pos: [-4.6, shelfY, 3.5], material: PBR_MATERIALS.woodOak });
      for (let bk = 0; bk < 12; bk++) {
        const color = bookColors[(level + bk) % bookColors.length];
        createBlock(0.45, 0.55, 0.12, color, { pos: [-4.55, shelfY + 0.3, 1.0 + bk * 0.42] });
      }
    }

    // 3. Classical Study Desk (Dark Cherry Wood)
    createBlock(1.4, 0.85, 2.6, 0x78350F, { pos: [-2.6, 0.425, 3.5], collider: true, material: PBR_MATERIALS.woodDark });
    createBlock(1.45, 0.06, 2.65, 0x9A3412, { pos: [-2.6, 0.88, 3.5], material: PBR_MATERIALS.woodOak });
    // Leather blotter on desk
    createBlock(0.8, 0.02, 1.4, 0x1E293B, { pos: [-2.5, 0.92, 3.5] });
    // Brass reading desk lamp
    LampManager.addLamp({
      name: 'Library Desk Lamp',
      type: 'table',
      pos: [-2.9, 1.15, 4.4],
      color: 0xFEF08A,
      intensity: 1.25,
      distance: 6.0,
      toggleable: true
    });
    // Inkwell and quill
    createBlock(0.12, 0.14, 0.12, 0x0F172A, { pos: [-2.3, 0.98, 4.2] });
    createBlock(0.02, 0.28, 0.02, 0xFFFFFF, { pos: [-2.3, 1.15, 4.2] });

    // Memory Object #1: Pergaminhos Antigos
    createBlock(0.35, 0.08, 0.55, 0xFEF3C7, { pos: [-2.6, 0.95, 3.5] });
    createBlock(0.38, 0.03, 0.06, 0xB45309, { pos: [-2.6, 0.98, 3.5] }); // ribbon tie
    interactables.push({
      name: 'Pergaminhos Antigos',
      pos: new THREE.Vector3(-2.6, 0.95, 3.5),
      action: () => inspectMemoryObject('library_scrolls')
    });

    // 4. Velvet Reading Armchair & Side Table (East Wall)
    createBlock(1.1, 0.95, 1.1, 0x831843, { pos: [3.2, 0.48, 5.2], collider: true }); // burgundy velvet
    createBlock(0.9, 0.55, 0.3, 0x9D174D, { pos: [3.2, 0.95, 5.6] }); // backrest
    createBlock(0.25, 0.45, 0.9, 0x9D174D, { pos: [2.7, 0.65, 5.2] }); // armrest L
    createBlock(0.25, 0.45, 0.9, 0x9D174D, { pos: [3.7, 0.65, 5.2] }); // armrest R
    createBlock(0.85, 0.15, 0.85, 0xFDE68A, { pos: [3.2, 0.55, 5.2] }); // gold cushion

    // Memory Object #2: Poltrona de Veludo
    interactables.push({
      name: 'Poltrona de Veludo',
      pos: new THREE.Vector3(3.2, 0.7, 5.2),
      action: () => inspectMemoryObject('library_armchair')
    });

    // 5. Spinning Brass Celestial Globe on Carved Wood Pedestal
    createBlock(0.65, 0.85, 0.65, 0x451A03, { pos: [3.2, 0.425, 1.8], collider: true, material: PBR_MATERIALS.woodDark });
    createBlock(0.5, 0.5, 0.5, 0xF59E0B, { pos: [3.2, 1.15, 1.8], material: PBR_MATERIALS.metalBrass });
    createBlock(0.08, 0.35, 0.08, 0x78350F, { pos: [3.2, 0.92, 1.8] }); // stem

    // Memory Object #3: Globo Celeste de Latão
    interactables.push({
      name: 'Globo Celeste de Latão',
      pos: new THREE.Vector3(3.2, 1.15, 1.8),
      action: () => inspectMemoryObject('library_globe')
    });

    // 6. Brick Fireplace Alcove (East Wall Center)
    createBlock(0.7, 2.2, 2.4, 0x7F1D1D, { pos: [4.6, 1.1, 3.5], collider: true });
    createBlock(0.5, 1.2, 1.4, 0x1C1917, { pos: [4.4, 0.6, 3.5] }); // firebox
    createBlock(0.85, 0.1, 2.6, 0x78350F, { pos: [4.55, 2.25, 3.5], material: PBR_MATERIALS.woodOak }); // mantel
    // Glowing Fire Embers
    LampManager.addLamp({
      name: 'Library Fireplace Hearth',
      type: 'table',
      pos: [4.1, 0.45, 3.5],
      color: 0xEA580C,
      intensity: 1.5,
      distance: 5.5,
      toggleable: false
    });
  }

  // =========================================================================
  // ROOM 2: JARDIM DE INVERNO & CHÁ (Z: [-11.5, -1.5], Center Z = -6.5)
  // =========================================================================
  function buildGardenDetails() {
    // 1. Terracotta Tile Pattern along floor
    createBlock(4.6, 0.02, 7.8, 0xC2410C, { pos: [0, 0.02, -6.5] });
    createBlock(4.2, 0.025, 7.4, 0xEA580C, { pos: [0, 0.025, -6.5] });

    // 2. Central Stone Tiered Fountain
    createBlock(1.8, 0.35, 1.8, 0x64748B, { pos: [2.5, 0.175, -6.5], collider: true }); // base basin
    createBlock(1.4, 0.1, 1.4, 0x38BDF8, { pos: [2.5, 0.32, -6.5], transparent: true, opacity: 0.8 }); // water
    createBlock(0.5, 0.65, 0.5, 0x475569, { pos: [2.5, 0.65, -6.5] }); // pillar
    createBlock(0.9, 0.18, 0.9, 0x64748B, { pos: [2.5, 0.95, -6.5] }); // upper basin
    createBlock(0.7, 0.08, 0.7, 0x38BDF8, { pos: [2.5, 1.02, -6.5], transparent: true, opacity: 0.8 }); // top water

    // Memory Object #1: Fonte de Pedra
    interactables.push({
      name: 'Fonte de Pedra',
      pos: new THREE.Vector3(2.5, 0.65, -6.5),
      action: () => inspectMemoryObject('garden_fountain')
    });

    // 3. Wrought Iron Tea Table & Pastry Set
    createBlock(1.3, 0.75, 1.3, 0x1E293B, { pos: [-2.4, 0.375, -6.5], collider: true });
    createBlock(1.4, 0.04, 1.4, 0xBAE6FD, { pos: [-2.4, 0.77, -6.5], transparent: true, opacity: 0.75 }); // glass top
    // Porcelain Teapot & Teacups
    createBlock(0.22, 0.22, 0.22, 0xFFFFFF, { pos: [-2.4, 0.9, -6.5] }); // teapot
    createBlock(0.12, 0.12, 0.12, 0xFFFFFF, { pos: [-2.1, 0.85, -6.3] }); // teacup 1
    createBlock(0.12, 0.12, 0.12, 0xFFFFFF, { pos: [-2.7, 0.85, -6.7] }); // teacup 2
    // Tiered sweet pastries stand
    createBlock(0.28, 0.28, 0.28, 0xFDE68A, { pos: [-2.4, 0.92, -6.8] });

    // Memory Object #2: Mesa de Chá das Cinco
    interactables.push({
      name: 'Mesa de Chá das Cinco',
      pos: new THREE.Vector3(-2.4, 0.85, -6.5),
      action: () => inspectMemoryObject('garden_tea_table')
    });

    // Two Wrought Iron Bistro Chairs
    createBlock(0.65, 0.45, 0.65, 0x1E293B, { pos: [-1.4, 0.225, -6.5], collider: true });
    createBlock(0.55, 0.1, 0.55, 0xA7F3D0, { pos: [-1.4, 0.48, -6.5], material: PBR_MATERIALS.fabricMint });
    createBlock(0.1, 0.55, 0.55, 0x1E293B, { pos: [-0.95, 0.72, -6.5] }); // chair back

    createBlock(0.65, 0.45, 0.65, 0x1E293B, { pos: [-3.4, 0.225, -6.5], collider: true });
    createBlock(0.55, 0.1, 0.55, 0xA7F3D0, { pos: [-3.4, 0.48, -6.5], material: PBR_MATERIALS.fabricMint });
    createBlock(0.1, 0.55, 0.55, 0x1E293B, { pos: [-3.85, 0.72, -6.5] }); // chair back

    // 4. Blossoming Miniature Orange Tree in Terracotta Planter
    createBlock(1.1, 0.8, 1.1, 0x9A3412, { pos: [-3.8, 0.4, -9.2], collider: true }); // large planter
    createBlock(0.25, 1.2, 0.25, 0x78350F, { pos: [-3.8, 1.3, -9.2] }); // trunk
    // Leafy canopy voxels
    createBlock(1.6, 1.2, 1.6, 0x15803D, { pos: [-3.8, 2.2, -9.2] });
    // Bright orange citrus fruit voxels
    createBlock(0.18, 0.18, 0.18, 0xF97316, { pos: [-3.3, 2.1, -8.7] });
    createBlock(0.18, 0.18, 0.18, 0xF97316, { pos: [-4.2, 2.3, -8.8] });
    createBlock(0.18, 0.18, 0.18, 0xF97316, { pos: [-3.5, 2.4, -9.6] });

    // Memory Object #3: Laranjeira em Flor
    interactables.push({
      name: 'Laranjeira em Flor',
      pos: new THREE.Vector3(-3.8, 1.5, -9.2),
      action: () => inspectMemoryObject('garden_orange_tree')
    });

    // 5. Potting Bench & Hanging Lavender Boxes (East Wall)
    createBlock(0.85, 0.85, 2.6, 0x78350F, { pos: [4.2, 0.425, -9.2], collider: true, material: PBR_MATERIALS.woodDark });
    createBlock(0.24, 0.22, 0.24, 0x9A3412, { pos: [4.2, 0.95, -8.6] }); // clay pots
    createBlock(0.22, 0.18, 0.22, 0x9A3412, { pos: [4.2, 0.94, -9.6] });
    // Window garden planter with fragrant lavender & ferns
    createBlock(0.5, 0.35, 3.2, 0x1E293B, { pos: [4.6, 0.95, -5.5] });
    createBlock(0.45, 0.25, 3.0, 0x8B5CF6, { pos: [4.6, 1.2, -5.5] }); // lavender blooms
  }

  // =========================================================================
  // ROOM 3: ATELIÊ DE MÚSICA & SONHOS (Z: [-21.5, -11.5], Center Z = -16.5)
  // =========================================================================
  function buildAtelierDetails() {
    // 1. Bohemian Indigo / Teal Floor Rug
    createBlock(4.2, 0.02, 6.8, 0x0F766E, { pos: [0, 0.02, -16.5] });
    createBlock(3.8, 0.025, 6.4, 0x115E59, { pos: [0, 0.025, -16.5] });

    // 2. Upright Acoustic Mahogany Piano (West Wall)
    createBlock(1.1, 1.5, 2.6, 0x451A03, { pos: [-4.2, 0.75, -16.5], collider: true, material: PBR_MATERIALS.woodDark });
    // Piano Keyboard Bed
    createBlock(0.45, 0.18, 2.2, 0xFFFFFF, { pos: [-3.55, 0.75, -16.5] }); // ivory keys
    createBlock(0.25, 0.08, 2.0, 0x0F172A, { pos: [-3.6, 0.85, -16.5] }); // ebony black keys
    // Music sheet stand
    createBlock(0.08, 0.4, 0.8, 0xFDE68A, { pos: [-3.9, 1.45, -16.5] });
    // Piano Stool
    createBlock(0.55, 0.5, 0.95, 0x78350F, { pos: [-2.8, 0.25, -16.5], collider: true });
    createBlock(0.52, 0.1, 0.92, 0x831843, { pos: [-2.8, 0.52, -16.5] }); // velvet top

    // Memory Object #1: Piano Acústico de Parede
    interactables.push({
      name: 'Piano Acústico de Parede',
      pos: new THREE.Vector3(-3.55, 0.9, -16.5),
      action: () => inspectMemoryObject('atelier_piano')
    });

    // 3. Artist's Easel & Twilight Painting (East Wall North)
    createBlock(0.12, 2.1, 0.12, 0x78350F, { pos: [2.8, 1.05, -14.5], rot: [0, 0, 0.15] }); // easel leg L
    createBlock(0.12, 2.1, 0.12, 0x78350F, { pos: [3.4, 1.05, -14.5], rot: [0, 0, -0.15] }); // easel leg R
    createBlock(0.12, 2.1, 0.12, 0x78350F, { pos: [3.1, 1.05, -14.1], rot: [-0.18, 0, 0] }); // back strut
    // Painted Canvas (Twilight landscape with stars)
    createBlock(0.08, 1.2, 1.1, 0x818CF8, { pos: [3.05, 1.3, -14.5], collider: true });
    createBlock(0.06, 0.45, 0.9, 0xF472B6, { pos: [3.08, 1.05, -14.5] }); // sunset blush
    // Wooden palette with paint blobs
    createBlock(0.35, 0.04, 0.45, 0xD4A373, { pos: [2.8, 0.85, -13.6] });

    // Memory Object #2: Cavalete de Pintura
    interactables.push({
      name: 'Cavalete de Pintura',
      pos: new THREE.Vector3(3.05, 1.3, -14.5),
      action: () => inspectMemoryObject('atelier_easel')
    });

    // 4. Antique Spun-Brass Gramophone on Cabinet (East Wall South)
    createBlock(0.9, 0.9, 1.1, 0x78350F, { pos: [3.6, 0.45, -18.8], collider: true, material: PBR_MATERIALS.woodDark });
    createBlock(0.5, 0.15, 0.5, 0x1C1917, { pos: [3.6, 0.98, -18.8] }); // turntable
    // Spun Brass Horn (Cone/Pyramid approximation in voxels)
    createBlock(0.35, 0.55, 0.35, 0xF59E0B, { pos: [3.5, 1.35, -18.8], material: PBR_MATERIALS.metalBrass });
    createBlock(0.55, 0.35, 0.55, 0xFBBF24, { pos: [3.4, 1.65, -18.8], material: PBR_MATERIALS.metalBrass });
    // Vinyl Record Sleeves
    createBlock(0.06, 0.45, 0.45, 0xEF4444, { pos: [3.1, 0.45, -18.8] });
    createBlock(0.06, 0.45, 0.45, 0x3B82F6, { pos: [3.18, 0.45, -18.8] });

    // Memory Object #3: Gramofone Antigo
    interactables.push({
      name: 'Gramofone Antigo',
      pos: new THREE.Vector3(3.5, 1.2, -18.8),
      action: () => inspectMemoryObject('atelier_gramophone')
    });

    // 5. Cello resting in corner stand & Curved Lounge Sofa
    createBlock(0.35, 1.4, 0.22, 0x9A3412, { pos: [-4.2, 0.8, -13.5] }); // cello body
    createBlock(0.08, 0.8, 0.08, 0x1E293B, { pos: [-4.2, 1.6, -13.5] }); // neck
    // Studio Lounge Daybed
    createBlock(1.4, 0.55, 2.6, 0x334155, { pos: [-1.2, 0.275, -19.6], collider: true });
    createBlock(0.55, 0.25, 0.55, 0xF59E0B, { pos: [-1.2, 0.65, -19.0] }); // gold cushion
    createBlock(0.55, 0.25, 0.55, 0x06B6D4, { pos: [-1.2, 0.65, -20.2] }); // cyan cushion
  }

  // =========================================================================
  // ROOM 4: OBSERVATÓRIO CELESTIAL (Z: [-31.5, -21.5], Center Z = -26.5)
  // =========================================================================
  function buildObservatoryDetails() {
    // 1. Midnight Blue Constellation Inlaid Floor
    createBlock(4.6, 0.02, 7.8, 0x0B132B, { pos: [0, 0.02, -26.5] });
    // Brass inlaid star lines
    createBlock(0.08, 0.03, 5.0, 0xF59E0B, { pos: [0, 0.03, -26.5], material: PBR_MATERIALS.metalBrass });
    createBlock(3.6, 0.03, 0.08, 0xF59E0B, { pos: [0, 0.03, -26.5], material: PBR_MATERIALS.metalBrass });

    // 2. Astronomical Refractor Telescope on Brass Tripod (Facing Sunset Window)
    createBlock(0.12, 1.5, 0.12, 0x475569, { pos: [-0.4, 0.75, -29.2], rot: [0, 0, -0.2] });
    createBlock(0.12, 1.5, 0.12, 0x475569, { pos: [0.4, 0.75, -29.2], rot: [0, 0, 0.2] });
    createBlock(0.12, 1.5, 0.12, 0x475569, { pos: [0, 0.75, -28.6], rot: [0.25, 0, 0] });
    // Long Brass Optical Tube
    createBlock(0.3, 0.3, 2.2, 0xF59E0B, { pos: [0, 1.6, -29.0], rot: [-0.3, 0, 0], collider: true, material: PBR_MATERIALS.metalBrass });
    createBlock(0.36, 0.36, 0.3, 0xFBBF24, { pos: [0, 1.85, -29.8], rot: [-0.3, 0, 0], material: PBR_MATERIALS.metalBrass }); // objective bell

    // Memory Object #1: Telescópio Astronômico
    interactables.push({
      name: 'Telescópio Astronômico',
      pos: new THREE.Vector3(0, 1.5, -29.0),
      action: () => inspectMemoryObject('observatory_telescope')
    });

    // 3. Heavy Cartographer's Star Chart Desk (West Wall)
    createBlock(1.4, 0.85, 2.6, 0x1E293B, { pos: [-3.2, 0.425, -26.5], collider: true });
    createBlock(1.45, 0.06, 2.65, 0x334155, { pos: [-3.2, 0.88, -26.5] });
    // Glowing Celestial Star Charts on desk
    createBlock(0.85, 0.02, 1.6, 0x0284C7, { pos: [-3.1, 0.92, -26.5] });
    createBlock(0.75, 0.025, 1.4, 0x38BDF8, { pos: [-3.1, 0.925, -26.5] }); // star lines
    // Brass Astrolabe & Divider Compass
    createBlock(0.35, 0.06, 0.35, 0xF59E0B, { pos: [-3.2, 0.96, -25.2], material: PBR_MATERIALS.metalBrass });

    // Memory Object #2: Mapa Celeste & Astrolábio
    interactables.push({
      name: 'Mapa Celeste & Astrolábio',
      pos: new THREE.Vector3(-3.2, 0.95, -26.5),
      action: () => inspectMemoryObject('observatory_celestial_map')
    });

    // 4. Resonant Crystal Display Cabinet (East Wall)
    createBlock(1.1, 0.95, 2.4, 0x0F172A, { pos: [3.4, 0.475, -26.5], collider: true });
    createBlock(1.0, 0.1, 2.2, 0x38BDF8, { pos: [3.4, 0.98, -26.5], transparent: true, opacity: 0.7 });
    // Glowing Amethyst and Quartz Cluster Crystals
    createBlock(0.28, 0.55, 0.28, 0xA855F7, { pos: [3.2, 1.25, -26.5], rot: [0.1, 0.2, 0.1] });
    createBlock(0.24, 0.45, 0.24, 0x38BDF8, { pos: [3.6, 1.2, -26.7], rot: [-0.15, 0, 0.2] });
    createBlock(0.22, 0.35, 0.22, 0xE879F9, { pos: [3.4, 1.15, -26.1], rot: [0.2, -0.1, 0] });
    // Ambient Crystal Glow PointLight
    LampManager.addLamp({
      name: 'Resonant Crystal Glow',
      type: 'table',
      pos: [3.4, 1.4, -26.5],
      color: 0xC084FC,
      intensity: 1.6,
      distance: 6.5,
      toggleable: false
    });

    // Memory Object #3: Geodo de Cristais Ressoantes
    interactables.push({
      name: 'Geodo de Cristais Ressoantes',
      pos: new THREE.Vector3(3.4, 1.2, -26.5),
      action: () => inspectMemoryObject('observatory_crystals')
    });

    // 5. Mechanical Brass Orrery Model (North West)
    createBlock(0.65, 0.85, 0.65, 0x1E293B, { pos: [-3.2, 0.425, -23.5], collider: true });
    createBlock(0.25, 0.25, 0.25, 0xF59E0B, { pos: [-3.2, 1.15, -23.5], material: PBR_MATERIALS.metalBrass }); // central sun
    createBlock(0.65, 0.04, 0.65, 0x94A3B8, { pos: [-3.2, 1.15, -23.5], material: PBR_MATERIALS.metalBrass }); // orbit rings
  }

  // =========================================================================
  // GRANDE SALA FINAL: SANTUÁRIO DAS MEMÓRIAS (Z: [-61.5, -31.5], Center Z = -46.5)
  // Monumental dimensions: 18m wide (X: [-9, 9]), 30m long, 7.0m height!
  // =========================================================================
  function buildGrandSanctuaryDetails() {
    // 1. Royal Purple & Gold Ceremonial Runner Carpet
    createBlock(4.8, 0.02, 26.0, 0x4C1D95, { pos: [0, 0.02, -46.5] });
    createBlock(4.4, 0.025, 25.6, 0x6D28D9, { pos: [0, 0.025, -46.5] });
    createBlock(0.2, 0.03, 25.4, 0xF59E0B, { pos: [-2.1, 0.03, -46.5], material: PBR_MATERIALS.metalBrass }); // gold border L
    createBlock(0.2, 0.03, 25.4, 0xF59E0B, { pos: [2.1, 0.03, -46.5], material: PBR_MATERIALS.metalBrass }); // gold border R

    // 2. Twelve Soaring Fluted Marble Columns (6 West, 6 East)
    const columnZList = [-36.0, -41.0, -46.0, -51.0, -56.0, -60.0];
    columnZList.forEach(cz => {
      // West Column
      createBlock(1.1, 0.5, 1.1, 0xE2E8F0, { pos: [-6.5, 0.25, cz], collider: true });
      createBlock(0.85, 6.2, 0.85, 0xF8FAFC, { pos: [-6.5, 3.4, cz], collider: true });
      createBlock(1.2, 0.4, 1.2, 0xE2E8F0, { pos: [-6.5, 6.7, cz] });

      // East Column
      createBlock(1.1, 0.5, 1.1, 0xE2E8F0, { pos: [6.5, 0.25, cz], collider: true });
      createBlock(0.85, 6.2, 0.85, 0xF8FAFC, { pos: [6.5, 3.4, cz], collider: true });
      createBlock(1.2, 0.4, 1.2, 0xE2E8F0, { pos: [6.5, 6.7, cz] });
    });

    // 3. Giant 12-Meter Arched Sunset Window (Back Wall at Z = -61.4)
    createBlock(10.0, 5.2, 0.15, 0xBAE6FD, { pos: [0, 3.6, -61.4], transparent: true, opacity: 0.5 });
    createBlock(10.2, 0.25, 0.25, 0xF59E0B, { pos: [0, 1.1, -61.35], material: PBR_MATERIALS.metalBrass });
    createBlock(10.2, 0.25, 0.25, 0xF59E0B, { pos: [0, 6.1, -61.35], material: PBR_MATERIALS.metalBrass });

    // 4. IN THE EXACT CENTER: Circular 3-Tiered Ceremonial Dais & Prepared Altar Pedestal
    // Tier 1 (Base, diameter ~5.6m)
    createBlock(5.6, 0.25, 5.6, 0xE2E8F0, { pos: [0, 0.125, -46.5] });
    // Tier 2 (Middle, diameter ~4.2m)
    createBlock(4.2, 0.25, 4.2, 0xF1F5F9, { pos: [0, 0.375, -46.5] });
    // Tier 3 (Top step, diameter ~2.8m)
    createBlock(2.8, 0.25, 2.8, 0xFFFFFF, { pos: [0, 0.625, -46.5] });

    // Prepared Central Pedestal (Altar platform prepared to receive developer's future object!)
    createBlock(1.2, 1.1, 1.2, 0xE2E8F0, { pos: [0, 1.3, -46.5], collider: true });
    createBlock(1.35, 0.12, 1.35, 0xF59E0B, { pos: [0, 1.9, -46.5], material: PBR_MATERIALS.metalBrass }); // gold altar crown
    
    // Vertical Celestial Light Shaft beam pouring from the high ceiling onto the pedestal
    const lightBeamGeom = new THREE.CylinderGeometry(0.85, 1.4, 5.8, 16);
    const lightBeamMat = new THREE.MeshBasicMaterial({
      color: 0xDDD6FE,
      transparent: true,
      opacity: 0.28,
      side: THREE.DoubleSide
    });
    const lightBeam = new THREE.Mesh(lightBeamGeom, lightBeamMat);
    lightBeam.position.set(0, 4.2, -46.5);
    scene.add(lightBeam);

    // Dynamic Heavenly Glow PointLight
    LampManager.addLamp({
      name: 'Sanctuary Central Light Beam',
      type: 'ceiling',
      pos: [0, 2.4, -46.5],
      color: 0xEDE9FE,
      intensity: 2.2,
      distance: 12.0,
      toggleable: false
    });

    // Mandatory Memory Object #1: Pedestal Central do Santuário
    interactables.push({
      name: 'Pedestal Central do Santuário',
      pos: new THREE.Vector3(0, 1.8, -46.5),
      action: () => inspectMemoryObject('final_pedestal')
    });

    // 5. Left Shrine: Altar dos Ecos (Embers & Sacred Chimes)
    createBlock(1.4, 0.95, 1.4, 0x1E1B4B, { pos: [-6.0, 0.475, -46.5], collider: true });
    createBlock(0.65, 0.35, 0.65, 0xF59E0B, { pos: [-6.0, 1.1, -46.5], material: PBR_MATERIALS.metalBrass });
    LampManager.addLamp({
      name: 'Sanctuary Echo Altar Flame',
      type: 'table',
      pos: [-6.0, 1.4, -46.5],
      color: 0xA78BFA,
      intensity: 1.5,
      distance: 6.5,
      toggleable: false
    });

    // Mandatory Memory Object #2: Altar dos Ecos
    interactables.push({
      name: 'Altar dos Ecos',
      pos: new THREE.Vector3(-6.0, 1.1, -46.5),
      action: () => inspectMemoryObject('final_pillar_altar')
    });

    // 6. Right Shrine: Espelho das Constelações
    createBlock(1.4, 0.95, 1.4, 0x1E1B4B, { pos: [6.0, 0.475, -46.5], collider: true });
    createBlock(0.1, 1.4, 1.1, 0x38BDF8, { pos: [6.0, 1.6, -46.5], transparent: true, opacity: 0.85 });
    createBlock(0.12, 1.5, 0.08, 0xF59E0B, { pos: [6.0, 1.6, -46.0], material: PBR_MATERIALS.metalBrass });
    createBlock(0.12, 1.5, 0.08, 0xF59E0B, { pos: [6.0, 1.6, -47.0], material: PBR_MATERIALS.metalBrass });

    // Mandatory Memory Object #3: Espelho das Constelações
    interactables.push({
      name: 'Espelho das Constelações',
      pos: new THREE.Vector3(6.0, 1.4, -46.5),
      action: () => inspectMemoryObject('final_memorial_mirror')
    });
  }

  // =========================================================================
  // MODULAR NARRATIVE SYSTEM & MEMORY INSPECTION ENGINE
  // =========================================================================
  let currentNarrativeLines = [];
  let currentNarrativeIndex = 0;
  let currentNarrativeCallback = null;

  function inspectMemoryObject(objId) {
    if (state.inCutscene || state.inMainMenu) return;

    let targetRoomId = null;
    let targetRoom = null;
    let targetObj = null;

    for (const [rId, room] of Object.entries(MEMORIES_CONFIG)) {
      const match = room.objects.find(o => o.id === objId);
      if (match) {
        targetRoomId = rId;
        targetRoom = room;
        targetObj = match;
        break;
      }
    }

    if (!targetObj) return;

    // Record inspection in persistent game state
    if (!state.inspectedObjects.includes(objId)) {
      state.inspectedObjects.push(objId);
      saveGame();
    }

    // Sound effect
    if (window.soundEngine && window.soundEngine.playItemPickup) {
      window.soundEngine.playItemPickup();
    }

    // Display narrative card
    showNarrativeCard(
      targetObj.name,
      'GATO FEITICEIRO',
      targetRoom.name,
      targetObj.text,
      () => {
        checkRoomCompletion(targetRoomId);
      }
    );

    updateHUD();
  }

  function showNarrativeCard(title, speaker, roomBadge, lines, onComplete) {
    const card = document.getElementById('narrative-card');
    const speakerEl = document.getElementById('narrative-card-speaker');
    const badgeEl = document.getElementById('narrative-card-room-badge');
    const textEl = document.getElementById('narrative-card-text');
    const pageEl = document.getElementById('narrative-card-page');
    const btnEl = document.getElementById('narrative-card-btn');

    if (!card) return;

    currentNarrativeLines = Array.isArray(lines) ? lines.slice() : [lines];
    currentNarrativeIndex = 0;
    currentNarrativeCallback = onComplete || null;

    if (speakerEl) speakerEl.innerText = speaker || 'GATO FEITICEIRO';
    if (badgeEl) badgeEl.innerText = roomBadge || title || 'Memória';

    card.classList.add('visible');
    renderNarrativePage();
  }

  function renderNarrativePage() {
    const textEl = document.getElementById('narrative-card-text');
    const pageEl = document.getElementById('narrative-card-page');
    const btnEl = document.getElementById('narrative-card-btn');

    if (textEl && currentNarrativeLines.length > 0) {
      textEl.innerText = currentNarrativeLines[currentNarrativeIndex];
    }
    if (pageEl) {
      pageEl.innerText = `${currentNarrativeIndex + 1} / ${currentNarrativeLines.length}`;
    }
    if (btnEl) {
      btnEl.innerText = (currentNarrativeIndex >= currentNarrativeLines.length - 1) ? 'CONCLUIR ✓' : 'AVANÇAR ▶';
    }

    if (window.soundEngine && window.soundEngine.playClick) {
      window.soundEngine.playClick();
    }
  }

  window.advanceNarrativeCard = function () {
    currentNarrativeIndex++;
    if (currentNarrativeIndex < currentNarrativeLines.length) {
      renderNarrativePage();
    } else {
      closeNarrativeCard();
    }
  };

  window.closeNarrativeCard = function () {
    const card = document.getElementById('narrative-card');
    if (card) card.classList.remove('visible');

    const cb = currentNarrativeCallback;
    currentNarrativeCallback = null;
    if (cb) cb();
  };

  function checkRoomCompletion(roomId) {
    const room = MEMORIES_CONFIG[roomId];
    if (!room) return;

    const allInspected = room.objects.every(o => state.inspectedObjects.includes(o.id));
    if (allInspected) {
      if (room.unlockDoor && !state.unlockedDoors.includes(room.unlockDoor)) {
        state.unlockedDoors.push(room.unlockDoor);
        openLinearDoor(room.unlockDoor);
        saveGame();

        setTimeout(() => {
          showNarrativeCard(
            room.name,
            'GATO FEITICEIRO',
            'Caminho Liberado',
            room.closingText,
            () => {
              showToast('✦ A porta para a próxima memória foi liberada!');
            }
          );
        }, 350);
      } else if (roomId === 'room_5_sanctuary' && !state.flags.gameCompleted) {
        state.flags.gameCompleted = true;
        saveGame();
        setTimeout(() => {
          showNarrativeCard(
            'Santuário das Memórias',
            'GATO FEITICEIRO',
            'Revelação',
            room.closingText,
            () => {
              showToast('✦ Você alcançou o centro das memórias!');
            }
          );
        }, 350);
      }
    }
    updateHUD();
  }

  function triggerRoomIntroduction(roomId) {
    const room = MEMORIES_CONFIG[roomId];
    if (!room) return;
    if (state.roomsIntroduced.includes(roomId)) return;

    state.roomsIntroduced.push(roomId);
    saveGame();

    setTimeout(() => {
      showNarrativeCard(
        room.name,
        'GATO FEITICEIRO',
        'Novo Ambiente',
        room.introText,
        null
      );
    }, 450);
  }

  // Modal: Diário de Memórias (Review past and present memories)
  window.openMemoriesModal = function () {
    window.soundEngine.init();
    const modal = document.getElementById('memories-modal');
    const listEl = document.getElementById('memories-list');
    if (!modal || !listEl) return;

    listEl.innerHTML = '';

    for (const [rId, room] of Object.entries(MEMORIES_CONFIG)) {
      const roomCard = document.createElement('div');
      roomCard.style.cssText = 'background: rgba(30, 27, 75, 0.7); border: 1px solid rgba(167, 139, 250, 0.35); border-radius: 10px; padding: 12px; margin-bottom: 8px;';

      const inspectedInRoom = room.objects.filter(o => state.inspectedObjects.includes(o.id)).length;
      const isComplete = (room.objects.length > 0 && inspectedInRoom === room.objects.length);

      const header = document.createElement('div');
      header.style.cssText = 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-weight: bold; color: #F59E0B;';
      header.innerHTML = `<span>✦ ${room.name}</span> <span style="font-size:12px; color:${isComplete ? '#10B981' : '#94A3B8'};">${inspectedInRoom}/${room.objects.length} ${isComplete ? '✓ Concluído' : '○ Em exploração'}</span>`;
      roomCard.appendChild(header);

      room.objects.forEach(obj => {
        const itemRow = document.createElement('div');
        const hasInspected = state.inspectedObjects.includes(obj.id);
        itemRow.style.cssText = `font-size: 13px; margin: 4px 0; padding: 4px 8px; border-radius: 6px; background: ${hasInspected ? 'rgba(167, 139, 250, 0.15)' : 'rgba(15, 23, 42, 0.4)'}; color: ${hasInspected ? '#E2E8F0' : '#64748B'};`;
        itemRow.innerHTML = `<strong>${hasInspected ? '✓' : '○'} ${obj.name}:</strong> ${hasInspected ? (Array.isArray(obj.text) ? obj.text[0] : obj.text) : 'Ainda não examinado...'}`;
        roomCard.appendChild(itemRow);
      });

      listEl.appendChild(roomCard);
    }

    modal.style.display = 'flex';
  };

  // --- CINEMATIC DIALOGUE SYSTEM ---
  let dialogueQueue = [];
  let dialogueCallback = null;
  let dialogueSpeaker = 'Maya';
  let dialogueLineIndex = 0;

  function showCinematicDialogue(speaker, lines, onComplete) {
    dialogueQueue = lines.slice();
    dialogueSpeaker = speaker || 'Maya';
    dialogueLineIndex = 0;
    dialogueCallback = onComplete || null;
    document.body.classList.add('cinematic-active');
    document.getElementById('cinematic-dialogue-overlay').style.display = 'flex';
    document.getElementById('cinematic-speaker').innerText = speaker || 'Maya';
    displayNextDialogueLine();
  }

  function displayNextDialogueLine() {
    if (dialogueQueue.length === 0) {
      document.body.classList.remove('cinematic-active');
      document.getElementById('cinematic-dialogue-overlay').style.display = 'none';
      if (dialogueCallback) {
        const cb = dialogueCallback;
        dialogueCallback = null;
        cb();
      }
      return;
    }
    const currentLine = dialogueQueue.shift();
    document.getElementById('cinematic-text').innerText = currentLine;
    if (window.soundEngine && window.soundEngine.playVoice) {
      const n = String(dialogueLineIndex + 1).padStart(2, '0');
      if (dialogueSpeaker === '???' || /feiticeiro|gato/i.test(dialogueSpeaker)) {
        window.soundEngine.playVoice('audio/voices/cat/intro_' + n + '.mp3');
      } else if (/maya/i.test(dialogueSpeaker)) {
        window.soundEngine.playVoice('audio/voices/maya/awakening_' + n + '.mp3');
      }
    }
    dialogueLineIndex++;
    window.soundEngine.playClick();
  }

  window.advanceCinematicDialogue = function () {
    displayNextDialogueLine();
  };

  function triggerNoteDialogue(noteId) {
    const note = state.notes.find(n => n.id === noteId);
    if (!note) return;
    if (!state.readNotes.includes(noteId)) {
      state.readNotes.push(noteId);
      saveGame();
    }
    showCinematicDialogue(note.speaker, note.lines);
  }

  // --- MEME BUTTON IMPLEMENTATION ---
  window.triggerMeme = function () {
    if (state.inCutscene || state.inMainMenu) return;
    window.soundEngine.init();

    // Randomize without repeating consecutively
    let nextIdx;
    do {
      nextIdx = Math.floor(Math.random() * MEME_PHRASES.length);
    } while (nextIdx === lastMemeIndex && MEME_PHRASES.length > 1);

    lastMemeIndex = nextIdx;
    const phrase = MEME_PHRASES[nextIdx];

    // Show speech bubble near character
    const bubble = document.getElementById('meme-bubble');
    bubble.innerText = phrase;
    bubble.style.display = 'block';

    window.soundEngine.playDuckQuack();

    if (memeTimer) clearTimeout(memeTimer);
    memeTimer = setTimeout(() => {
      bubble.style.display = 'none';
    }, 3200);
  };

  // --- JUMP IMPLEMENTATION ---
  window.triggerJump = function () {
    if (state.inCutscene || state.inMainMenu) return;
    if (isGrounded) {
      isGrounded = false;
      jumpVelocity = 5.2; // Upward initial velocity
      window.soundEngine.playFootstep();
    }
  };

  // --- CAMERA MODE SWITCHING (1P / 3P) ---
  window.toggleCameraMode = function () {
    const nextMode = state.cameraMode === '3P' ? '1P' : '3P';
    setCameraMode(nextMode);
    showToast(`Camera: ${state.cameraMode === '1P' ? 'First-Person (1P)' : 'Third-Person (3P)'}`);
    window.soundEngine.playClick();
    saveGame();
  };

  function setCameraMode(mode) {
    state.cameraMode = mode;
    const textEl = document.getElementById('cam-mode-text');
    const settingsEl = document.getElementById('settings-cam-text');
    if (textEl) textEl.innerText = mode;
    if (settingsEl) settingsEl.innerText = mode === '1P' ? 'First-Person (1P)' : 'Third-Person (3P)';

    // In 1P, hide Maya's head so camera isn't obstructed
    if (charHead) {
      charHead.visible = (mode === '3P');
    }
  }

  // --- SMOOTH CAPSULE COLLISION SYSTEM (PREVENTS GETTING STUCK) ---
  function moveCharacter(dx, dz) {
    const charRadius = 0.28; // Tightly calibrated capsule radius
    let newX = characterPos.x + dx;
    let newZ = characterPos.z + dz;

    // Resolve collision against each solid AABB with smooth sliding projection
    for (const box of colliders) {
      // Find closest point on box to character center
      const closestX = Math.max(box.min.x, Math.min(newX, box.max.x));
      const closestZ = Math.max(box.min.z, Math.min(newZ, box.max.z));

      const distX = newX - closestX;
      const distZ = newZ - closestZ;
      const distSq = distX * distX + distZ * distZ;

      if (distSq < charRadius * charRadius) {
        // Vertical height overlap check
        if (characterPos.y + 1.6 > box.min.y && characterPos.y < box.max.y) {
          const dist = Math.sqrt(distSq);
          if (dist > 0.0001) {
            const nx = distX / dist;
            const nz = distZ / dist;
            const penetration = charRadius - dist + 0.005; // tiny buffer prevents sticking!

            // Push character outward along normal
            newX += nx * penetration;
            newZ += nz * penetration;

            // Project remaining delta along tangent
            const dot = dx * nx + dz * nz;
            if (dot < 0) {
              dx -= dot * nx;
              dz -= dot * nz;
            }
          } else {
            // Center is inside box, push to nearest edge
            const dLeft = Math.abs(newX - box.min.x);
            const dRight = Math.abs(newX - box.max.x);
            const dBottom = Math.abs(newZ - box.min.z);
            const dTop = Math.abs(newZ - box.max.z);
            const minD = Math.min(dLeft, dRight, dBottom, dTop);

            if (minD === dLeft) newX = box.min.x - charRadius - 0.01;
            else if (minD === dRight) newX = box.max.x + charRadius + 0.01;
            else if (minD === dBottom) newZ = box.min.z - charRadius - 0.01;
            else newZ = box.max.z + charRadius + 0.01;
          }
        }
      }
    }

    characterPos.x = newX;
    characterPos.z = newZ;
  }

  let stepDistance = 0;

  // --- CONTROLS SETUP ---
  function setupControls() {
    window.addEventListener('keydown', (e) => {
      keys[e.key.toLowerCase()] = true;
      if (e.key === 'e' || e.key === 'E') triggerInteraction();
      if (e.key === ' ') triggerJump();
      if (e.key === 'm' || e.key === 'M') triggerMeme();
      if (e.key === 'c' || e.key === 'C') toggleCameraMode();
      window.soundEngine.init();
    });
    window.addEventListener('keyup', (e) => {
      keys[e.key.toLowerCase()] = false;
    });

    const joyZone = document.getElementById('joystick-zone');
    const joyStick = document.getElementById('joystick-stick');

    joyZone.addEventListener('touchstart', (e) => {
      if (state.hudEditMode || state.inCutscene) return;
      window.soundEngine.init();
      joyActive = true;
      const touch = e.targetTouches[0];
      const rect = joyZone.getBoundingClientRect();
      joyStartX = rect.left + rect.width / 2;
      joyStartY = rect.top + rect.height / 2;
      handleJoyMove(touch.clientX, touch.clientY);
      e.preventDefault();
    }, { passive: false });

    joyZone.addEventListener('touchmove', (e) => {
      if (!joyActive || state.hudEditMode || state.inCutscene) return;
      const touch = e.targetTouches[0];
      handleJoyMove(touch.clientX, touch.clientY);
      e.preventDefault();
    }, { passive: false });

    const endJoy = () => {
      joyActive = false;
      joyDeltaX = 0;
      joyDeltaY = 0;
      joyStick.style.transform = `translate(0px, 0px)`;
    };
    joyZone.addEventListener('touchend', endJoy);
    joyZone.addEventListener('touchcancel', endJoy);

    function handleJoyMove(cx, cy) {
      const maxR = 45;
      let dx = cx - joyStartX;
      let dy = cy - joyStartY;
      const dist = Math.hypot(dx, dy);
      if (dist > maxR) {
        dx = (dx / dist) * maxR;
        dy = (dy / dist) * maxR;
      }
      joyStick.style.transform = `translate(${dx}px, ${dy}px)`;
      joyDeltaX = dx / maxR;
      joyDeltaY = dy / maxR;
    }

    const lookZone = document.getElementById('look-zone');
    lookZone.addEventListener('touchstart', (e) => {
      if (state.hudEditMode || state.inCutscene) return;
      window.soundEngine.init();
      lookActive = true;
      const touch = e.targetTouches[0];
      lookLastX = touch.clientX;
      lookLastY = touch.clientY;
      e.preventDefault();
    }, { passive: false });

    lookZone.addEventListener('touchmove', (e) => {
      if (!lookActive || state.hudEditMode || state.inCutscene) return;
      const touch = e.targetTouches[0];
      const dx = touch.clientX - lookLastX;
      const dy = touch.clientY - lookLastY;
      lookLastX = touch.clientX;
      lookLastY = touch.clientY;

      cameraYaw -= dx * sensitivity;
      cameraPitch -= dy * sensitivity;

      // CRITICAL: Clamp camera pitch so it can NEVER clip above the 3.7m ceiling!
      // In 3P: maximum pitch angle is restricted based on camera distance
      cameraPitch = Math.max(-0.25, Math.min(0.55, cameraPitch));
      e.preventDefault();
    }, { passive: false });

    lookZone.addEventListener('touchend', () => { lookActive = false; });
    lookZone.addEventListener('touchcancel', () => { lookActive = false; });
  }

  // --- OPENING 3D CINEMATIC WAKE-UP SEQUENCE ---
  function startOpeningCutscene() {
    state.inCutscene = true;
    cutsceneStage = 0;
    cutsceneTime = 0;
    document.getElementById('cutscene-skip-btn').style.display = 'block';

    // Maya starts sleeping peacefully in bed
    characterPos.set(0, 0, 15.5);
    characterFacingYaw = 0;
    if (charBodyRoot) {
      charBodyRoot.position.set(0, 0.56, 0); // Contact with mattress
      charBodyRoot.rotation.set(0, 0, 0);
    }
    if (charHips) {
      charHips.position.set(0, 0.72, 0);
      charHips.rotation.set(-Math.PI / 2, 0, 0); // Flat on mattress
    }
    if (charSpineLower) charSpineLower.rotation.set(0, 0, 0);
    if (charChest) charChest.rotation.set(0, 0, 0);
    if (charNeck) charNeck.rotation.set(0.12, 0, 0); // Head on pillow
    if (charEyeLids) charEyeLids.scale.y = 1.0; // Eyes closed
    if (charShoulderL) charShoulderL.rotation.set(0.1, 0, 0);
    if (charShoulderR) charShoulderR.rotation.set(0.1, 0, 0);
    if (charFingersL) charFingersL.rotation.set(-0.4, 0, 0);
    if (charFingersR) charFingersR.rotation.set(-0.4, 0, 0);
    if (charThighL) charThighL.rotation.set(0, 0, 0);
    if (charThighR) charThighR.rotation.set(0, 0, 0);
    if (charKneeL) charKneeL.rotation.set(0, 0, 0);
    if (charKneeR) charKneeR.rotation.set(0, 0, 0);
    if (charAnkleL) charAnkleL.rotation.set(0, 0, 0);
    if (charAnkleR) charAnkleR.rotation.set(0, 0, 0);

    // Bed duvet covers her lower body naturally
    if (bedroomDuvetMesh) {
      bedroomDuvetMesh.position.z = 16.0;
      bedroomDuvetMesh.scale.z = 1.0;
    }
  }

  window.skipCutscene = function () {
    endCutscene();
  };

  function endCutscene() {
    state.inCutscene = false;
    document.getElementById('cutscene-skip-btn').style.display = 'none';
    document.body.classList.remove('cinematic-active');
    document.getElementById('cinematic-dialogue-overlay').style.display = 'none';

    // Maya stands on bedroom floor near vanity mirror & bed
    characterPos.set(-3.6, 0, 14.5);
    characterFacingYaw = -Math.PI / 2; // Facing the mirror
    if (charBodyRoot) {
      charBodyRoot.position.set(0, 0, 0);
      charBodyRoot.rotation.set(0, 0, 0);
    }
    if (charHips) {
      charHips.position.set(0, 0.72, 0);
      charHips.rotation.set(0, 0, 0);
    }
    if (charSpineLower) charSpineLower.rotation.set(0, 0, 0);
    if (charChest) charChest.rotation.set(0, 0, 0);
    if (charNeck) charNeck.rotation.set(0, 0, 0);
    if (charHead) charHead.rotation.set(0, 0, 0);
    if (charEyeLids) charEyeLids.scale.y = 0.0;
    if (charShoulderL) charShoulderL.rotation.set(0, 0, 0);
    if (charShoulderR) charShoulderR.rotation.set(0, 0, 0);
    if (charElbowL) charElbowL.rotation.set(0, 0, 0);
    if (charElbowR) charElbowR.rotation.set(0, 0, 0);
    if (charWristL) charWristL.rotation.set(0, 0, 0);
    if (charWristR) charWristR.rotation.set(0, 0, 0);
    if (charFingersL) charFingersL.rotation.set(0, 0, 0);
    if (charFingersR) charFingersR.rotation.set(0, 0, 0);
    if (charThighL) charThighL.rotation.set(0, 0, 0);
    if (charThighR) charThighR.rotation.set(0, 0, 0);
    if (charKneeL) charKneeL.rotation.set(0, 0, 0);
    if (charKneeR) charKneeR.rotation.set(0, 0, 0);
    if (charAnkleL) charAnkleL.rotation.set(0, 0, 0);
    if (charAnkleR) charAnkleR.rotation.set(0, 0, 0);

    if (bedroomDuvetMesh) {
      bedroomDuvetMesh.position.z = 16.5;
      bedroomDuvetMesh.scale.z = 0.75;
    }

    cameraYaw = -Math.PI / 2;
    cameraPitch = 0.22;
    if (wizardCatGroup) wizardCatGroup.visible = true;
    state.flags.cutsceneWatched = true;
    saveGame();
  }

  function updateCutscene(dt) {
    cutsceneTime += dt;
    const t = cutsceneTime;

    animateEnvironments(dt);
    renderPlanarMirrors();
    if (wizardCatGroup) {
      wizardCatGroup.visible = t >= 26.5;
      if (t >= 26.5) {
        wizardCatGroup.position.set(-2.25, 0.12 + Math.sin(t * 3) * 0.08, 14.1);
        if (wizardCatStaff) wizardCatStaff.rotation.z = Math.sin(t * 4) * 0.18;
      }
    }

    if (t < 3.5) {
      // Stage 1: Establishing Dolly Shot Across Sunlit Bedroom (0 - 3.5s)
      const p = t / 3.5;
      camera.position.set(
        THREE.MathUtils.lerp(2.8, 1.4, p),
        THREE.MathUtils.lerp(1.7, 1.3, p),
        THREE.MathUtils.lerp(18.2, 16.5, p)
      );
      camera.lookAt(0, 0.75, 14.5);

      if (charChest) {
        charChest.scale.y = 1.0 + Math.sin(t * 2.2) * 0.035;
      }
      if (charFingersL && charFingersR) {
        charFingersL.rotation.x = -0.4 + Math.sin(t * 1.5) * 0.05;
        charFingersR.rotation.x = -0.4 + Math.sin(t * 1.5) * 0.05;
      }
    } else if (t < 7.0) {
      // Stage 2: Close-up on Pillow & Face (3.5 - 7.0s)
      camera.position.set(0.65, 1.15, 14.8);
      camera.lookAt(0, 0.85, 14.1);

      if (charHead) {
        charHead.rotation.y = Math.sin((t - 3.5) * 1.4) * 0.18;
      }

      if (charEyeLids) {
        if (t < 4.8) {
          charEyeLids.scale.y = Math.max(0.0, 1.0 - (t - 3.5) / 1.0);
        } else if (t >= 5.0 && t <= 5.15) {
          charEyeLids.scale.y = 1.0;
        } else if (t >= 6.1 && t <= 6.25) {
          charEyeLids.scale.y = 1.0;
        } else {
          charEyeLids.scale.y = 0.0;
        }
      }

      if (charFingersL && charFingersR) {
        const fingerFlex = Math.sin((t - 3.5) * 2.5) * 0.2;
        charFingersL.rotation.x = -0.3 + fingerFlex;
        charFingersR.rotation.x = -0.3 + fingerFlex;
      }
    } else if (t < 11.0) {
      // Stage 3: Morning Stretch & Mattress Reaction (7.0 - 11.0s)
      const p = (t - 7.0) / 4.0;
      camera.position.set(1.5, 1.6, 17.2);
      camera.lookAt(0, 0.8, 15.0);

      const stretchPhase = Math.sin(p * Math.PI);
      if (charShoulderL && charShoulderR) {
        charShoulderL.rotation.x = 0.1 - stretchPhase * 1.3;
        charShoulderR.rotation.x = 0.1 - stretchPhase * 1.3;
      }
      if (charElbowL && charElbowR) {
        charElbowL.rotation.x = stretchPhase * 0.2;
        charElbowR.rotation.x = stretchPhase * 0.2;
      }
      if (charFingersL && charFingersR) {
        charFingersL.rotation.x = stretchPhase * 0.3;
        charFingersR.rotation.x = stretchPhase * 0.3;
      }
      if (charSpineLower) {
        charSpineLower.rotation.x = -stretchPhase * 0.18;
      }
      if (charChest) {
        charChest.scale.y = 1.0 + stretchPhase * 0.08;
      }
      if (bedroomDuvetMesh && p > 0.4) {
        bedroomDuvetMesh.position.z = 16.0 + (p - 0.4) * 0.5;
      }
    } else if (t < 15.5) {
      // Stage 4: Sitting Up with Continuous Mattress Contact (11.0 - 15.5s)
      const p = Math.min(1.0, (t - 11.0) / 4.0);
      const easeP = p * p * (3 - 2 * p);

      camera.position.set(-1.6, 1.45, 15.2);
      camera.lookAt(0, 0.9, 15.0);

      if (charHips) {
        charHips.rotation.x = -Math.PI / 2 + easeP * (Math.PI / 2);
      }
      if (charShoulderL && charShoulderR) {
        charShoulderL.rotation.x = easeP * 0.3;
        charShoulderR.rotation.x = easeP * 0.3;
      }
      if (charElbowL && charElbowR) {
        charElbowL.rotation.x = easeP * 0.4;
        charElbowR.rotation.x = easeP * 0.4;
      }
      if (charWristL && charWristR) {
        charWristL.rotation.x = -easeP * 0.35;
        charWristR.rotation.x = -easeP * 0.35;
      }
      if (charNeck) {
        charNeck.rotation.x = 0.12 * (1.0 - easeP);
      }
      if (charHead) {
        charHead.rotation.z = Math.sin(t * 1.2) * 0.06;
      }
    } else if (t < 19.5) {
      // Stage 5: Moving Legs Over Bed Edge & Feet on Floor (15.5 - 19.5s)
      const p = Math.min(1.0, (t - 15.5) / 3.5);
      const easeP = p * p * (3 - 2 * p);

      camera.position.set(-2.0, 1.0, 14.8);
      camera.lookAt(-0.5, 0.5, 15.2);

      if (charHips) {
        charHips.rotation.y = easeP * (Math.PI / 2);
      }
      if (charKneeL && charKneeR) {
        charKneeL.rotation.x = -easeP * (Math.PI / 2);
        charKneeR.rotation.x = -easeP * (Math.PI / 2);
      }
      if (charThighL && charThighR) {
        charThighL.rotation.x = easeP * 0.15;
        charThighR.rotation.x = easeP * 0.15;
      }
      if (charShoulderL && charShoulderR) {
        charShoulderL.rotation.x = 0.3 + easeP * 0.2;
        charShoulderR.rotation.x = 0.3 + easeP * 0.2;
      }
      if (bedroomDuvetMesh) {
        bedroomDuvetMesh.position.z = 16.5;
        bedroomDuvetMesh.scale.z = 0.75;
      }
    } else if (t < 23.5) {
      // Stage 6: Standing Up Gracefully & Grounding (19.5 - 23.5s)
      const p = Math.min(1.0, (t - 19.5) / 3.5);
      const easeP = p * p * (3 - 2 * p);

      camera.position.set(-1.4, 1.4, 13.0);
      camera.lookAt(characterPos.x, 1.1, characterPos.z);

      characterPos.x = -1.2 * easeP;
      characterPos.z = 15.5 - 0.5 * easeP;
      characterFacingYaw = -Math.PI / 2;

      if (charBodyRoot) {
        charBodyRoot.position.y = 0.56 * (1.0 - easeP);
      }
      if (charHips) {
        charHips.rotation.set(0, 0, 0);
      }
      if (charKneeL && charKneeR) {
        charKneeL.rotation.x = -(1.0 - easeP) * (Math.PI / 2);
        charKneeR.rotation.x = -(1.0 - easeP) * (Math.PI / 2);
      }
      if (charThighL && charThighR) {
        charThighL.rotation.set(0, 0, 0);
      }
      if (charShoulderL && charShoulderR) {
        charShoulderL.rotation.x = (1.0 - easeP) * 0.4;
        charShoulderR.rotation.x = (1.0 - easeP) * 0.4;
      }
      if (charElbowL && charElbowR) {
        charElbowL.rotation.set(0.1, 0, 0);
      }
      if (charHead) {
        charHead.rotation.y = Math.sin(t * 1.5) * 0.25;
      }
    } else if (t < 29.5) {
      // Stage 7: Walking to Vanity Mirror & Gazing at Reflection (23.5 - 29.5s)
      const p = Math.min(1.0, (t - 23.5) / 4.5);

      characterPos.x = THREE.MathUtils.lerp(-1.2, -3.6, p);
      characterPos.z = 15.0 - 0.5 * p;
      characterFacingYaw = -Math.PI / 2;

      if (p < 0.95) {
        walkAnimTime += dt * 8.5;
        const leg = Math.sin(walkAnimTime);
        if (charThighL && charThighR) {
          charThighL.rotation.x = leg * 0.45;
          charThighR.rotation.x = -leg * 0.45;
        }
        if (charKneeL && charKneeR) {
          charKneeL.rotation.x = leg < 0 ? -Math.abs(leg) * 0.55 : -0.05;
          charKneeR.rotation.x = -leg < 0 ? -Math.abs(leg) * 0.55 : -0.05;
        }
        if (charShoulderL && charShoulderR) {
          charShoulderL.rotation.x = -leg * 0.4;
          charShoulderR.rotation.x = leg * 0.4;
        }
      } else {
        if (charThighL) charThighL.rotation.x = 0;
        if (charThighR) charThighR.rotation.x = 0;
        if (charKneeL) charKneeL.rotation.x = 0;
        if (charKneeR) charKneeR.rotation.x = 0;
        if (charShoulderL) charShoulderL.rotation.x = 0;

        const touchP = (t - 27.5) / 2.0;
        if (touchP > 0 && charShoulderR && charElbowR && charHandR) {
          const tEase = Math.min(1.0, touchP);
          charShoulderR.rotation.x = -0.75 * tEase;
          charElbowR.rotation.x = 1.15 * tEase;
          charHandR.rotation.x = 0.35 * tEase;
        }
      }

      camera.position.set(-2.2, 1.52, 14.5);
      camera.lookAt(-4.85, 1.5, 14.5);

      if (t >= 29.2 && cutsceneStage === 0) {
        cutsceneStage = 1;
        showCinematicDialogue('Gato Feiticeiro', [
          'Ah... você finalmente despertou.',
          'Não precisa dizer nada, Maya. Seus olhos já me dizem que tudo ao redor parece um mistério para você.',
          'Venha comigo. Deixe-me mostrar esta casa... cada cômodo guarda momentos e lembranças de tempos preciosos.',
          'Observe os objetos com atenção. Conforme você recordar, o caminho adiante irá se revelar.'
        ], () => {
          endCutscene();
          showToast('✦ O Gato Feiticeiro agora acompanha você pelas memórias.');
        });
      }
    }

    if (characterGroup) {
      characterGroup.position.copy(characterPos);
      characterGroup.rotation.y = characterFacingYaw;
    }
  }

  // --- MAIN MENU LOGIC ---
  window.onMenuContinue = function () {
    window.soundEngine.init();
    if (loadGame()) {
      showToast('Adventure Restored!');
    }
    state.inMainMenu = false;
    document.getElementById('main-menu-overlay').style.display = 'none';
  };

  window.onMenuNewGame = function () {
    window.soundEngine.init();
    if (hasSavedGame()) {
      if (!confirm('Start a new game? Your previous save will be overwritten.')) return;
    }
    localStorage.removeItem('cubescape_save');
    state.inMainMenu = false;
    document.getElementById('main-menu-overlay').style.display = 'none';
    startOpeningCutscene();
  };

  window.onMenuLoadGame = function () {
    window.soundEngine.init();
    if (loadGame()) {
      state.inMainMenu = false;
      document.getElementById('main-menu-overlay').style.display = 'none';
      showToast('Game loaded successfully!');
    } else {
      showToast('No saved game found!');
      window.soundEngine.playSafeError();
    }
  };

  function updateMenuButtons() {
    const contBtn = document.getElementById('btn-menu-continue');
    if (contBtn) {
      contBtn.disabled = !hasSavedGame();
    }
  }

  // --- HUD CUSTOMIZATION SYSTEM ---
  let isDraggingHud = false;
  let currentDragEl = null;
  let dragOffset = { x: 0, y: 0 };

  window.startHudCustomize = function () {
    window.closeModals();
    state.hudEditMode = true;
    document.body.classList.add('hud-edit-mode');
    document.getElementById('hud-edit-toolbar').style.display = 'flex';
    document.getElementById('main-menu-overlay').style.display = 'none';
    setupDraggableHud();
  };

  function setupDraggableHud() {
    const customizables = document.querySelectorAll('.hud-customizable');
    customizables.forEach(el => {
      el.onpointerdown = (e) => {
        if (!state.hudEditMode) return;
        isDraggingHud = true;
        currentDragEl = el;
        const rect = el.getBoundingClientRect();
        dragOffset.x = e.clientX - rect.left;
        dragOffset.y = e.clientY - rect.top;
        el.setPointerCapture(e.pointerId);
        e.stopPropagation();
      };
      el.onpointermove = (e) => {
        if (!state.hudEditMode || !isDraggingHud || currentDragEl !== el) return;
        let nx = e.clientX - dragOffset.x;
        let ny = e.clientY - dragOffset.y;
        nx = Math.max(10, Math.min(window.innerWidth - el.offsetWidth - 10, nx));
        ny = Math.max(10, Math.min(window.innerHeight - el.offsetHeight - 10, ny));

        el.style.left = `${nx}px`;
        el.style.top = `${ny}px`;
        el.style.bottom = 'auto';
        el.style.right = 'auto';
        el.style.transform = 'none';
      };
      el.onpointerup = (e) => {
        if (currentDragEl === el) {
          isDraggingHud = false;
          currentDragEl = null;
          el.releasePointerCapture(e.pointerId);
        }
      };
    });
  }

  window.saveHudLayout = function () {
    const layout = {};
    document.querySelectorAll('.hud-customizable').forEach(el => {
      layout[el.id] = {
        left: el.style.left,
        top: el.style.top,
        bottom: el.style.bottom,
        right: el.style.right,
        transform: el.style.transform
      };
    });
    localStorage.setItem('cubescape_hud_layout', JSON.stringify(layout));
    showToast('HUD Layout Saved!');
  };

  window.resetHudLayout = function () {
    localStorage.removeItem('cubescape_hud_layout');
    document.querySelectorAll('.hud-customizable').forEach(el => {
      el.style.left = '';
      el.style.top = '';
      el.style.bottom = '';
      el.style.right = '';
      el.style.transform = '';
    });
    showToast('HUD Layout Reset to Default.');
  };

  function loadHudLayout() {
    try {
      const saved = localStorage.getItem('cubescape_hud_layout');
      if (!saved) return;
      const layout = JSON.parse(saved);
      for (const id in layout) {
        const el = document.getElementById(id);
        if (el && layout[id]) {
          if (layout[id].left) el.style.left = layout[id].left;
          if (layout[id].top) el.style.top = layout[id].top;
          if (layout[id].bottom) el.style.bottom = layout[id].bottom;
          if (layout[id].right) el.style.right = layout[id].right;
          if (layout[id].transform) el.style.transform = layout[id].transform;
        }
      }
    } catch (e) {
      console.warn('Failed to load HUD layout', e);
    }
  }

  window.exitHudCustomize = function () {
    state.hudEditMode = false;
    document.body.classList.remove('hud-edit-mode');
    document.getElementById('hud-edit-toolbar').style.display = 'none';
    if (state.inMainMenu) {
      document.getElementById('main-menu-overlay').style.display = 'flex';
    }
  };

  // --- AUDIO CONTROLS VIA INDEPENDENT SLIDERS ---
  window.updateAudioSetting = function (channel, value) {
    const norm = value / 100;
    if (channel === 'master') window.soundEngine.setMasterVolume(norm);
    if (channel === 'music') window.soundEngine.setMusicVolume(norm);
    if (channel === 'ambient') window.soundEngine.setAmbientVolume(norm);
    if (channel === 'character') window.soundEngine.setCharacterVolume(norm);
    if (channel === 'voice') window.soundEngine.setVoiceVolume(norm);
  };

  window.setSensitivity = function (val) {
    sensitivity = 0.001 + (val / 10) * 0.005;
  };

  window.manualSaveGame = function () {
    saveGame();
    showToast('Game Progress Saved!');
    window.soundEngine.playItemPickup();
  };

  // --- INTERACTION & ROOM LOGIC ---
  function updateInteractionPrompt() {
    const prompt = document.getElementById('interact-prompt');
    const promptText = document.getElementById('prompt-text');

    let nearest = null;
    let minDist = 2.4;

    for (const it of interactables) {
      const d = characterPos.distanceTo(it.pos);
      if (d < minDist) {
        minDist = d;
        nearest = it;
      }
    }

    if (nearest && !state.inMainMenu && !state.inCutscene && !state.hudEditMode) {
      activeInteractable = nearest;
      promptText.innerText = `Inspect: ${nearest.name}`;
      prompt.style.display = 'flex';
    } else {
      activeInteractable = null;
      prompt.style.display = 'none';
    }
  }

  window.triggerInteraction = function () {
    if (activeInteractable && activeInteractable.action) {
      activeInteractable.action();
    }
  };

  function detectCurrentRoom() {
    let roomId = 'room_5_sanctuary';
    const z = characterPos.z;

    if (z > 8.5) roomId = 'bedroom';
    else if (z > -1.5) roomId = 'room_1_library';
    else if (z > -11.5) roomId = 'room_2_garden';
    else if (z > -21.5) roomId = 'room_3_atelier';
    else if (z > -31.5) roomId = 'room_4_observatory';
    else roomId = 'room_5_sanctuary';

    const roomConfig = MEMORIES_CONFIG[roomId];
    const roomName = roomConfig ? roomConfig.name : 'Memória';

    if (state.room !== roomName) {
      state.room = roomName;
      const roomTextEl = document.getElementById('room-name-text');
      if (roomTextEl) roomTextEl.innerText = roomName;

      triggerRoomIntroduction(roomId);
      updateHUD();
    }
  }

  // --- INVENTORY MANAGEMENT (BORDERLESS) ---
  function addItem(id, icon, name, desc) {
    if (state.inventory.find(i => i.id === id)) return;
    state.inventory.push({ id, icon, name, desc });
    updateInventoryUI();
    saveGame();
  }

  function hasItem(id) {
    return state.inventory.some(i => i.id === id);
  }

  function removeItem(id) {
    state.inventory = state.inventory.filter(i => i.id !== id);
    updateInventoryUI();
    saveGame();
  }

  function updateInventoryUI() {
    const slots = document.querySelectorAll('.inv-slot');
    slots.forEach((slot, idx) => {
      const item = state.inventory[idx];
      if (item) {
        slot.innerHTML = item.icon;
        slot.classList.add('has-item');
      } else {
        slot.innerHTML = '';
        slot.classList.remove('has-item');
      }
      if (idx === state.selectedSlot) {
        slot.classList.add('active');
      } else {
        slot.classList.remove('active');
      }
    });
  }

  window.selectInventorySlot = function (slotIdx) {
    const item = state.inventory[slotIdx];
    state.selectedSlot = (state.selectedSlot === slotIdx) ? -1 : slotIdx;
    updateInventoryUI();
    if (item && state.selectedSlot !== -1) {
      showToast(`${item.name}: ${item.desc}`);
      window.soundEngine.playClick();
    }
  };

  // --- MODALS (SAFE, TERMINAL, NOTEBOOK, DUCKS, SETTINGS) ---
  let activeSafeType = null;
  let safeInput = '';
  let catPuzzleStartedAt = 0;
  let catPuzzleErrors = 0;
  let catHintStage = 0;

  function openSafeModal(type) {
    activeSafeType = type;
    catPuzzleStartedAt = performance.now();
    catPuzzleErrors = 0;
    catHintStage = 0;
    safeInput = '';
    const modal = document.getElementById('safe-modal');
    const screen = document.getElementById('safe-screen');
    const hint = document.getElementById('safe-hint-text');
    const title = document.getElementById('safe-title-text');

    screen.classList.remove('error');
    if (type === 'kitchen_safe') {
      title.innerText = 'Kitchen Wall Safe';
      hint.innerText = '4-digit code from the refrigerator sticky note.';
      screen.innerText = '_ _ _ _';
    } else {
      title.innerText = 'Bathroom Medicine Cabinet';
      hint.innerText = '3-digit combination from the misty mirror.';
      screen.innerText = '_ _ _';
    }
    modal.style.display = 'flex';
  }

  window.safePress = function (digit) {
    window.soundEngine.playClick();
    const maxLen = activeSafeType === 'kitchen_safe' ? 4 : 3;
    if (safeInput.length < maxLen) {
      safeInput += digit;
      updateSafeDisplay();
    }
  };

  window.safeClear = function () {
    window.soundEngine.playClick();
    safeInput = '';
    updateSafeDisplay();
  };

  function updateSafeDisplay() {
    const screen = document.getElementById('safe-screen');
    screen.classList.remove('error');
    const maxLen = activeSafeType === 'kitchen_safe' ? 4 : 3;
    let disp = '';
    for (let i = 0; i < maxLen; i++) {
      disp += (i < safeInput.length ? safeInput[i] : '_') + ' ';
    }
    screen.innerText = disp.trim();
  }

  window.safeEnter = function () {
    const screen = document.getElementById('safe-screen');
    if (activeSafeType === 'kitchen_safe') {
      if (safeInput === '7428') {
        catPuzzleStartedAt = 0;
        window.soundEngine.playSafeSuccess();
        screen.innerText = 'OPEN';
        state.flags.kitchenSafeUnlocked = true;
        setTimeout(() => {
          window.closeModals();
          if (!hasItem('crystal_prism')) {
            addItem('crystal_prism', '💎', 'Crystal Prism', 'An optical prism for the Solarium puzzle.');
            showCinematicDialogue('Maya', [
              'The wall safe clicked open!',
              'Inside was a sparkling Crystal Prism! This must belong on the Solarium pedestal.'
            ]);
          }
        }, 500);
      } else {
        catPuzzleErrors++;
        if (catPuzzleErrors >= 3 && catHintStage < 1) {
          catHintStage = 1;
          showCatRadioMessage('Dica: releia as pistas que você encontrou. Os números não estão aqui por acaso. E não adianta encarar o teclado, ele não vai sentir pena.', 'hint_01.mp3');
        }
        window.soundEngine.playSafeError();
        screen.classList.add('error');
        screen.innerText = 'ERR';
        setTimeout(() => { window.safeClear(); }, 600);
      }
    } else if (activeSafeType === 'bathroom_safe') {
      if (safeInput === '385') {
        catPuzzleStartedAt = 0;
        catPuzzleStartedAt = 0;
        window.soundEngine.playSafeSuccess();
        screen.innerText = 'OPEN';
        state.flags.bathroomSafeUnlocked = true;
        setTimeout(() => {
          window.closeModals();
          if (!hasItem('desk_key')) {
            addItem('desk_key', '🗝️', 'Desk Key', 'Unlocks Maya\'s bedroom workstation desk drawer.');
            showCinematicDialogue('Maya', [
              'The medicine cabinet clicked open!',
              'I found a small silver Desk Key on the glass shelf!'
            ]);
          }
        }, 500);
      } else {
        catPuzzleErrors++;
        if (catPuzzleErrors >= 3 && catHintStage < 1) {
          catHintStage = 1;
          showCatRadioMessage('Dica: observe os detalhes do banheiro. A resposta está ligada a uma pista visual que você já encontrou.', 'hint_01.mp3');
        }
        window.soundEngine.playSafeError();
        screen.classList.add('error');
        screen.innerText = 'ERR';
        setTimeout(() => { window.safeClear(); }, 600);
      }
    }
  };

  function openPcModal() {
    const out = document.getElementById('pc-output');
    out.innerHTML = `
      <p style="color:#38BDF8;">[SYSTEM STATUS: ONLINE]</p>
      <p>Room: Bedroom Workstation</p>
      <p>Flash Drive Port: ${hasItem('usb_drive') ? '<span style="color:#34D399;">CONNECTED</span>' : '<span style="color:#EF4444;">DISCONNECTED</span>'}</p>
      <p style="color:#FBBF24;">Security override: Type "SUNSHINE" to unlock secret wardrobe passage.</p>
    `;
    document.getElementById('pc-modal').style.display = 'flex';
    window.soundEngine.playClick();
  }

  window.submitPcCommand = function () {
    const inp = document.getElementById('pc-input');
    const val = inp.value.trim().toUpperCase();
    const out = document.getElementById('pc-output');
    inp.value = '';

    if (val === 'SUNSHINE' || val === 'OVERRIDE') {
      state.flags.pcUnlocked = true;
      state.flags.secretPassageRevealed = true;
      window.soundEngine.playSafeSuccess();
      out.innerHTML += `<p style="color:#34D399;">> ACCESS GRANTED! Override code accepted. Wardrobe passage unlocked!</p>`;
      showToast('Override success! Wardrobe passage unlocked.');
      saveGame();
    } else if (val === 'STATUS') {
      out.innerHTML += `<p>> House doors active. Bedroom: ${state.flags.bedroomDoorUnlocked ? 'UNLOCKED' : 'LOCKED'}. Solarium: ${state.flags.solariumPuzzleSolved ? 'SOLVED' : 'SEALED'}.</p>`;
    } else if (val === 'CLUES') {
      out.innerHTML += `<p>> Log: "Password is the state of the sunny sky outside."</p>`;
    } else {
      window.soundEngine.playSafeError();
      out.innerHTML += `<p style="color:#EF4444;">> ERROR: Invalid credentials.</p>`;
    }
  };

  window.quickPc = function (cmd) {
    document.getElementById('pc-input').value = cmd;
    window.submitPcCommand();
  };

  window.openNotesModal = function () {
    const container = document.getElementById('notebook-entries');
    container.innerHTML = '';
    if (state.readNotes.length === 0) {
      container.innerHTML = `<p style="color:#64748B; font-style:italic; padding:12px;">No clues discovered yet. Inspect books, mirrors, and notes around the rooms!</p>`;
    } else {
      state.readNotes.forEach(nid => {
        const n = state.notes.find(x => x.id === nid);
        if (n) {
          const div = document.createElement('div');
          div.style.background = '#FEF3C7';
          div.style.padding = '12px';
          div.style.borderRadius = '12px';
          div.style.color = '#78350F';
          div.innerHTML = `<h4 style="margin-bottom:6px; color:#92400E;">${n.speaker}</h4><p style="font-size:14px;">${n.lines.join('<br>')}</p>`;
          container.appendChild(div);
        }
      });
    }
    document.getElementById('notebook-modal').style.display = 'flex';
  };

  window.openDucksModal = function () {
    const list = document.getElementById('ducks-list');
    list.innerHTML = '';
    for (let i = 1; i <= 5; i++) {
      const found = state.ducksFound.includes(i);
      const row = document.createElement('div');
      row.style.display = 'flex';
      row.style.alignItems = 'center';
      row.style.justifyContent = 'space-between';
      row.style.padding = '10px 14px';
      row.style.borderRadius = '12px';
      row.style.background = found ? '#FEF08A' : '#F1F5F9';
      row.innerHTML = `
        <span style="font-weight:bold; color:${found ? '#92400E' : '#64748B'};">🦆 Duck #${i}</span>
        <span>${found ? '✅ Discovered' : '❓ Hidden in the house'}</span>
      `;
      list.appendChild(row);
    }
    document.getElementById('ducks-modal').style.display = 'flex';
  };

  window.openSettingsModal = function () {
    const se = window.soundEngine;
    document.getElementById('vol-master').value = se.volumes.master * 100;
    document.getElementById('vol-music').value = se.volumes.music * 100;
    document.getElementById('vol-ambient').value = se.volumes.ambient * 100;
    document.getElementById('vol-character').value = se.volumes.character * 100;
    document.getElementById('vol-voice').value = (se.volumes.voice ?? 1) * 100;
    document.getElementById('settings-cam-text').innerText = state.cameraMode === '1P' ? 'First-Person (1P)' : 'Third-Person (3P)';
    document.getElementById('settings-modal').style.display = 'flex';
  };

  window.closeModals = function () {
    document.querySelectorAll('.modal-overlay').forEach(m => m.style.display = 'none');
  };

  window.resetGameProgress = function () {
    if (confirm('Start a fresh new adventure? Progress will reset.')) {
      localStorage.removeItem('cubescape_save');
      location.reload();
    }
  };

  function openVictoryModal() {
    const stats = document.getElementById('victory-stats');
    stats.innerHTML = `
      <p><b>Ducks Discovered:</b> ${state.ducksFound.length} / 5</p>
      <p><b>Clues Uncovered:</b> ${state.readNotes.length} / ${state.notes.length}</p>
      <p><b>Status:</b> Sunlit Master Architect</p>
    `;
    document.getElementById('victory-modal').style.display = 'flex';
  }

  window.playAgain = function () {
    window.resetGameProgress();
  };

  function updateHUD() {
    const memEl = document.getElementById('memories-hud-text');
    if (memEl) {
      let currentRoomId = 'bedroom';
      const z = characterPos.z;
      if (z > 8.5) currentRoomId = 'bedroom';
      else if (z > -1.5) currentRoomId = 'room_1_library';
      else if (z > -11.5) currentRoomId = 'room_2_garden';
      else if (z > -21.5) currentRoomId = 'room_3_atelier';
      else if (z > -31.5) currentRoomId = 'room_4_observatory';
      else currentRoomId = 'room_5_sanctuary';

      const room = MEMORIES_CONFIG[currentRoomId];
      if (room && room.objects && room.objects.length > 0) {
        const inspectedCount = room.objects.filter(o => state.inspectedObjects.includes(o.id)).length;
        memEl.innerText = `Lembranças: ${inspectedCount} / ${room.objects.length}`;
      } else {
        memEl.innerText = `Lembranças: ${state.inspectedObjects.length} salvas`;
      }
    }
    updateInventoryUI();
  }

  function showToast(msg) {
    const toast = document.getElementById('game-toast');
    toast.innerText = msg;
    toast.style.display = 'block';
    toast.style.animation = 'none';
    toast.offsetHeight;
    toast.style.animation = 'toastFade 2.4s forwards';
    setTimeout(() => { toast.style.display = 'none'; }, 2400);
  }

  function onWindowResize() {
    const container = document.getElementById('canvas-container');
    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  }

  // --- ANIMATION & MAIN GAME LOOP ---
  let lastTime = performance.now();

  function animate() {
    requestAnimationFrame(animate);
    const now = performance.now();
    const dt = Math.min((now - lastTime) / 1000, 0.1);
    lastTime = now;

    // Handle Cutscene
    if (state.inCutscene) {
      updateCutscene(dt);
      renderer.render(scene, camera);
      return;
    }

    updateWizardCat(dt, now);
    updateCatPuzzleHints(now);

    // Apply Jumping & Gravity Physics
    if (!isGrounded) {
      jumpVelocity -= 14.0 * dt;
      characterPos.y += jumpVelocity * dt;

      // Prevent jumping through the 3.7m ceiling
      if (characterPos.y > 1.8) {
        characterPos.y = 1.8;
        jumpVelocity = 0;
      }

      // Grounding detection
      if (characterPos.y <= 0) {
        characterPos.y = 0;
        jumpVelocity = 0;
        isGrounded = true;
        window.soundEngine.playFootstep();
      }
    }

    // Movement Calculations (Keyboard + Correct Joystick)
    if (!state.inMainMenu && !state.hudEditMode) {
      let inputForward = 0;
      let inputRight = 0;

      if (keys['w'] || keys['arrowup']) inputForward += 1;
      if (keys['s'] || keys['arrowdown']) inputForward -= 1;
      if (keys['a'] || keys['arrowleft']) inputRight -= 1;
      if (keys['d'] || keys['arrowright']) inputRight += 1;

      // Correct Touch Joystick
      if (joyActive) {
        inputForward -= joyDeltaY; // Push UP => joyDeltaY < 0 => forward > 0
        inputRight += joyDeltaX;   // Push RIGHT => joyDeltaX > 0 => right > 0
      }

      // Camera-relative forward & right
      const fwdX = -Math.sin(cameraYaw);
      const fwdZ = -Math.cos(cameraYaw);
      const rightX = Math.cos(cameraYaw);
      const rightZ = -Math.sin(cameraYaw);

      let moveDirX = fwdX * inputForward + rightX * inputRight;
      let moveDirZ = fwdZ * inputForward + rightZ * inputRight;
      const moveMagnitude = Math.hypot(moveDirX, moveDirZ);

      if (moveMagnitude > 0.05) {
        isMoving = true;
        moveDirX /= moveMagnitude;
        moveDirZ /= moveMagnitude;

        const speed = Math.min(moveMagnitude, 1.0) * 3.8 * dt;
        moveCharacter(moveDirX * speed, moveDirZ * speed);

        // Turn Maya toward movement direction
        const targetYaw = Math.atan2(moveDirX, moveDirZ);
        let diff = targetYaw - characterFacingYaw;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        characterFacingYaw += diff * 0.22;

        if (isGrounded) {
          stepDistance += speed;
          if (stepDistance > 1.4) {
            stepDistance = 0;
            window.soundEngine.playFootstep();
          }
        }
      } else {
        isMoving = false;
      }
    }

    // Procedural Character Animations (Maya Articulated 15-Joint Skeletal Rig)
    if (characterGroup) {
      characterGroup.position.set(characterPos.x, characterPos.y, characterPos.z);
      characterGroup.rotation.y = characterFacingYaw;

      if (isMoving) {
        walkAnimTime += dt * 10.5;
        const legSwing = Math.sin(walkAnimTime) * 0.48;
        const armSwing = Math.sin(walkAnimTime) * 0.45;

        if (charThighL && charThighR) {
          charThighL.rotation.x = legSwing;
          charThighR.rotation.x = -legSwing;
        }
        if (charKneeL && charKneeR) {
          charKneeL.rotation.x = legSwing < 0 ? -Math.abs(legSwing) * 0.65 : -0.05;
          charKneeR.rotation.x = -legSwing < 0 ? -Math.abs(legSwing) * 0.65 : -0.05;
        }
        if (charAnkleL && charAnkleR) {
          charAnkleL.rotation.x = -legSwing * 0.35;
          charAnkleR.rotation.x = legSwing * 0.35;
        }
        if (charHips) {
          charHips.position.y = 0.72 + Math.abs(Math.sin(walkAnimTime)) * 0.035;
          charHips.rotation.y = Math.sin(walkAnimTime) * 0.05;
        }
        if (charSpineLower) {
          charSpineLower.rotation.y = -Math.sin(walkAnimTime) * 0.04;
        }
        if (charShoulderL) charShoulderL.rotation.x = -armSwing;
        if (charShoulderR && !isReaching) charShoulderR.rotation.x = armSwing;
        if (charElbowL) charElbowL.rotation.x = 0.15 + Math.abs(armSwing) * 0.15;
        if (charElbowR && !isReaching) charElbowR.rotation.x = 0.15 + Math.abs(armSwing) * 0.15;
        if (charHead) {
          charHead.position.y = 0.10 + Math.abs(Math.sin(walkAnimTime * 2)) * 0.02;
        }
      } else {
        const idleTime = now * 0.002;
        if (charThighL) charThighL.rotation.x = THREE.MathUtils.lerp(charThighL.rotation.x, 0, dt * 8.0);
        if (charThighR) charThighR.rotation.x = THREE.MathUtils.lerp(charThighR.rotation.x, 0, dt * 8.0);
        if (charKneeL) charKneeL.rotation.x = THREE.MathUtils.lerp(charKneeL.rotation.x, 0, dt * 8.0);
        if (charKneeR) charKneeR.rotation.x = THREE.MathUtils.lerp(charKneeR.rotation.x, 0, dt * 8.0);
        if (charAnkleL) charAnkleL.rotation.x = THREE.MathUtils.lerp(charAnkleL.rotation.x, 0, dt * 8.0);
        if (charAnkleR) charAnkleR.rotation.x = THREE.MathUtils.lerp(charAnkleR.rotation.x, 0, dt * 8.0);
        if (charHips) {
          charHips.position.y = THREE.MathUtils.lerp(charHips.position.y, 0.72, dt * 8.0);
          charHips.rotation.y = THREE.MathUtils.lerp(charHips.rotation.y, 0, dt * 8.0);
        }
        if (charSpineLower) charSpineLower.rotation.y = THREE.MathUtils.lerp(charSpineLower.rotation.y, 0, dt * 8.0);

        if (charChest) {
          charChest.scale.y = 1.0 + Math.sin(idleTime * 2.0) * 0.025;
          charChest.scale.x = 1.0 + Math.sin(idleTime * 2.0) * 0.015;
        }
        if (charShoulderL) charShoulderL.rotation.x = Math.sin(idleTime) * 0.04;
        if (charShoulderR && !isReaching) charShoulderR.rotation.x = -Math.sin(idleTime) * 0.04;
        if (charElbowL) charElbowL.rotation.x = 0.08 + Math.sin(idleTime) * 0.02;
        if (charElbowR && !isReaching) charElbowR.rotation.x = 0.08 - Math.sin(idleTime) * 0.02;
        if (charHead) {
          charHead.position.y = 0.10;
          charHead.rotation.z = Math.sin(idleTime * 0.8) * 0.025;
        }
      }

      // Procedural Eyelids Blinking
      blinkTimer -= dt;
      if (charEyeLids) {
        if (blinkTimer <= 0) {
          charEyeLids.scale.y = 1.0;
          if (blinkTimer < -0.15) {
            charEyeLids.scale.y = 0.0;
            blinkTimer = 2.5 + Math.random() * 2.5;
          }
        } else {
          charEyeLids.scale.y = 0.0;
        }
      }

      // Physical Reaching Interaction
      if (isReaching) {
        reachTimer += dt;
        const reachPhase = reachTimer / 0.5;
        if (reachPhase < 0.5) {
          const f = reachPhase / 0.5;
          if (charShoulderR) charShoulderR.rotation.x = -1.1 * f;
          if (charElbowR) charElbowR.rotation.x = 0.35 * f;
        } else if (reachPhase < 1.0) {
          if (reachCallback) {
            const cb = reachCallback;
            reachCallback = null;
            cb();
          }
          const r = (1.0 - reachPhase) / 0.5;
          if (charShoulderR) charShoulderR.rotation.x = -1.1 * r;
          if (charElbowR) charElbowR.rotation.x = 0.35 * r;
        } else {
          isReaching = false;
        }
      }
    }

    // Dynamic Lamps & Environmental Life Updates
    LampManager.update(dt);
    animateEnvironments(dt);
    renderPlanarMirrors();

    // Camera Placement with Ceiling Collision Avoidance
    if (state.inMainMenu) {
      const orbitYaw = Math.PI + Math.sin(now * 0.0003) * 0.35;
      const camX = characterPos.x + Math.sin(orbitYaw) * 3.8;
      const camZ = characterPos.z + Math.cos(orbitYaw) * 3.8;
      camera.position.set(camX, 1.8, camZ);
      camera.lookAt(characterPos.x, 1.2, characterPos.z);
    } else if (state.cameraMode === '1P') {
      // First-Person Mode: Camera at Maya's eye level
      const eyeHeight = characterPos.y + 1.45;
      camera.position.set(characterPos.x, eyeHeight, characterPos.z);

      const lookTargetX = characterPos.x - Math.sin(cameraYaw) * Math.cos(cameraPitch);
      const lookTargetY = eyeHeight + Math.sin(cameraPitch);
      const lookTargetZ = characterPos.z - Math.cos(cameraYaw) * Math.cos(cameraPitch);

      camera.lookAt(lookTargetX, lookTargetY, lookTargetZ);
    } else {
      // Third-Person Mode: Following behind Maya with ceiling clearance
      const targetLook = new THREE.Vector3(
        characterPos.x,
        characterPos.y + cameraTargetHeight,
        characterPos.z
      );

      // Clamp vertical pitch so camera cannot rise above 3.35m (ceiling is 3.7m)
      const maxAllowedHeight = 3.35;
      const cosPitch = Math.cos(cameraPitch);
      const sinPitch = Math.sin(cameraPitch);

      let camOffsetDist = maxCamDistance;
      const desiredY = targetLook.y + sinPitch * camOffsetDist;
      if (desiredY > maxAllowedHeight) {
        camOffsetDist = (maxAllowedHeight - targetLook.y) / sinPitch;
        camOffsetDist = Math.max(1.2, Math.min(maxCamDistance, camOffsetDist));
      }

      currentCamDistance += (camOffsetDist - currentCamDistance) * 0.2;

      const offsetX = Math.sin(cameraYaw) * Math.cos(cameraPitch) * currentCamDistance;
      const offsetZ = Math.cos(cameraYaw) * Math.cos(cameraPitch) * currentCamDistance;
      const offsetY = Math.sin(cameraPitch) * currentCamDistance;

      let desiredCamPos = new THREE.Vector3(
        targetLook.x + offsetX,
        Math.min(maxAllowedHeight, targetLook.y + offsetY),
        targetLook.z + offsetZ
      );

      // Wall boundary clamping
      const minX = -12.4, maxX = 12.4, minZ = -1.0, maxZ = 26.0;
      if (desiredCamPos.x < minX) desiredCamPos.x = minX;
      if (desiredCamPos.x > maxX) desiredCamPos.x = maxX;
      if (desiredCamPos.z < minZ) desiredCamPos.z = minZ;
      if (desiredCamPos.z > maxZ) desiredCamPos.z = maxZ;

      camera.position.copy(desiredCamPos);
      camera.lookAt(targetLook);
    }

    // Process Door & Drawer Interpolations
    animDoors.forEach(d => {
      d.obj.rotation.y += (d.targetRot - d.obj.rotation.y) * 0.15;
    });
    animDrawers.forEach(d => {
      d.obj.position[d.axis] += (d.target - d.obj.position[d.axis]) * 0.18;
    });

    updateInteractionPrompt();
    detectCurrentRoom();

    try {
      renderer.render(scene, camera);
    } catch (e) {
      console.error('Renderer error', e);
    }
  }

  // --- INITIALIZATION ---
  window.addEventListener('DOMContentLoaded', () => {
    try {
      initThree();
      updateHUD();
      animate();
    } catch (error) {
      console.error('Cubescape startup failed:', error);
      const overlay = document.createElement('div');
      overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#171321;color:#fff;padding:24px;font:16px/1.5 sans-serif;display:flex;align-items:center;justify-content:center;text-align:center;';
      overlay.textContent = 'Não foi possível iniciar o jogo neste dispositivo. Feche e abra novamente. Se o problema continuar, envie uma captura desta tela ao suporte.';
      document.body.appendChild(overlay);
    }
  });

})();
