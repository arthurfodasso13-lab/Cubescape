package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.CubescapeTheme

class MainActivity : ComponentActivity() {

  private var webViewRef: WebView? = null

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      CubescapeTheme {
        BackHandler {
          webViewRef?.evaluateJavascript(
            """
            (function() {
              var modals = document.querySelectorAll('.modal-overlay');
              var anyOpen = false;
              modals.forEach(function(m) {
                if (m.style.display === 'flex' || m.style.display === 'block') {
                  anyOpen = true;
                  m.style.display = 'none';
                }
              });
              if (!anyOpen) {
                var menu = document.getElementById('main-menu-overlay');
                if (!menu || menu.style.display === 'none') {
                  if (typeof window.openSettingsModal === 'function') {
                    window.openSettingsModal();
                  }
                }
              }
            })();
            """.trimIndent(),
            null
          )
        }

        Surface(
          modifier = Modifier
            .fillMaxSize()
            .testTag("cubescape_game_surface"),
          color = Color(0xFF87CEEB)
        ) {
          GameScreen(
            onWebViewReady = { webViewRef = it }
          )
        }
      }
    }
  }

  override fun onResume() {
    super.onResume()
    webViewRef?.onResume()
  }

  override fun onPause() {
    super.onPause()
    webViewRef?.onPause()
  }

  override fun onDestroy() {
    webViewRef?.destroy()
    webViewRef = null
    super.onDestroy()
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GameScreen(
  onWebViewReady: (WebView) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val sharedPreferences = remember {
    context.getSharedPreferences("cubescape_prefs", Context.MODE_PRIVATE)
  }

  val bridge = remember {
    AndroidBridge(context, sharedPreferences)
  }

  Box(modifier = modifier.fillMaxSize()) {
    AndroidView(
      modifier = Modifier
        .fillMaxSize()
        .testTag("game_webview"),
      factory = { ctx ->
        WebView(ctx).apply {
          settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
          }
          setBackgroundColor(0xFF87CEEB.toInt())
          webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage?): Boolean {
              android.util.Log.d("CubescapeWeb", "${consoleMessage?.message()} [${consoleMessage?.sourceId()}:${consoleMessage?.lineNumber()}]")
              return true
            }
          }
          webViewClient = WebViewClient()

          addJavascriptInterface(bridge, "AndroidBridge")
          loadUrl("file:///android_asset/game/index.html")

          onWebViewReady(this)
        }
      }
    )
  }
}

class AndroidBridge(
  private val context: Context,
  private val sharedPreferences: android.content.SharedPreferences
) {

  @JavascriptInterface
  fun saveGameState(jsonString: String) {
    sharedPreferences.edit().putString("saved_state", jsonString).apply()
  }

  @JavascriptInterface
  fun loadGameState(): String? {
    return sharedPreferences.getString("saved_state", null)
  }

  @JavascriptInterface
  fun vibrate(durationMs: Long) {
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager =
          context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        val vibrator = vibratorManager?.defaultVibrator
        vibrator?.vibrate(
          VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
        )
      } else {
        @Suppress("DEPRECATION")
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          vibrator?.vibrate(
            VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
          )
        } else {
          @Suppress("DEPRECATION")
          vibrator?.vibrate(durationMs)
        }
      }
    } catch (_: Exception) {
      // Haptics unavailable on emulator / some devices, ignore gracefully
    }
  }
}
