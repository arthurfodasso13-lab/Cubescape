package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SkyBlue = Color(0xFF38BDF8)
val WarmSun = Color(0xFFFBBF24)
val BirchWood = Color(0xFFE5C396)
val SageGreen = Color(0xFF4ADE80)
val ModernWhite = Color(0xFFF8FAFC)
val DarkCharcoal = Color(0xFF1E293B)
val SlateGray = Color(0xFF64748B)
val AmberGold = Color(0xFFF59E0B)

val PrimaryBlue = Color(0xFF0284C7)
val SecondaryTeal = Color(0xFF0D9488)
val TertiaryAmber = Color(0xFFD97706)
