package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Cubescape", appName)
  }

  @Test
  fun `verify shared preferences bridge initialization`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = context.getSharedPreferences("cubescape_prefs", Context.MODE_PRIVATE)
    val bridge = AndroidBridge(context, prefs)
    bridge.saveGameState("{\"test\": true}")
    val loaded = bridge.loadGameState()
    assertEquals("{\"test\": true}", loaded)
  }
}
